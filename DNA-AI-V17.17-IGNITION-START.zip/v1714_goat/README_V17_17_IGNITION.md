# DNA.AI V17.17 — Ignition Start

Built directly on V17.15 Premium 3D UI.

- Fresh dashboard launch starts DORMANT.
- Voice engine is stopped during dormant state.
- Existing dashboard remains visible but its lighting and controls are dimmed/disabled.
- The central DNA.AI core is the ignition key.
- Click the core to run a sub-second cyan power-up sequence.
- After ignition the existing voice engine starts and the original V17.15 UI/functionality becomes active.
- No new npm/Python packages, models, WebGL, video, Ollama or PyTorch were added.
- Overlay/orb and backend command architecture are unchanged.
