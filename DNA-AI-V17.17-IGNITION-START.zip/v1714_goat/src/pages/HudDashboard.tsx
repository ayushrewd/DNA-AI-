import { HudHeader } from '@/components/HudHeader';
import { SystemDiagnostics } from '@/components/SystemDiagnostics';
import { AiModules } from '@/components/AiModules';
import { VoiceWaveform } from '@/components/VoiceWaveform';
import { CentralRing } from '@/components/CentralRing';
import { SystemConsole } from '@/components/SystemConsole';
import { NetworkStatus } from '@/components/NetworkStatus';
import { AiInformation } from '@/components/AiInformation';
import { SystemActivity } from '@/components/SystemActivity';
import { QuickAccess } from '@/components/QuickAccess';
import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

export default function HudDashboard() {
  const [voiceState, setVoiceState] = useState('UNAVAILABLE');
  const [micBusy, setMicBusy] = useState(false);
  const [systemActive, setSystemActive] = useState(false);
  const [igniting, setIgniting] = useState(false);
  const micEnabled = voiceState !== 'MIC_OFF' && voiceState !== 'STOPPED';
  const toggleMic = async () => {
    if (!window.dnaDesktop || micBusy) return;
    setMicBusy(true);
    try { const s = await window.dnaDesktop.voiceToggle(); setVoiceState(s.state); } finally { setMicBusy(false); }
  };
  useEffect(() => {
    if (!window.dnaDesktop) return;
    // Ignition mode: every fresh dashboard launch starts dormant.
    window.dnaDesktop.voiceStop().then(s => setVoiceState(s.state)).catch(() => setVoiceState('STOPPED'));
    return window.dnaDesktop.onVoiceState(s => setVoiceState(s.state));
  }, []);
  const igniteSystem = async () => {
    if (systemActive || igniting) return;
    setIgniting(true);
    // Light sequence starts immediately; voice comes online near the end.
    window.setTimeout(async () => {
      try {
        if (window.dnaDesktop) { const s = await window.dnaDesktop.voiceStart(); setVoiceState(s.state); }
      } finally {
        setSystemActive(true);
        setIgniting(false);
      }
    }, 720);
  };
  const voiceLabel = voiceState === 'MIC_OFF' || voiceState === 'STOPPED' ? 'MIC OFF' : voiceState === 'WAITING_WAKE' ? 'HEY DNA' : voiceState === 'AWAKE' ? 'AWAKE' : voiceState === 'PROCESSING' ? 'PROCESSING...' : voiceState;
  return (
    <div
      className={`dna-dashboard ${systemActive ? 'dna-system-active' : igniting ? 'dna-system-igniting' : 'dna-system-dormant'} w-screen overflow-hidden bg-hud-bg text-cyan-glow font-tech relative z-0`}
      style={{ height: '100dvh', display: 'flex', flexDirection: 'column', padding: '16px 20px 14px' }}
    >
      {/* Scanline overlay */}
      <div className="absolute inset-0 pointer-events-none z-50 opacity-[0.06] bg-[linear-gradient(rgba(0,229,255,0)_50%,rgba(0,229,255,0.25)_50%)] bg-[length:100%_4px]" />
      {/* Vignette */}
      <div className="absolute inset-0 pointer-events-none z-40 bg-[radial-gradient(ellipse_at_center,transparent_42%,#000000_112%)]" />

      <div className="dna-powered-content"><HudHeader /></div>

      <div
        className="dna-powered-content relative z-10 flex-1 overflow-hidden"
        style={{ display: 'flex', gap: '16px', paddingTop: '10px', minHeight: 0 }}
      >
        {/* ── Left Column ─────────────────────────────── */}
        <div
          style={{
            width: '300px',
            flexShrink: 0,
            display: 'flex',
            flexDirection: 'column',
            gap: '10px',
            height: '100%',
          }}
        >
          {/* System Diagnostics — fixed 260px */}
          <SystemDiagnostics />

          {/* AI Modules — takes remaining space */}
          <div style={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column' }}>
            <AiModules />
          </div>

          {/* Voice Waveform — fixed 110px */}
          <div style={{ flexShrink: 0 }}>
            <VoiceWaveform />
          </div>
        </div>

        {/* ── Center Column ───────────────────────────── */}
        <div
          style={{
            flex: 1,
            minWidth: 0,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'space-between',
            height: '100%',
          }}
        >
          {/* Ring + Listening label */}
          <div style={{ flex: 1, minHeight: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', width: '100%' }}>
            <CentralRing active={systemActive} igniting={igniting} onIgnite={igniteSystem} />
            <div style={{ marginTop: '20px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                <motion.div
                  style={{ display: 'flex', gap: '3px' }}
                  animate={{ opacity: [0.3, 1, 0.3] }}
                  transition={{ repeat: Infinity, duration: 1.5 }}
                >
                  {[3, 5, 3, 7, 4].map((h, i) => (
                    <div key={i} style={{ width: '3px', height: `${h}px`, background: '#00e5ff', borderRadius: '1px' }} />
                  ))}
                </motion.div>
                <div className="font-orbitron" style={{ fontSize: '18px', letterSpacing: '0.2em', color: '#00e5ff', textShadow: '0 0 15px #00e5ff' }}>
                  {systemActive ? voiceLabel : igniting ? 'IGNITING...' : 'SYSTEM DORMANT'}
                </div>
                <motion.div
                  style={{ display: 'flex', gap: '3px' }}
                  animate={{ opacity: [0.3, 1, 0.3] }}
                  transition={{ repeat: Infinity, duration: 1.5, delay: 0.5 }}
                >
                  {[4, 7, 3, 5, 3].map((h, i) => (
                    <div key={i} style={{ width: '3px', height: `${h}px`, background: '#00e5ff', borderRadius: '1px' }} />
                  ))}
                </motion.div>
              </div>
              <div style={{ fontSize: '10px', letterSpacing: '0.3em', opacity: 0.55 }}>{systemActive ? (voiceState === 'WAITING_WAKE' ? 'SAY “HEY DNA” TO ACTIVATE' : voiceState === 'AWAKE' ? 'LISTENING FOR YOUR COMMAND' : 'VOICE ENGINE STATUS') : igniting ? 'POWERING DNA SYSTEMS' : 'CLICK DNA.AI CORE TO START'}</div>
              <button
                onClick={toggleMic}
                disabled={micBusy || !systemActive}
                title={micEnabled ? 'Disable DNA microphone completely' : 'Enable DNA microphone'}
                style={{
                  marginTop: '8px', padding: '7px 14px', borderRadius: '999px',
                  border: `1px solid ${micEnabled ? '#00e5ff' : '#ff5263'}`,
                  background: micEnabled ? 'rgba(0,229,255,.08)' : 'rgba(255,82,99,.08)',
                  color: micEnabled ? '#00e5ff' : '#ff7a88', fontSize: '10px',
                  letterSpacing: '.16em', cursor: micBusy ? 'wait' : 'pointer',
                  boxShadow: micEnabled ? '0 0 12px rgba(0,229,255,.18)' : '0 0 12px rgba(255,82,99,.15)'
                }}
              >
                {micBusy ? 'MIC...' : micEnabled ? '● MIC ON — CLICK TO MUTE' : '○ MIC OFF — CLICK TO ENABLE'}
              </button>
            </div>
          </div>

          {/* System Console — bottom of center */}
          <div style={{ width: '100%', flexShrink: 0 }}>
            <SystemConsole />
          </div>
        </div>

        {/* ── Right Column ────────────────────────────── */}
        <div
          style={{
            width: '300px',
            flexShrink: 0,
            display: 'flex',
            flexDirection: 'column',
            gap: '10px',
            height: '100%',
          }}
        >
          {/* Network Status */}
          <div style={{ flexShrink: 0 }}>
            <NetworkStatus />
          </div>

          {/* AI Information */}
          <div style={{ flexShrink: 0 }}>
            <AiInformation />
          </div>

          {/* System Activity */}
          <div style={{ flexShrink: 0 }}>
            <SystemActivity />
          </div>

          {/* Quick Access */}
          <div style={{ flexShrink: 0 }}>
            <QuickAccess />
          </div>
        </div>
      </div>
    </div>
  );
}
