# DNA.AI V12 — Voice-First Reliability Build

Frontend is intentionally unchanged.

## What changed
- Whisper is now a persistent Python worker: the model loads once instead of once per command.
- `DNA` remains a lightweight Windows wake listener; after wake, high-accuracy local Whisper captures the command.
- One wake opens a natural command session. After each executed command and echo-safe TTS cooldown, DNA listens for a short follow-up automatically. Silence returns it to wake mode.
- CUDA is attempted on RTX GPUs; if the CUDA runtime is incomplete, STT falls back to a smaller CPU model instead of becoming deaf.
- TTS never runs concurrently with command capture. Existing 1.5 s post-TTS cooldown is retained.
- No frontend redesign.

## Acceptance target
1. Say `DNA` once.
2. Say `Open calculator`.
3. After it opens and DNA finishes speaking, say `Open ChatGPT` without saying DNA again.
4. Then say `Play CarryMinati on YouTube`.
5. Stay silent for ~5 seconds; DNA returns to wake mode.

Static checks cannot prove physical microphone quality or browser autoplay. Those remain real Windows acceptance tests.
