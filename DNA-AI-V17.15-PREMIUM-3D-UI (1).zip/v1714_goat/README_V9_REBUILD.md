# DNA.AI V9 — capability-first rebuild

This release fixes the failures observed in V8.1.1 instead of masking them.

## Critical changes
- Deterministic `play <query> on YouTube` route. It uses Playwright, opens a real watch URL, starts the HTML5 video, and verifies `video.paused === false` before reporting success.
- Local-command precedence: `play` is classified as a local action, so the conversational LLM cannot answer a playback command with unrelated prose.
- Higher-accuracy local STT default: faster-whisper `medium`, beam/best-of decoding, command/name prompt and hotwords including ChatGPT, CarryMinati and YouTube.
- Existing direct website routes remain deterministic (`open chatgpt`, `open youtube`, etc.).
- Existing UI is preserved.

## Voice prerequisite
Run `SETUP_LOCAL_VOICE.bat` once on a Windows PC with Python 3.10–3.12. The first voice use downloads the multilingual Whisper model. Without this, DNA.AI intentionally falls back to Windows Speech, which is less accurate.

## Acceptance tests before calling it final
1. `open calculator` -> Calculator actually opens.
2. `open chatgpt` -> chatgpt.com opens directly.
3. `play CarryMinati on YouTube` -> a YouTube watch page opens and playback is verified before `[OK]`.
4. Voice: `Hey DNA` then `Open ChatGPT` -> transcript contains ChatGPT, not CBT.
5. Voice: `Hey DNA` then `Play CarryMinati on YouTube` -> transcript and actual playback both succeed.
6. If playback cannot start, DNA.AI reports failure instead of claiming it is playing.

## Verification note
Node/Electron source syntax and Python bridge syntax were checked in the rebuild environment. Full Windows runtime/installer behavior must be acceptance-tested on Windows because the build environment is not Windows and its internal npm mirror does not contain @tailwindcss/vite.
