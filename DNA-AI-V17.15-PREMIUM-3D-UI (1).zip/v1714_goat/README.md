# DNA.AI P1 — Brain + Native Windows Voice

Preserves the approved Replit HUD and adds a real Electron execution layer.

## Implemented
- Secure Electron preload + typed IPC (`contextIsolation: true`, `nodeIntegration: false`)
- Deterministic Windows/URL command engine
- Gemini conversational fallback for non-local commands (REST from Electron main; key is never exposed to renderer)
- Windows native speech recognition using .NET `System.Speech`
- Windows native TTS using `System.Speech.Synthesis`
- Voice transcripts/results streamed to the existing System Console
- Voice UI reflects runtime state instead of hardcoded `LISTENING`
- Real RAM/system metrics foundation from Node `os`

## Configure Gemini (PowerShell)
For the current terminal session:

```powershell
$env:GEMINI_API_KEY="YOUR_KEY"
$env:GEMINI_MODEL="gemini-2.5-flash"
npm run electron:dev
```

If no key is configured, local commands still work and AI queries report `NOT_CONFIGURED` instead of faking a response.

## Run
```powershell
npm install
npm run typecheck
npm run build
npm run electron:dev
```

## Tests
Type: `open calculator`, `open youtube`, or `who are you?`.
Speak after the voice panel reports `LISTENING`.

## Runtime limitations
Native STT/TTS currently targets Windows and depends on the Windows `System.Speech` recognizer/voice installed on the machine. Recognition quality and Hinglish support depend on installed Windows speech language packs. This build does not yet implement a true wake-word model/VAD; it performs continuous dictation. Wake word + VAD should be a separate next phase (Whisper.cpp/Vosk + dedicated wake-word engine), not faked.
