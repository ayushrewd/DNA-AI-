# DNA.AI P5 — Core Assistant Integration

## Changes
- Migrated Gemini default from deprecated/new-user-blocked `gemini-2.5-flash` to `gemini-3.6-flash`.
- Gemini requests use the `x-goog-api-key` header and automatically try compatible Flash fallbacks only when a model is unavailable.
- Added local `.env` loading in Electron main so the Gemini key does not need to be re-entered in PowerShell on every launch.
- `.env` is git-ignored. Never commit or share API keys.
- Wake activation is restricted to `Hey DNA` / `Hey D N A` to reduce false triggers from ordinary uses of the word DNA.
- Siri overlay now receives focus when wake is detected.
- TTS exposes a real `SPEAKING` runtime state and command execution waits for speech completion before returning to wake mode, reducing self-listening races.
- Existing HUD and local Windows command architecture preserved.

## Setup
1. Copy `.env.example` to `.env`.
2. Put a NEW Gemini API key in `.env`.
3. `npm install`
4. `npm run electron:dev`

## Verification checklist on Windows
- Type `who are you?` and confirm a Gemini response.
- Type `open calculator` and confirm Calculator opens.
- Hide the HUD, say `Hey DNA`, and confirm the overlay appears.
- After DNA says `Yes?`, say `open YouTube` and confirm the action executes.
- Confirm the overlay returns to wake mode after TTS finishes.

## Known boundary
The wake/STT prototype still uses Windows `System.Speech`. This is not Siri-grade wake-word recognition, VAD, noise suppression, or multilingual STT. A dedicated wake-word detector + VAD + Whisper-class STT remains a later native voice-engine upgrade and must be tested on the target Windows hardware.
