# DNA.AI V8 — Final Canonical

V8 keeps the V7 HUD layout/design and adds a luminance/glow pass only. It also adds a persistent local alarm/timer/reminder scheduler.

Examples:
- `timer for 20 minutes`
- `20 minute ka timer laga do`
- `alarm tomorrow at 7 am`
- `kal 7 baje alarm laga do`
- `remind me in 30 minutes to study ML`
- `show my alarms`

Schedules are stored under Electron userData and re-armed after app/PC restart when DNA.AI autostarts. When due, DNA shows a Windows notification, foregrounds its assistant overlay, and speaks the reminder through the configured voice stack.

## Phone
V8 remains the Windows canonical client. It does not pretend that an APK/iOS app is bundled. A secure phone companion requires a separate mobile client/pairing layer; exposing unrestricted PC commands over LAN by default was deliberately not added because that would weaken the security boundary.

## UI
No component layout, panel placement, typography, or visual structure was redesigned. Only cyan luminance, panel edge glow, ambient center light, and text glow were increased.
