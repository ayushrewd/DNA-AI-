# DNA.AI V17.2 — Hardware-style Mic Toggle

Adds a dashboard MIC ON/OFF control without redesigning the HUD.

- MIC ON: existing DNA/Hey DNA wake + command voice pipeline works normally.
- MIC OFF: stops wake recognizer, command capture, and persistent STT worker. DNA cannot hear anything.
- Click again: voice stack starts again and returns to wake listening.
- Existing Sleep Mode remains separate: Sleep still keeps lightweight wake listening; MIC OFF is a true user-controlled microphone kill switch.

Backend IPC: `dna:voice-toggle`
Frontend: button below the central voice status.
