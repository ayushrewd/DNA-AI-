# DNA.AI V17.3 Fast/Silent

- Preserves MIC ON/OFF and Hey DNA wake behavior.
- Local PC commands execute silently (HUD confirms) instead of waiting for TTS.
- Conversational AI answers still speak.
- Repeated-token / echo hallucinations such as `alte alte alte` are discarded before routing or TTS.
- Faster Whisper decoding (beam 3 vs 8) while keeping the multilingual medium model by default.
- Faster end-of-speech detection and shorter command timeout.
- TTS cooldown reduced to 400 ms.
- Continuous follow-up remains OFF by default to prevent echo loops.

Hardware voice behavior still requires testing on the target Windows PC.
