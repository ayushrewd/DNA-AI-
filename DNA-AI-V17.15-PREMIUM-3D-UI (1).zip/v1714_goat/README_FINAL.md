# DNA.AI — Canonical V3 Maximum Build

Start here: `DNA_MAXIMUM_BUILD.md`.

Core pipeline:

`Wake/voice or text -> local-first intent router -> permission boundary -> Windows/browser/file tools -> action verification -> response`

Conversation/research:

`Input -> relevant long-term memory -> model router -> answer`

Perception:

`Screenshot -> vision provider -> grounded screen description -> structured UI Automation when available`

This archive intentionally does not claim that a source-level feature is runtime-verified on every Windows machine. Run the verification script, build the installer, then validate wake, STT, TTS, browser logins and UI automation on the target PC.
