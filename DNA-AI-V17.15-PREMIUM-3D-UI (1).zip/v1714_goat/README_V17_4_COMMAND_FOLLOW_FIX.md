# DNA.AI V17.4 — Command Follow Fix

Focused repair on deterministic command routing while preserving MIC toggle, wake word, fast/silent mode, and conversation.

Added natural YouTube compound commands such as `Open YT and play CarryMinati`, YouTube search variants, and broader Google search phrases. YouTube compound commands are kept atomic so the multi-action splitter cannot lose the YouTube context.

Local deterministic commands continue to bypass the conversational model.
