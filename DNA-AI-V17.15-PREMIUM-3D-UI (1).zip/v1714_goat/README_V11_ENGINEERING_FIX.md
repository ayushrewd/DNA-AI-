# DNA.AI V11 — engineering repair

Frontend is intentionally unchanged.

## Repairs made
- Removed spoken wake acknowledgement that caused self-trigger feedback.
- Added explicit SPEAKING -> COOLDOWN -> WAITING_WAKE transition (1.5 s).
- Added deterministic, testable intent parser for YouTube/Hinglish/open commands.
- Fixed `at youtube`, `YouTube pe ... chala`, `... YouTube pe laga`, `play some music`, `ChatGPT open kar`, and common `khol/kholo` forms.
- YouTube success remains tied to browser-agent video playback state (`video.paused === false`), not just search navigation.
- Kept Whisper `medium` local STT and Edge TTS path from V10.
- Added `npm run test:dna` deterministic router acceptance tests.

## Verified in this build environment
- `npm run test:dna`: 8/8 parser tests pass.
- Node syntax: main + intent router pass.
- Python syntax: Whisper + Edge TTS bridges pass.

## Must still be verified on Windows hardware
Physical microphone wake accuracy, CUDA runtime, actual browser autoplay, installed-app launch, and speaker/microphone acoustic isolation cannot be truthfully runtime-tested in this Linux build environment.

## Windows
Run `BUILD_FINAL_WINDOWS.bat`, then install from `release`.
