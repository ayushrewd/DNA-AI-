# DNA.AI P4 — Siri-style interaction layer

P4 keeps the full HUD intact and adds a separate frameless assistant overlay.

Runtime flow:
1. DNA.AI stays alive in the tray/background.
2. Passive Windows speech recognition waits for “Hey DNA”.
3. Wake detection shows the compact floating overlay, not the full dashboard.
4. The next utterance is routed through the same local Intent Engine / Gemini fallback.
5. Voice result is displayed in the overlay and spoken through native Windows TTS.
6. The overlay dismisses after the interaction; the wake engine remains alive.
7. “Open full command center” opens the original HUD.

Current limitation: System.Speech is a prototype wake/STT layer, not a dedicated low-power production wake-word model. Local Windows microphone/runtime verification is required.
