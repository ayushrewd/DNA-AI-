@echo off
setlocal
TITLE DNA.AI Local Brain Setup
where ollama >nul 2>nul
if errorlevel 1 (
  echo Installing Ollama...
  winget install --id Ollama.Ollama -e --accept-package-agreements --accept-source-agreements
  if errorlevel 1 (
    echo Ollama install failed. Install Ollama manually, then run this file again.
    pause & exit /b 1
  )
  set "PATH=%PATH%;%LOCALAPPDATA%\Programs\Ollama"
)
echo Starting Ollama...
start "" /min ollama serve
ping 127.0.0.1 -n 4 >nul
echo Installing DNA local conversational model. This is a one-time download...
ollama pull qwen3:4b
if errorlevel 1 (echo Model download failed. Check internet and run this again.& pause & exit /b 1)
echo DNA.AI local brain is ready.
pause
