# DNA Brain v2 — Canonical Architecture

DNA.AI is not a cloned foundation model. Its intelligence is composed from:

1. **Local-first tool router** — Windows/apps/files/browser actions never depend on chat quota.
2. **Provider router** — Gemini 3.6 Flash by default, with optional local Ollama fallback.
3. **Conversation context** — recent multi-turn context is retained inside the running DNA session.
4. **Explicit long-term memory** — `remember ...`, `yaad rakho ...`, recall, and forget commands persist locally under Electron userData.
5. **Fresh web research** — `research <topic>` uses DNA's persistent browser agent to collect current search evidence, then asks the brain to synthesize only that evidence.
6. **Browser identity separation** — persistent DNA browser profile; authenticated state remains local and must never be committed to source control.
7. **Truth boundary** — the language model cannot claim OS actions; only verified local tools can report successful actions.
8. **Natural voice** — neural TTS path remains separate from conversational-model quota.

## Optional local brain
Install Ollama separately and pull a model, then set `DNA_BRAIN_ORDER=gemini,ollama` or `ollama,gemini`. DNA continues to function locally even if no local model is installed; only the fallback is unavailable.

## Memory commands
- `remember my project deadline is Friday`
- `yaad rakho I prefer short answers`
- `what do you remember about project deadline`
- `forget project deadline`

## Research
- `research latest Windows AI automation APIs`

Research is evidence-grounded search-result synthesis, not unrestricted autonomous browsing. High-risk actions still require confirmation.
