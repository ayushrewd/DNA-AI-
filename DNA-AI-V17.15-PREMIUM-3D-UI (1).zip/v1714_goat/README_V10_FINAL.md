# DNA.AI V10 FINAL — capability-first

Hardware target: Intel Core 7 240H, 16 GB DDR5, RTX 4050 Laptop 6 GB.

## Architecture
- Wake word: **DNA** (also accepts Hey/Okay/Yo DNA), lightweight Windows constrained grammar.
- Command STT: faster-whisper **medium**, automatically uses NVIDIA CUDA when available, CPU fallback.
- Brain: local-first Ollama (qwen3:4b setup script), no mandatory paid API.
- Voice: Edge neural TTS first, Windows TTS fallback.
- Actions: deterministic local router before LLM.
- YouTube: Edge/Playwright automation and playback verification.
- WhatsApp: persistent WhatsApp Web session and outgoing-message verification.
- Truth rule: known actions should not claim success when verification fails.

## Install
Run BUILD_FINAL_WINDOWS.bat, then install release\DNA.AI-Setup-11.0.0.exe.
Voice dependencies self-install on first launch if Python is available. Run SETUP_DNA_BRAIN.bat once for free local conversation.

## Core acceptance tests
1. DNA -> Yeah?
2. Open ChatGPT.
3. Open calculator.
4. Play CarryMinati on YouTube.
5. Send a WhatsApp message to a signed-in contact.
6. Explain ML fundamentals.

Do not call a capability successful merely because the UI says ACTIVE. Runtime behavior is the test.
