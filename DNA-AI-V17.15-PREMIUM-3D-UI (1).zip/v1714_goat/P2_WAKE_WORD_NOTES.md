# DNA.AI P2 — Wake Activation

## Added
- Voice engine starts automatically when the Electron renderer is ready.
- Passive state is `WAITING_WAKE`.
- Recognizes wake variants: `Hey DNA`, `Hey D N A`, `DNA`, `D N A` from Windows System.Speech transcripts.
- On wake detection, a minimized/hidden DNA.AI window is restored, shown, and focused.
- DNA.AI answers `Yes?`, then accepts the next recognized utterance for 10 seconds.
- Supports one-shot phrases such as `Hey DNA open YouTube`.
- After command execution, returns to passive wake listening.
- Ignores recognition events while native TTS is speaking to reduce self-trigger feedback.

## Verification boundary
Code syntax is verified in this build environment. Microphone recognition, Windows System.Speech accuracy, window foreground behavior, and wake-word reliability require local Windows runtime verification.

## Important
This is a practical P2 wake layer built on Windows System.Speech dictation. It is not yet a dedicated low-power wake-word model. A later production voice engine should use a dedicated wake detector plus VAD and a stronger STT engine such as whisper.cpp/Vosk as appropriate.
