const assert=require('node:assert/strict');
const {classify}=require('./electron/intent-router.cjs');
const cases=[
 ['Play CarryMinati on YouTube','YOUTUBE_PLAY','CarryMinati'],
 ['play carryminati at youtube','YOUTUBE_PLAY','carryminati'],
 ['YouTube pe CarryMinati chala','YOUTUBE_PLAY','carryminati'],
 ['CarryMinati YouTube pe laga','YOUTUBE_PLAY','carryminati'],
 ['play some music','YOUTUBE_PLAY','music'],
 ['Chrome khol','OPEN','chrome'],
 ['calculator kholo','OPEN','calculator'],
 ['ChatGPT open kar','OPEN','chatgpt'],
 ['Open Instagram','OPEN','instagram'],
 ['Instagram kholo','OPEN','instagram'],
 ['Insta open kar','OPEN','insta'],
 ['Open YT and play CarryMinati','YOUTUBE_PLAY','carryminati'],
 ['Open YouTube then play Arijit Singh','YOUTUBE_PLAY','arijit singh'],
 ['YouTube search CarryMinati','YOUTUBE_PLAY','carryminati'],
 ['Search CarryMinati on YouTube','YOUTUBE_PLAY','carryminati'],
 ['Search machine learning roadmap','WEB_SEARCH','machine learning roadmap'],
 ['Google search neural networks','WEB_SEARCH','neural networks'],
];
for(const [input,intent,entity] of cases){const r=classify(input);assert.equal(r.intent,intent,input);assert.equal((r.query||r.target).toLowerCase(),entity.toLowerCase(),input);console.log('PASS',input,'=>',r);}
console.log(`DNA deterministic router: ${cases.length}/${cases.length} passed`);
