# DNA.AI P6 Local Wake

No Picovoice account, access key, or cloud wake-word service is required.

The wake listener uses a constrained Windows System.Speech grammar rather than open dictation. On the target PC, a direct runtime test transcribed spoken “Hey DNA” as “AT&T”; P6 therefore includes that observed acoustic alias in the wake grammar. After wake detection, DNA stops the wake listener, says “Yes?”, runs a separate one-shot dictation recognizer for the command, executes the existing local/Gemini intent path, speaks the result, and rearms wake listening.

This is a pragmatic local Windows build, not a claim of Siri-grade universal wake-word accuracy. A future cross-user production build should replace the wake detector with a trained local ONNX wake-word model.
