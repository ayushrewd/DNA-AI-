# DNA.AI V15 — Voice Reliability Repair

Frontend is unchanged. This patch only repairs the post-wake command microphone path.

## Root cause addressed
V14 opened the high-accuracy command microphone only after the wake recognizer was stopped. If the user naturally began speaking immediately after “DNA”, the first word or whole short command could occur before the command stream was ready. V15 keeps one Whisper microphone stream open and maintains a rolling ~1.4 s pre-buffer, so the wake-to-command handoff does not discard immediate speech.

The speech gate was also too aggressive for quiet laptop microphones. V15 lowers/adapts the energy threshold while retaining silence endpointing.

## Intentionally unchanged
- Approved frontend/HUD
- Working wake phrase behavior
- Router/actions/browser/brain

## First test
Say “DNA”, then naturally say “Open Instagram”. You should not need an exaggerated pause.
