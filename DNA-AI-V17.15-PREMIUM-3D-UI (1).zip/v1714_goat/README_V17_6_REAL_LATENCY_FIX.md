# DNA.AI V17.6 — Real Latency Fix

Focused on measured architectural latency rather than cosmetic timeout tweaks.

- Wake overlay no longer steals keyboard focus from the dashboard input.
- Known Windows apps return immediately after launch; process verification is asynchronous.
- YouTube automation reuses an existing YouTube page and uses bounded shorter waits.
- Ollama prefers fast 3B non-thinking models before 4B models, disables thinking where supported, uses 2K context and shorter history.
- Existing MIC toggle, wake word, anti-loop, sleep, Hinglish router and voice path preserved.
