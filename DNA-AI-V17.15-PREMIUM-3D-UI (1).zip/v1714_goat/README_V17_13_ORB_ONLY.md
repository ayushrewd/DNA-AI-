# DNA.AI V17.13 — Orb Only / Dark UI

UI-only refinement of the V17.11 working baseline.

- Assistant overlay is now ONLY the floating DNA orb.
- Removed overlay card, transcript, READY label, close button and command-center link.
- Overlay window reduced from 560x220 to 190x190 and made non-focusable.
- Orb animates differently for listening, processing and speaking states.
- Main HUD background/panels are substantially darker with restrained cyan glow.
- Voice, wake-word, TTS, command routing and assistant logic were not replaced.

Keep your known-good V17.11 ZIP as the golden rollback copy.
