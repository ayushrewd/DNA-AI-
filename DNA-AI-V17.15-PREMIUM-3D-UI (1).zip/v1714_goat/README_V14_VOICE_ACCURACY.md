# DNA.AI V14 — Voice Accuracy Fix

Frontend is unchanged. This build changes only the post-wake command listening path.

## What changed
- Wake word behavior remains as-is.
- Actual commands never fall back to Windows Dictation.
- A single persistent faster-whisper worker is preloaded before wake listening starts.
- Default command model is multilingual `medium` for better Indian-English/Hinglish accuracy.
- 500 ms audio pre-roll prevents clipping the first word after wake.
- Longer endpoint silence (850 ms) prevents cutting commands too early.
- Stronger command/name context for ChatGPT, Instagram, YouTube, CarryMinati, WhatsApp, VS Code, Spotify, Chrome, Ollama and Hinglish verbs.
- Whisper decoding uses deterministic temperature 0 and stronger beam search.
- If Whisper is unavailable, DNA reports the voice-engine failure instead of silently using lower-accuracy command dictation.

## First launch
The Whisper medium model may need to download/cache on first use. Wait until the HUD no longer shows VOICE_MODEL_LOADING before saying the wake word.

## Acceptance test
Say `DNA`, then naturally say `Open Instagram`. The transcript shown by DNA should match the command closely and Instagram should open.
