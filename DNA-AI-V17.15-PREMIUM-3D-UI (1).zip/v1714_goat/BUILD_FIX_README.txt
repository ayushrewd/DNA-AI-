DNA.AI V8.1.1 build fix

The previous V8.1 verifier ran tsc across 53 unused template UI files, producing 104 type errors before Vite could build the actual application dependency graph. V8.1.1 verifies Electron runtime JavaScript syntax and the real Vite production bundle, then packages that exact bundle with electron-builder.
