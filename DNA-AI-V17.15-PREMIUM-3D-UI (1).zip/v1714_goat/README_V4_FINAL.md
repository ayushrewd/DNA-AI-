# DNA.AI Canonical V4 — Final Candidate

This is the single source tree to test and improve. It is not a claim that desktop-agent research is solved.

## What V4 changes over V3

- Optional **local multilingual Whisper STT** (`faster-whisper`) for English/Hindi/Hinglish. When installed, both wake detection and command transcription use the local model. Windows System.Speech remains an emergency fallback only.
- Optional **natural Indian neural TTS** via Python `edge-tts`, avoiding the npm package that previously blocked reproducible builds. Gemini TTS and Windows TTS remain fallbacks.
- **Multi-action local plans**: commands such as `Chrome kholo aur YouTube kholo` are split, executed sequentially, logged, and stopped on failure.
- Existing **local-first router** remains authoritative: OS actions do not need Gemini.
- Existing **action verification**, Windows structured UI adapter, screen vision, persistent browser profile, WhatsApp confirmation, ChatGPT image download, web research, memory, Ollama fallback, tray/autostart and installer remain.
- Health state now reports whether STT is `WHISPER_LOCAL` or `WINDOWS_FALLBACK`.

## Local voice setup

Run `SETUP_LOCAL_VOICE.bat` once. It installs Python-side voice dependencies. The first Whisper use downloads the selected model. Default is `small`; set `DNA_WHISPER_MODEL=medium` for more accuracy if the machine is powerful enough.

This setup is intentionally separate from the core installer because Whisper model size/performance is hardware-dependent.

## Security model

DNA does not receive blanket administrator access. Sending messages, destructive actions, credentials, and high-impact operations must remain permission/confirmation gated. Browser authentication lives in DNA's persistent browser profile and must be treated as sensitive.

## Runtime acceptance bar

Do not call the build successful until these pass on the target Windows PC:

1. App starts from installer without npm/Vite.
2. `open calculator` works with AI quota unavailable.
3. `Hey DNA` wakes locally.
4. Hinglish command transcription is accurate enough for normal use.
5. DNA speaks through neural TTS.
6. `Chrome kholo aur YouTube kholo` executes both actions.
7. A file-search command returns a real existing file.
8. Screen analysis describes the actual current desktop.
9. WhatsApp drafts the intended contact/message and only sends after confirmation.
10. ChatGPT image download saves a real file and reports its path.
11. A failed action is reported as failed rather than falsely saying “done”.
