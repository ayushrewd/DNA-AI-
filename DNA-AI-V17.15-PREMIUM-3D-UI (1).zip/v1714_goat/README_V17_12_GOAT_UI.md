# DNA.AI V17.12 — GOAT UI

Frontend-only visual upgrade based on the working V17.11 Single Female Voice build.

- V17.11 voice, wake, TTS, routing, commands, mic toggle and backend logic are preserved.
- New right-side Siri-style floating 3D DNA orb overlay.
- Orb visually reacts to listening, thinking and speaking states already emitted by V17.11.
- Premium glass HUD polish with no new AI/runtime dependencies.
- No Ollama, PyTorch, image generation or screen-intelligence additions.

The only Electron change is overlay window positioning on the active display.
