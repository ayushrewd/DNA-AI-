# DNA.AI V17.15 — Premium UI Remaster
Visual-only patch over V17.14. No voice, command router, TTS, Electron services, Python bridges, or dependencies changed.

- True near-black main canvas and panels
- Brighter electric sky-blue highlights
- Central HUD uses real CSS perspective + mouse parallax and separated Z-depth layers
- Premium panel elevation and button press/hover depth
- Orb remains orb-only with transparent surrounding page and stronger spherical shading
