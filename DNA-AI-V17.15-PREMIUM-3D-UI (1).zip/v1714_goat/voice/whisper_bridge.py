"""DNA.AI local multilingual speech bridge v5.
Local-first Hinglish/English/Hindi STT with adaptive end-of-speech detection.
Uses faster-whisper + sounddevice. Audio stays on device.
Modes: wake | command
"""
import argparse, os, sys, time, tempfile, wave, re, queue, subprocess, threading
from collections import deque
import numpy as np
try:
    import sounddevice as sd
    from faster_whisper import WhisperModel
except Exception as e:
    print('DNA_ERROR|LOCAL_STT_DEPENDENCIES_MISSING|' + str(e), flush=True); sys.exit(2)

RATE=16000; BLOCK=1600
MODEL_NAME=os.environ.get('DNA_WHISPER_MODEL','small')
def auto_device():
    forced=os.environ.get('DNA_WHISPER_DEVICE','').strip()
    if forced: return forced
    try:
        subprocess.run(['nvidia-smi'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2, check=True)
        return 'cuda'
    except Exception:
        return 'cpu'
DEVICE=auto_device()
COMPUTE=os.environ.get('DNA_WHISPER_COMPUTE','int8' if DEVICE=='cpu' else 'float16')
def load_model():
    global DEVICE, COMPUTE
    try:
        return WhisperModel(MODEL_NAME, device=DEVICE, compute_type=COMPUTE)
    except Exception as e:
        print('DNA_WARN|GPU_STT_FALLBACK|' + str(e), flush=True)
        DEVICE='cpu'; COMPUTE='int8'
        return WhisperModel(os.environ.get('DNA_WHISPER_CPU_MODEL','small'), device='cpu', compute_type='int8')
model=load_model()

def rms(a):
    x=a.astype(np.float32); return float(np.sqrt(np.mean(x*x))) if len(x) else 0.0

def capture_utterance(max_seconds=8.0, start_timeout=5.0, silence_seconds=0.85):
    """Energy-gated capture with pre-roll so the first word is never clipped."""
    from collections import deque
    q=queue.Queue(); chunks=[]; started=False; quiet=0.0; t0=time.time(); noise=[]
    preroll=deque(maxlen=5)  # ~0.5 s at 100 ms blocks
    def cb(indata, frames, ti, status): q.put(indata[:,0].copy())
    with sd.InputStream(samplerate=RATE, channels=1, dtype='int16', blocksize=BLOCK, callback=cb):
        while time.time()-t0 < max_seconds:
            try: a=q.get(timeout=.4)
            except queue.Empty: continue
            level=rms(a)
            if not started:
                preroll.append(a.copy())
                noise.append(level); noise=noise[-12:]
                baseline=float(np.median(noise)) if noise else 100.0
                threshold=max(220.0, baseline*3.0)
                if level >= threshold:
                    started=True; chunks.extend(list(preroll)); quiet=0.0
                elif time.time()-t0 >= start_timeout: break
            else:
                chunks.append(a)
                baseline=float(np.median(noise)) if noise else 100.0
                threshold=max(180.0, baseline*2.0)
                quiet = quiet + len(a)/RATE if level < threshold else 0.0
                if quiet >= silence_seconds and sum(len(x) for x in chunks) >= int(.45*RATE): break
    return np.concatenate(chunks) if chunks else np.zeros(0,dtype=np.int16)

def transcribe(audio, hotwords='DNA, Hey DNA, ChatGPT, CarryMinati, YouTube, calculator, Chrome, WhatsApp, VS Code, Spotify, open, play, search'):
    if len(audio)<RATE//5: return ''
    fd,name=tempfile.mkstemp(suffix='.wav'); os.close(fd)
    try:
        with wave.open(name,'wb') as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(RATE); w.writeframes(audio.tobytes())
        kwargs=dict(beam_size=1, best_of=1, vad_filter=True, condition_on_previous_text=False, temperature=0.0,
                    initial_prompt='DNA desktop assistant. Transcribe exactly what the user says. The speaker uses Indian English and Hinglish. Common commands and names: open, kholo, khol, chala, chalao, laga, search, ChatGPT, Instagram, Insta, YouTube, CarryMinati, calculator, Chrome, WhatsApp, VS Code, Spotify, Ollama. Preserve names and do not translate Hinglish.',
                    vad_parameters=dict(min_silence_duration_ms=320, speech_pad_ms=180))
        # Newer faster-whisper supports hotwords; keep compatibility with older installs.
        global model, DEVICE, COMPUTE
        try:
            try: segs,info=model.transcribe(name, hotwords=hotwords, **kwargs)
            except TypeError: segs,info=model.transcribe(name, **kwargs)
            return ' '.join(s.text.strip() for s in segs).strip()
        except Exception as e:
            # RTX drivers can be present while CUDA runtime DLLs required by CTranslate2 are not.
            # Fall back once to a smaller CPU model instead of making DNA deaf.
            if DEVICE == 'cuda':
                print('DNA_WARN|CUDA_TRANSCRIBE_FALLBACK|' + str(e), flush=True)
                DEVICE='cpu'; COMPUTE='int8'
                model=WhisperModel(os.environ.get('DNA_WHISPER_CPU_MODEL','small'), device='cpu', compute_type='int8')
                try: segs,info=model.transcribe(name, hotwords=hotwords, **kwargs)
                except TypeError: segs,info=model.transcribe(name, **kwargs)
                return ' '.join(s.text.strip() for s in segs).strip()
            raise
    finally:
        try: os.unlink(name)
        except: pass

def norm(s): return re.sub(r'[^a-z0-9 ]+',' ',s.lower()).strip()
def is_wake(t):
    n=norm(t); aliases=('hey dna','hey d n a','hi dna','okay dna','ok dna','dna ai','dna')
    return any(a in n for a in aliases)

def wake_loop():
    print('DNA_READY',flush=True)
    while True:
        try:
            a=capture_utterance(max_seconds=4.5,start_timeout=3.0,silence_seconds=.45)
            t=transcribe(a,'Hey DNA, DNA AI')
            if t: print('DNA_HEARD|'+t,flush=True)
            if t and is_wake(t): print('DNA_WAKE|0.95|'+t,flush=True); return
        except KeyboardInterrupt: return
        except Exception as e: print('DNA_ERROR|'+str(e),flush=True); time.sleep(.4)

def command_once(seconds):
    print('DNA_COMMAND_READY',flush=True)
    try:
        a=capture_utterance(max_seconds=seconds,start_timeout=min(4.5,seconds),silence_seconds=.75)
        t=transcribe(a)
        if t: print('DNA_COMMAND|0.95|'+t,flush=True)
        else: print('DNA_COMMAND_TIMEOUT',flush=True)
    except Exception as e: print('DNA_COMMAND_ERROR|'+str(e),flush=True)


def server_loop():
    """Persistent STT + persistent microphone worker.

    The microphone stream stays open even while Electron is listening for the wake word.
    A rolling pre-buffer preserves speech that starts immediately after "DNA", so the first
    word is not lost while Electron kills the wake recognizer and switches state.
    """
    audio_q=queue.Queue(maxsize=240)
    ring=deque(maxlen=14)  # ~1.4 seconds of audio before CAPTURE
    ring_lock=threading.Lock()

    def mic_cb(indata, frames, ti, status):
        a=indata[:,0].copy()
        with ring_lock:
            ring.append(a)
        try:
            audio_q.put_nowait(a)
        except queue.Full:
            try: audio_q.get_nowait()
            except queue.Empty: pass
            try: audio_q.put_nowait(a)
            except queue.Full: pass

    try:
        mic=sd.query_devices(kind='input')
        mic_name=str(mic.get('name','default microphone')).replace('|',' ')
        stream=sd.InputStream(samplerate=RATE, channels=1, dtype='int16', blocksize=BLOCK, callback=mic_cb)
        stream.start()
    except Exception as e:
        print('DNA_ERROR|MIC_OPEN_FAILED|' + str(e), flush=True)
        return

    print('DNA_SERVER_READY|%s|%s|%s|%s' % (MODEL_NAME, DEVICE, COMPUTE, mic_name), flush=True)

    def capture_from_live_stream(max_seconds=9.0, start_timeout=5.0, silence_seconds=.9):
        # Drop stale queued blocks, but retain the rolling ring so words spoken immediately
        # after the wake phrase survive the recognizer handoff.
        try:
            while True: audio_q.get_nowait()
        except queue.Empty:
            pass
        with ring_lock:
            pre=list(ring)
        chunks=list(pre)
        started=False; quiet=0.0; t0=time.time(); noise=[]
        # Check the prebuffer for recent speech. We only use it as pre-roll; fresh audio still
        # decides the endpoint, avoiding old wake-word audio becoming the command.
        while time.time()-t0 < max_seconds:
            try: a=audio_q.get(timeout=.35)
            except queue.Empty: continue
            level=rms(a)
            if not started:
                noise.append(level); noise=noise[-10:]
                baseline=float(np.median(noise)) if noise else 80.0
                # Less aggressive than V14: laptop mics + soft speech were often below the
                # old 3x-noise gate and DNA looked deaf even though the mic was working.
                threshold=max(110.0, baseline*1.65)
                if level >= threshold:
                    started=True
                    chunks.append(a); quiet=0.0
                elif time.time()-t0 >= start_timeout:
                    return np.zeros(0,dtype=np.int16)
            else:
                chunks.append(a)
                baseline=float(np.median(noise)) if noise else 80.0
                threshold=max(95.0, baseline*1.35)
                quiet = quiet + len(a)/RATE if level < threshold else 0.0
                if quiet >= silence_seconds and sum(len(x) for x in chunks) >= int(.55*RATE):
                    break
        return np.concatenate(chunks) if chunks else np.zeros(0,dtype=np.int16)

    try:
        for raw in sys.stdin:
            line=raw.strip()
            if not line: continue
            if line == 'QUIT': break
            if line.startswith('CAPTURE'):
                parts=line.split('|')
                try: seconds=float(parts[1]) if len(parts)>1 else 9.0
                except: seconds=9.0
                print('DNA_COMMAND_READY', flush=True)
                try:
                    a=capture_from_live_stream(max_seconds=seconds,start_timeout=min(2.5,seconds),silence_seconds=.42)
                    t=transcribe(a)
                    if t: print('DNA_COMMAND|0.95|'+t,flush=True)
                    else: print('DNA_COMMAND_TIMEOUT',flush=True)
                except Exception as e:
                    print('DNA_COMMAND_ERROR|'+str(e),flush=True)
    finally:
        try: stream.stop(); stream.close()
        except Exception: pass

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('mode',choices=['wake','command','server']); p.add_argument('--seconds',type=float,default=9.0); a=p.parse_args()
    wake_loop() if a.mode=='wake' else (server_loop() if a.mode=='server' else command_once(a.seconds))
