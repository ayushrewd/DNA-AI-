# DNA.AI dedicated wake word

Put the Windows Porcupine custom keyword model here as:

`hey-dna_windows.ppn`

Create the custom phrase **Hey DNA** in Picovoice Console and download the **Windows** model.
The model file is intentionally not bundled because it is generated for the developer's Picovoice configuration.
