import asyncio, os, sys, tempfile
try:
 import edge_tts
except Exception as e:
 print('ERR:'+str(e),file=sys.stderr); sys.exit(2)
async def main():
 text=sys.stdin.read().strip()
 voice='en-IN-NeerjaNeural'  # DNA.AI single female voice; intentionally locked
 out=sys.argv[1]
 c=edge_tts.Communicate(text,voice,rate=os.environ.get('DNA_TTS_RATE','+12%'))
 await c.save(out)
asyncio.run(main())
