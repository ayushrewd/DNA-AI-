# DNA.AI V6 acceptance tests

1. Reboot/login: DNA starts in tray without opening a noisy console.
2. 20/20 quiet-room `Hey DNA` attempts; log false wakes for 30 minutes.
3. One-breath: `Hey DNA, calculator kholo` opens Calculator without asking `Haan, bol?` first.
4. Two-turn: `Hey DNA` -> acknowledgement -> `Chrome kholo` works.
5. Hinglish STT: 20 mixed Hindi/English commands; record word/intent failures.
6. Gemini/cloud unavailable: local apps/files/volume still work.
7. Natural TTS sounds acceptable and does not route local actions through chat AI.
8. Five conversational follow-ups preserve context and DNA identity.
9. Memory survives restart; relevant recall beats unrelated saved memories; forget removes it.
10. Multi-action: `Chrome kholo aur YouTube kholo` executes sequentially and reports partial failure honestly.
11. Known app launch is process-verified; failed launch never says `Done`.
12. File search returns only existing paths.
13. Browser accessibility inspection/click works on a normal website.
14. ChatGPT download requires user-authenticated persistent profile and verifies downloaded file exists.
15. WhatsApp resolves intended contact, drafts first, and requires explicit send confirmation.
16. Screen analysis describes visible state but never claims an unexecuted action.
17. Sensitive/destructive intents appear in audit log with risk class.
18. Kill/restart browser agent and voice engine; DNA recovers without reinstall.
19. Run for 2 hours idle; check CPU/RAM growth and false wake rate.
20. Run `npm run verify`; all syntax, TypeScript and Vite build checks pass.

## V7 image/brain tests
21. With Gemini key absent and Ollama running, normal conversation uses local brain.
22. With ComfyUI + checkpoint running: `create an image of a futuristic Delhi at night` saves a real image to Downloads.
23. Hinglish: `DNA helix ka futuristic wallpaper banao` creates and saves an image.
24. Stop ComfyUI and retry image generation: DNA reports local image engine unavailable instead of claiming success.
25. Gemini quota exhausted: local Windows actions and local image generation remain usable.
