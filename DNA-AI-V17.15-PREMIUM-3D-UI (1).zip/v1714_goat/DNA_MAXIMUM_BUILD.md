# DNA.AI Maximum Build — V3

This is the canonical Windows desktop-agent branch produced from GOAT V2 after a source review.

## Architecture upgrades
- Local-first command execution remains independent of cloud AI quota.
- Action verification for known Windows apps: DNA checks that the target process actually appears before reporting verified success.
- Structured Windows UI Automation adapter: if Microsoft's `winapp` CLI is installed, DNA can inspect and invoke accessible controls instead of relying only on screen coordinates.
- Browser research now opens and reads current source pages instead of grounding answers only on search-result snippets.
- Long-term memory retrieval now combines lexical relevance, explicit-memory priority, and recency.
- Natural voice remains provider-independent: Edge neural TTS first, optional Gemini TTS second, Windows speech only as emergency fallback.
- Persistent authenticated browser profile remains isolated under DNA's app data.
- WhatsApp drafts still require a confirmation step before browser-agent sending.
- Added local volume, mute and lock controls.

## Runtime truth
Source-level syntax/build checks can be run with `npm run verify`. Windows microphone accuracy, installed-app discovery, UI Automation availability, authenticated website DOM changes, and real-device audio latency must still be verified on the target Windows machine.

## Known hard limit
The current bundled wake/command recognizer still falls back to Windows System.Speech. The architecture is ready for a dedicated multilingual STT/wake sidecar, but shipping a large speech model inside this small source archive without testing it on the target hardware would be misleading. A Whisper-class multilingual engine is the next replacement for production Hinglish input.
