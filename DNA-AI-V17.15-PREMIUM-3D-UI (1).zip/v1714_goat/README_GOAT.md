# DNA.AI — GOAT Canonical Build 2.0

This is the single canonical DNA.AI source tree. It preserves the approved React HUD and the verified Electron/local-command foundation, while upgrading the brain layer.

## What is real in this build
- Electron Windows desktop app and installer configuration
- Local-first app/file/browser commands
- Persistent background/tray architecture
- Wake/voice prototype plus neural TTS path
- Gemini conversational brain
- Optional Ollama local-brain fallback
- Multi-turn session context
- Explicit persistent long-term memory
- Browser research workflow
- Persistent browser profile for user-authenticated workflows
- WhatsApp draft/send confirmation workflow
- ChatGPT download workflow foundation

## What is not honestly “solved” yet
- Frontier-model weights/data are not bundled and cannot be copied from ChatGPT.
- Current Windows wake/STT remains below Siri-level Hinglish accuracy.
- Arbitrary computer use is not safe/reliable enough to execute without a permission and UI-grounding layer.
- Singing requires a dedicated music/singing model, not normal TTS.

Do not call unverified capabilities complete. Build and runtime-test on Windows.
