@echo off
setlocal
cd /d "%~dp0"
title DNA.AI V16 Packaged Voice Repair Builder
echo ========================================
echo     DNA.AI V16 PACKAGED VOICE REPAIR BUILD
echo ========================================
where node >nul 2>nul || (echo ERROR: Node.js is required.& pause & exit /b 1)
where py >nul 2>nul || where python >nul 2>nul || (echo ERROR: Python 3.10+ is required.& pause & exit /b 1)
echo [1/5] Installing Node dependencies...
call npm install
if errorlevel 1 goto :fail
echo [2/5] Installing local voice engine...
call SETUP_LOCAL_VOICE.bat --no-pause
if errorlevel 1 goto :fail
echo [3/5] Verifying source and deterministic router...
call npm run verify
if errorlevel 1 goto :fail
echo [4/5] Packaging Windows installer...
call npx electron-builder --win nsis
if errorlevel 1 goto :fail
echo [5/5] Done.
echo SUCCESS: release\DNA.AI-Setup-16.0.0.exe
explorer release
pause
exit /b 0
:fail
echo.
echo BUILD FAILED. Screenshot the FIRST error block above.
pause
exit /b 1
