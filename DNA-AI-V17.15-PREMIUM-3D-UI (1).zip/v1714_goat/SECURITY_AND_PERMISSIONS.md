# DNA.AI security model

DNA is powerful by capability, not by giving the language model unrestricted administrator access.

- Read-only/local low-risk actions may run directly.
- External communications are drafted first and require explicit confirmation before browser-agent sending.
- Destructive operations are not exposed as generic model tools in this build.
- API keys use Electron safeStorage when available.
- Browser login state lives in DNA's private app-data profile and must never be committed or exported casually.
- DNA should report success only after the executor or verifier reports success.
- Raw provider errors belong in logs, not user-facing personality responses.
