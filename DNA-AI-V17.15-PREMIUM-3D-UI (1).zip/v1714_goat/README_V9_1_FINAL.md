# DNA.AI V9.1 Capability-First Rebuild

This build removes the most damaging failure mode from earlier builds: conversational AI is not allowed to pretend that desktop actions succeeded.

## First-launch behavior
- Starts in the tray and automatically attempts to install local `faster-whisper`, `sounddevice`, `numpy`, and `edge-tts` through the detected Python launcher.
- Accurate local STT becomes primary when available; Windows Speech remains fallback only.
- The Whisper model is downloaded on first local voice start, so the first start can take time.

## Deterministic actions
- `Open ChatGPT` -> direct ChatGPT URL.
- `Play CarryMinati on YouTube` -> controlled Edge session -> YouTube results -> first video -> playback verification.
- WhatsApp explicit send phrases use the persistent controlled WhatsApp Web session and verify an outgoing message bubble before reporting success.
- Failed verification returns failure; it must not print `[OK]`.

## Reality / limitations
- WhatsApp Web and ChatGPT browser features require one-time sign-in in DNA.AI's persistent browser profile.
- A strong general conversational brain still needs either a working local Ollama model or a configured cloud provider. No desktop app can legally bundle ChatGPT's/OpenAI's private model weights or unlimited cloud inference.
- Image generation needs a configured local image backend.
- This source was syntax-checked for Electron/Node and Python in the build environment; Windows runtime acceptance must still be tested on Windows.
