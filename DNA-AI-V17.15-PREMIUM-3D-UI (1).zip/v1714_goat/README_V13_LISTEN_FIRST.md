# DNA.AI V13 — Listen First Recovery

This build deliberately prioritizes the one thing a voice assistant cannot fake: hearing the command.

## What changed
- Frontend is unchanged.
- Fixed the cold-start deaf window: DNA no longer waits for Whisper to finish loading *after* wake detection before opening the microphone.
- Whisper prewarms in the background. If it is warm, commands use persistent local Whisper. If not, the command is captured immediately using Windows dictation rather than being lost.
- Default local Whisper model changed from `medium` to multilingual `small` for much faster startup on a 16 GB / RTX 4050 laptop. It still supports Indian English/Hinglish; CUDA is used when available and CPU remains a fallback.
- The persistent worker reports the actual default input-device name in its startup line for diagnosis.
- Added Instagram as a deterministic website target (`open Instagram`, `Instagram kholo`, `open Insta`).
- Added common command phrases to the immediate Windows fallback grammar, including ChatGPT, Instagram, CarryMinati/YouTube and music.

## First acceptance test
1. Launch DNA.AI and wait until the HUD says it is ready.
2. Say `DNA`.
3. Say `Open Instagram`.
4. Then test `DNA` → `Open calculator`.

The first command must be captured immediately even if Whisper is still warming.
