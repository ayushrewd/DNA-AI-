const { app, BrowserWindow, ipcMain, shell, clipboard, Tray, Menu, nativeImage, safeStorage, Notification, screen } = require('electron');
const path = require('node:path');
const os = require('node:os');
const { spawn, execFile } = require('node:child_process');
const https = require('node:https');
const fs = require('node:fs');
const { BrowserAgent } = require('./browser-agent.cjs');
const { DNABrain } = require('./brain.cjs');
const { WindowsAgent } = require('./windows-agent.cjs');
const { RuntimeGuard } = require('./runtime-guard.cjs');
const { ImageAgent } = require('./image-agent.cjs');
const { DNAScheduler, parseScheduleCommand } = require('./scheduler.cjs');
const { parseYouTube, parseSearch, parseOpen } = require('./intent-router.cjs');

const isDev = !app.isPackaged;
let mainWindow;
let assistantWindow = null;
let setupWindow = null;
let tray = null;
let isQuitting = false;
const launchedInBackground = process.argv.includes('--background');
let voiceProcess = null;
let sttWorker = null;
let sttWorkerReady = false;
let sttCapturePending = null;
let voiceState = { state: 'STOPPED', lastTranscript: '', lastError: '', recognizer: 'DNA Local Voice', wakeWord: 'DNA', wakeDetectedAt: null };
let wakeArmedUntil = 0;
let isSpeaking = false;
let lastSpokenText = '';
let lastSpokenAt = 0;
let sleepingMode = false;
let lastVoiceTranscript = '';
let lastVoiceTranscriptAt = 0;
let wakeTimer = null;
let browserAgent = null;
let pendingConfirmation = null;
let dnaBrain = null;
const windowsAgent = new WindowsAgent();
let runtimeGuard = null;
let imageAgent = null;
let dnaScheduler = null;
const WAKE_COMMAND_WINDOW_MS = 12000;

function loadLocalEnv() {
  const envPath = path.join(__dirname, '..', '.env');
  if (!fs.existsSync(envPath)) return;
  for (const rawLine of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq < 1) continue;
    const key = line.slice(0, eq).trim();
    let value = line.slice(eq + 1).trim();
    if ((value.startsWith('\"') && value.endsWith('\"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    if (!process.env[key]) process.env[key] = value;
  }
}
loadLocalEnv();

function configPath() { return path.join(app.getPath('userData'), 'dna-config.json'); }
function readConfig() {
  try { return JSON.parse(fs.readFileSync(configPath(), 'utf8')); } catch { return {}; }
}
function writeConfig(next) {
  fs.mkdirSync(path.dirname(configPath()), { recursive: true });
  fs.writeFileSync(configPath(), JSON.stringify(next, null, 2), 'utf8');
}
function getStoredApiKey() {
  if (process.env.GEMINI_API_KEY) return process.env.GEMINI_API_KEY;
  const cfg = readConfig();
  if (!cfg.apiKey) return '';
  try {
    if (cfg.apiKeyEncrypted && safeStorage.isEncryptionAvailable()) return safeStorage.decryptString(Buffer.from(cfg.apiKey, 'base64'));
    return cfg.apiKey;
  } catch { return ''; }
}
function saveApiKey(value) {
  const key = String(value || '').trim();
  const cfg = readConfig();
  if (!key) { delete cfg.apiKey; delete cfg.apiKeyEncrypted; writeConfig(cfg); return true; }
  if (safeStorage.isEncryptionAvailable()) {
    cfg.apiKey = safeStorage.encryptString(key).toString('base64');
    cfg.apiKeyEncrypted = true;
  } else {
    cfg.apiKey = key; cfg.apiKeyEncrypted = false;
  }
  writeConfig(cfg); return true;
}

const APP_COMMANDS = {
  calculator: ['calc.exe'], calc: ['calc.exe'], notepad: ['notepad.exe'], explorer: ['explorer.exe'], 'file explorer': ['explorer.exe'],
  cmd: ['cmd.exe'], 'command prompt': ['cmd.exe'], powershell: ['powershell.exe'], 'task manager': ['taskmgr.exe'], taskmanager: ['taskmgr.exe'],
  chrome: ['cmd.exe', '/c', 'start', '', 'chrome'], edge: ['cmd.exe', '/c', 'start', '', 'msedge'], firefox: ['cmd.exe', '/c', 'start', '', 'firefox'],
  'vs code': ['cmd.exe', '/c', 'start', '', 'code'], vscode: ['cmd.exe', '/c', 'start', '', 'code'], spotify: ['cmd.exe', '/c', 'start', '', 'spotify:'],
  whatsapp: ['cmd.exe', '/c', 'start', '', 'whatsapp:'],
  discord: ['cmd.exe','/c','start','','discord:'], telegram: ['cmd.exe','/c','start','','tg:'], paint: ['mspaint.exe'], terminal: ['cmd.exe','/c','start','','wt'], 'windows terminal': ['cmd.exe','/c','start','','wt']
};
const URLS = { youtube: 'https://youtube.com', gmail: 'https://mail.google.com', github: 'https://github.com', google: 'https://google.com', chatgpt: 'https://chatgpt.com', whatsapp: 'https://web.whatsapp.com', spotify: 'https://open.spotify.com', instagram: 'https://www.instagram.com' };

function launch(command) { const [exe, ...args] = command; const child = spawn(exe, args, { detached: true, stdio: 'ignore', windowsHide: false }); child.unref(); }
function normalizeTarget(s) {
  return String(s || '')
    .toLowerCase()
    .replace(/[“”"'`]/g, '')
    .replace(/[.,!?;:]+$/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

const TARGET_ALIASES = {
  'calculator app': 'calculator', 'windows calculator': 'calculator', 'calc': 'calculator',
  'notepad app': 'notepad', 'windows notepad': 'notepad',
  'file manager': 'file explorer', 'files': 'file explorer',
  'visual studio code': 'vs code', 'v s code': 'vs code', 'code': 'vs code',
  'google chrome': 'chrome', 'microsoft edge': 'edge',
  'you tube': 'youtube', 'yt': 'youtube',
  'whats app': 'whatsapp',
  'insta': 'instagram', 'instagram app': 'instagram'
};

function resolveTarget(raw) {
  const normalized = normalizeTarget(raw);
  return TARGET_ALIASES[normalized] || normalized;
}


function psQuote(value) { return `'${String(value).replace(/'/g, "''")}'`; }
function runPowerShell(script, timeout = 12000) {
  return new Promise((resolve, reject) => {
    execFile('powershell.exe', ['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-Command', script], { windowsHide:true, timeout, maxBuffer:1024*1024 }, (error, stdout, stderr) => {
      if (error) return reject(new Error(String(stderr || error.message).trim()));
      resolve(String(stdout || '').trim());
    });
  });
}
function rememberEvent(kind, payload) {
  try {
    const file = path.join(app.getPath('userData'), 'dna-history.json');
    let rows=[]; try { rows=JSON.parse(fs.readFileSync(file,'utf8')); if(!Array.isArray(rows)) rows=[]; } catch {}
    rows.push({ at:new Date().toISOString(), kind, ...payload });
    if(rows.length>250) rows=rows.slice(-250);
    fs.writeFileSync(file, JSON.stringify(rows,null,2),'utf8');
  } catch {}
}
function normalizeLocalSpeech(text) {
  return normalizeTarget(text)
    .replace(/^dna[ ,]+/, '')
    .replace(/\bplease\b/g,'')
    .replace(/\b(zara|jara|bhai|bro)\b/g,'')
    .replace(/\s+/g,' ').trim();
}
async function findFiles(query) {
  const q=String(query||'').trim(); if(!q) return [];
  const roots=[app.getPath('desktop'),app.getPath('documents'),app.getPath('downloads')].filter(Boolean);
  const script=`$ErrorActionPreference='SilentlyContinue'; $roots=@(${roots.map(psQuote).join(',')}); $q=${psQuote(q)}; Get-ChildItem -Path $roots -File -Recurse -Force | Where-Object { $_.Name -like ('*'+$q+'*') } | Sort-Object LastWriteTime -Descending | Select-Object -First 8 FullName,Name,LastWriteTime | ConvertTo-Json -Compress`;
  try { const out=await runPowerShell(script,15000); if(!out)return[]; const parsed=JSON.parse(out); return Array.isArray(parsed)?parsed:[parsed]; } catch { return []; }
}
async function closeApp(target) {
  const t=resolveTarget(target).replace(/\.exe$/,'');
  const processAliases={ 'vs code':'Code',vscode:'Code','google chrome':'chrome',chrome:'chrome',edge:'msedge',firefox:'firefox',spotify:'Spotify',whatsapp:'WhatsApp',notepad:'Notepad',calculator:'CalculatorApp' };
  const proc=processAliases[t]||t;
  try { await runPowerShell(`Get-Process -Name ${psQuote(proc)} -ErrorAction Stop | Stop-Process`); return true; } catch { return false; }
}
async function openWhatsappMessage(phone, message) {
  const digits=String(phone||'').replace(/\D/g,'');
  if(digits.length<8) return false;
  await shell.openExternal(`https://wa.me/${digits}?text=${encodeURIComponent(message||'')}`); return true;
}


function contactsPath() { return path.join(app.getPath('userData'), 'dna-contacts.json'); }
function readContacts() { try { const v=JSON.parse(fs.readFileSync(contactsPath(),'utf8')); return v && typeof v==='object' ? v : {}; } catch { return {}; } }
function saveContacts(v) { fs.writeFileSync(contactsPath(), JSON.stringify(v,null,2),'utf8'); }
function normalizeContactName(v) { return String(v||'').toLowerCase().replace(/[^a-z0-9 ]/g,'').replace(/\s+/g,' ').trim(); }
function rememberContact(name, phone) {
  const digits=String(phone||'').replace(/\D/g,''); if(digits.length<8) return false;
  const c=readContacts(); c[normalizeContactName(name)]={ name:String(name).trim(), phone:digits }; saveContacts(c); return true;
}
function resolveContact(name) { return readContacts()[normalizeContactName(name)] || null; }
async function whatsappSendConfirmed(name, message) {
  const c=resolveContact(name); if(!c) return {ok:false,message:`I don't know ${name}'s number yet. Say: remember contact ${name} as +91...`};
  await shell.openExternal(`https://wa.me/${c.phone}?text=${encodeURIComponent(message||'')}`);
  // Explicit "send whatsapp" is treated as the user's send confirmation. Give WhatsApp time to focus, then press Enter.
  setTimeout(()=>runPowerShell(`Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('{ENTER}')`,5000).catch(()=>{}),3500);
  return {ok:true,message:`Sending your WhatsApp message to ${c.name}.`};
}
async function captureScreen() {
  const out=path.join(app.getPath('pictures'),`DNA-Screenshot-${Date.now()}.png`);
  const script=`Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; $b=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds; $bmp=New-Object System.Drawing.Bitmap $b.Width,$b.Height; $g=[System.Drawing.Graphics]::FromImage($bmp); $g.CopyFromScreen($b.Location,[System.Drawing.Point]::Empty,$b.Size); $bmp.Save(${psQuote(out)},[System.Drawing.Imaging.ImageFormat]::Png); $g.Dispose(); $bmp.Dispose()`;
  await runPowerShell(script,15000); return out;
}
async function analyzeScreen(question='Describe what is on my screen and identify the most relevant actionable UI elements.') {
  const key=getStoredApiKey(); if(!key) return {ok:false,message:'Screen understanding needs an AI vision provider configured.'};
  const file=await captureScreen();
  const b64=fs.readFileSync(file).toString('base64');
  const model=process.env.DNA_VISION_MODEL || process.env.GEMINI_MODEL || 'gemini-3.6-flash';
  const body={contents:[{role:'user',parts:[{text:`You are the vision subsystem of DNA.AI. Analyze this Windows desktop screenshot. ${question} Be precise. Do not claim an action occurred. If suggesting clicks, identify visible labels and approximate locations only when clear.`},{inline_data:{mime_type:'image/png',data:b64}}]}]};
  try{
    const res=await fetch(`https://generativelanguage.googleapis.com/v1/models/${encodeURIComponent(model)}:generateContent`,{method:'POST',headers:{'content-type':'application/json','x-goog-api-key':key},body:JSON.stringify(body)});
    const data=await res.json(); if(!res.ok) throw new Error(data?.error?.message||`Vision HTTP ${res.status}`);
    const message=data?.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join('').trim();
    return message?{ok:true,message,path:file}:{ok:false,message:'I could not understand the current screen.'};
  }catch(e){console.error('[DNA.AI][VISION]',e.message);return{ok:false,message:'My screen-understanding service is temporarily unavailable.'};}
}

async function clickScreen(x,y) {
  x=Math.round(Number(x)); y=Math.round(Number(y)); if(!Number.isFinite(x)||!Number.isFinite(y)) return false;
  const script=`Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public class DnaMouse { [DllImport("user32.dll")] public static extern bool SetCursorPos(int X,int Y); [DllImport("user32.dll")] public static extern void mouse_event(uint f,uint dx,uint dy,uint d,uint e); }'; [DnaMouse]::SetCursorPos(${x},${y})|Out-Null; Start-Sleep -Milliseconds 100; [DnaMouse]::mouse_event(2,0,0,0,0); [DnaMouse]::mouse_event(4,0,0,0,0)`;
  await runPowerShell(script); return true;
}
async function typeText(text) {
  const encoded=Buffer.from(String(text),'utf8').toString('base64');
  const script=`Add-Type -AssemblyName System.Windows.Forms; $t=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${encoded}')); [System.Windows.Forms.SendKeys]::SendWait($t.Replace('{','{{}').Replace('}','{}}'))`;
  await runPowerShell(script); return true;
}

function pythonExe() { return process.env.DNA_PYTHON || 'py'; }
function packagedResourcePath(...parts) {
  // Python cannot execute files through Electron's virtual app.asar filesystem.
  // Voice bridges are unpacked by electron-builder and must be resolved from
  // app.asar.unpacked in production. Development keeps the normal source path.
  if (app.isPackaged) return path.join(process.resourcesPath, 'app.asar.unpacked', ...parts);
  return path.join(__dirname, '..', ...parts);
}
function localVoiceBridge() { return packagedResourcePath('voice', 'whisper_bridge.py'); }
function localTtsBridge() { return packagedResourcePath('voice', 'edge_tts_bridge.py'); }
function localVoiceAvailable() {
  try { require('node:child_process').execFileSync(pythonExe(), ['-c','import faster_whisper, sounddevice, numpy'], {windowsHide:true,timeout:5000,stdio:'ignore'}); return fs.existsSync(localVoiceBridge()); } catch { return false; }
}

let voiceBootstrapPromise=null;
function bootstrapVoiceDependencies(){
  if(process.platform!=='win32' || localVoiceAvailable()) return Promise.resolve(true);
  if(voiceBootstrapPromise) return voiceBootstrapPromise;
  voiceState={...voiceState,state:'INITIALIZING',recognizer:'Installing accurate local voice',lastError:''}; emitVoice();
  voiceBootstrapPromise=new Promise(resolve=>{
    const args=['-m','pip','install','--disable-pip-version-check','--user','faster-whisper>=1.1.0','sounddevice>=0.5.0','numpy>=1.24,<3','edge-tts>=6.1.0'];
    const p=spawn(pythonExe(),args,{windowsHide:true,stdio:['ignore','ignore','pipe']}); let err='';
    p.stderr.on('data',d=>err+=d.toString());
    p.on('error',()=>resolve(false));
    p.on('exit',code=>{const ok=code===0&&localVoiceAvailable(); if(!ok) voiceState={...voiceState,state:'FAILED',lastError:'Accurate local voice setup failed. Python 3.10+ with pip is required.'}; emitVoice(); resolve(ok);});
  });
  return voiceBootstrapPromise;
}
async function edgeNaturalTts(text) {
  const file=path.join(app.getPath('temp'),`dna-edge-${Date.now()}.mp3`);
  await new Promise((resolve,reject)=>{
    const p=spawn(pythonExe(),[localTtsBridge(),file],{stdio:['pipe','ignore','pipe'],windowsHide:true}); let err='';
    p.stderr.on('data',d=>err+=d); p.on('error',reject); p.on('exit',c=>c===0?resolve(true):reject(new Error(err||`edge-tts exited ${c}`))); p.stdin.end(String(text).slice(0,1800));
  });
  await runPowerShell(`Add-Type -AssemblyName presentationCore; $m=New-Object system.windows.media.mediaplayer; $m.open([uri]${psQuote(file)}); $m.Play(); while(-not $m.NaturalDuration.HasTimeSpan){Start-Sleep -Milliseconds 100}; Start-Sleep -Milliseconds ([int]$m.NaturalDuration.TimeSpan.TotalMilliseconds+150); $m.Close()`,30000);
  try{fs.unlinkSync(file)}catch{} return true;
}

function wavBufferFromPcm(pcm, sampleRate=24000, channels=1, bits=16) {
  const header=Buffer.alloc(44); const byteRate=sampleRate*channels*bits/8; const blockAlign=channels*bits/8;
  header.write('RIFF',0); header.writeUInt32LE(36+pcm.length,4); header.write('WAVE',8); header.write('fmt ',12); header.writeUInt32LE(16,16); header.writeUInt16LE(1,20); header.writeUInt16LE(channels,22); header.writeUInt32LE(sampleRate,24); header.writeUInt32LE(byteRate,28); header.writeUInt16LE(blockAlign,32); header.writeUInt16LE(bits,34); header.write('data',36); header.writeUInt32LE(pcm.length,40); return Buffer.concat([header,pcm]);
}
async function geminiNaturalTts(text, style='') {
  const key=getStoredApiKey(); if(!key) throw new Error('Natural voice is not configured.');
  const voice=process.env.DNA_TTS_VOICE || 'Achird';
  const prompt=`# AUDIO PROFILE: DNA.AI\nA warm, youthful, intelligent Indian personal AI companion. Natural, friendly, never robotic.\n# DIRECTOR'S NOTES\nSpeak naturally in the language of the transcript. Hinglish should sound like a fluent Indian friend switching comfortably between Hindi and English. Keep acknowledgements short and human. ${style}\n# TRANSCRIPT\n${String(text).slice(0,1800)}`;
  const res=await fetch('https://generativelanguage.googleapis.com/v1beta/interactions',{method:'POST',headers:{'content-type':'application/json','x-goog-api-key':key,'Api-Revision':'2026-05-20'},body:JSON.stringify({model:process.env.DNA_TTS_MODEL||'gemini-3.1-flash-tts-preview',input:prompt,response_format:{type:'audio'},generation_config:{speech_config:[{voice}]}})});
  const data=await res.json(); if(!res.ok) throw new Error(data?.error?.message||`Natural TTS HTTP ${res.status}`);
  const b64=data?.output_audio?.data; if(!b64) throw new Error('Natural TTS returned no audio.');
  const file=path.join(app.getPath('temp'),`dna-voice-${Date.now()}.wav`); fs.writeFileSync(file,wavBufferFromPcm(Buffer.from(b64,'base64')));
  await runPowerShell(`$p=New-Object System.Media.SoundPlayer ${psQuote(file)}; $p.PlaySync()`,30000); try{fs.unlinkSync(file)}catch{} return true;
}

function looksLikeLocalCommand(text) {
  const lower = normalizeTarget(text);
  if (/^(?:create|generate|make|banao|bana do|image banao|photo banao)\b/i.test(lower) && /(?:image|photo|picture|wallpaper|poster|logo|banao|bana do)/i.test(lower)) return true;
  return /^(open|launch|start|run|play|close|find|search|copy|show|remember|send|screenshot|click|type|set|remind|timer|alarm)\b/.test(lower) || /\b(kholo|khol do|band karo|band kar do)$/.test(lower) ||
    /^(google|youtube) (search|pe search)\b/.test(lower) || /^search (google|youtube) for\b/.test(lower) || /^(whatsapp|message)\b/.test(lower);
}

async function localIntent(raw) {
  const command = String(raw || '').trim();
  const lower = normalizeLocalSpeech(command);

  // Sleep mode: stop active/follow-up command listening and return to wake-word-only mode.
  // The lightweight wake listener remains armed, so saying DNA/Hey DNA wakes the assistant again.
  if (/^(?:go to sleep|sleep|sleep mode|sleep now|so ja|so jao|so ja bhai|rest mode)$/i.test(lower)) {
    sleepingMode = true;
    return { handled:true, ok:true, message:'Going to sleep. Say Hey DNA when you need me.', intent:'SLEEP_MODE' };
  }
  const schedule = parseScheduleCommand(command);
  if (schedule && dnaScheduler) {
    const item=dnaScheduler.add(schedule);
    const when=new Date(item.at).toLocaleString([], {weekday:'short',hour:'numeric',minute:'2-digit'});
    return {handled:true,ok:true,message:`Done. ${item.type} set for ${when}.`,intent:'SCHEDULE_CREATE',data:item};
  }
  if (/^(?:show|list) (?:my )?(?:alarms|timers|reminders)|(?:alarms|reminders) (?:dikhao|batao)$/i.test(command)) {
    const rows=dnaScheduler?dnaScheduler.list():[];
    return {handled:true,ok:true,message:rows.length?rows.slice(0,8).map(x=>`${x.type}: ${x.label} — ${new Date(x.at).toLocaleString()}`).join(' • '):'No active alarms or reminders.',intent:'SCHEDULE_LIST',data:rows};
  }
  const playYoutube = parseYouTube(lower);
  if (playYoutube) {
    if (!browserAgent) return { handled:true, ok:false, message:'Browser automation is not ready.', intent:'YOUTUBE_PLAY' };
    const query=playYoutube.query;
    const r=await browserAgent.playYouTube(query);
    return { handled:true, ok:r.ok, message:r.message, intent:'YOUTUBE_PLAY', data:r };
  }

  const openIntent = parseOpen(lower);
  let match = openIntent ? [null, openIntent.target] : null;
  if (match) {
    const target = resolveTarget(match[1]);
    if (target === 'downloads' || target === 'downloads folder') {
      await shell.openPath(app.getPath('downloads'));
      return { handled: true, ok: true, message: 'Opening Downloads.', intent: 'OPEN_FOLDER' };
    }
    if (target === 'documents' || target === 'documents folder') {
      await shell.openPath(app.getPath('documents'));
      return { handled: true, ok: true, message: 'Opening Documents.', intent: 'OPEN_FOLDER' };
    }
    if (target === 'desktop' || target === 'desktop folder') {
      await shell.openPath(app.getPath('desktop'));
      return { handled: true, ok: true, message: 'Opening Desktop.', intent: 'OPEN_FOLDER' };
    }
    if (APP_COMMANDS[target]) {
      // FAST PATH: launch immediately. Verification runs asynchronously so a successful
      // desktop command is never held hostage by a multi-second process polling loop.
      launch(APP_COMMANDS[target]);
      windowsAgent.waitRunning(target, 1800).then(v=>console.log('[DNA.AI][VERIFY]', target, v)).catch(()=>{});
      return { handled: true, ok: true, message: `Opening ${target}.`, intent: 'OPEN_APP', data:{verification:{pending:true}} };
    }
    if (URLS[target]) {
      await shell.openExternal(URLS[target]);
      return { handled: true, ok: true, message: `Opening ${target}.`, intent: 'OPEN_URL' };
    }
    // Broad Windows app access: let the Windows shell resolve installed apps, Start-menu aliases,
    // registered URI handlers, shortcuts, documents and executables without routing to cloud AI.
    if (process.platform === 'win32' && /^[a-z0-9][a-z0-9 ._+()-]{0,100}$/i.test(target)) {
      try {
        launch(['cmd.exe', '/d', '/s', '/c', 'start', '', target]);
        return { handled: true, ok: true, message: `Opening ${target}.`, intent: 'OPEN_WINDOWS_TARGET' };
      } catch {}
    }
    // Local-looking commands MUST NOT silently fall through to the cloud AI provider.
    return { handled: true, ok: false, message: `I couldn't find a local app or shortcut named ${target}.`, intent: 'LOCAL_COMMAND_UNKNOWN' };
  }
  const searchIntent = parseSearch(lower);
  if (searchIntent) {
    await shell.openExternal(`https://www.google.com/search?q=${encodeURIComponent(searchIntent.query)}`);
    return { handled:true, ok:true, message:`Searching Google for ${searchIntent.query}.`, intent:'WEB_SEARCH' };
  }
  const google = lower.match(/^search google for\s+(.+)$/);
  if (google) {
    await shell.openExternal(`https://www.google.com/search?q=${encodeURIComponent(google[1])}`);
    return { handled: true, ok: true, message: `Searching Google for ${google[1]}.`, intent: 'WEB_SEARCH' };
  }
  const youtube = lower.match(/^search youtube for\s+(.+)$/);
  if (youtube) {
    await shell.openExternal(`https://www.youtube.com/results?search_query=${encodeURIComponent(youtube[1])}`);
    return { handled: true, ok: true, message: `Searching YouTube for ${youtube[1]}.`, intent: 'YOUTUBE_SEARCH' };
  }
  const close = lower.match(/^(?:close|quit|exit)\s+(.+)$/) || lower.match(/^(.+?)\s+(?:band karo|band kar do)$/);
  if (close) {
    const target=resolveTarget(close[1]); const ok=await closeApp(target);
    return { handled:true, ok, message:ok?`Closed ${target}.`:`I couldn't find a running ${target} process.`, intent:'CLOSE_APP' };
  }
  const find = lower.match(/^(?:find|search for|locate)\s+(?:my\s+)?(?:file\s+)?(.+)$/) || lower.match(/^(.+?)\s+(?:file\s+)?(?:dhundo|dhoondo|find karo)$/);
  if (find) {
    const results=await findFiles(find[1]);
    if(!results.length) return { handled:true, ok:false, message:`I couldn't find a matching file in Desktop, Documents, or Downloads.`, intent:'FIND_FILE', data:[] };
    const first=results[0];
    return { handled:true, ok:true, message:results.length===1?`Found it: ${first.Name}`:`I found ${results.length} matches. The newest is ${first.Name}.`, intent:'FIND_FILE', data:results };
  }
  const wa = command.match(/^(?:whatsapp|message)\s+(?:to\s+)?(\+?[0-9][0-9\s-]{7,})\s*[:,-]?\s*(?:saying|say|message)?\s*(.+)$/i);
  if (wa) {
    const ok=await openWhatsappMessage(wa[1],wa[2]);
    return { handled:true, ok, message:ok?'I opened WhatsApp with the message ready. Review it and press Send.':'I need a valid phone number for this local WhatsApp action.', intent:'WHATSAPP_DRAFT' };
  }

  const remember = command.match(/^remember contact\s+(.+?)\s+as\s+(\+?[0-9][0-9\s-]{7,})$/i);
  if (remember) { const ok=rememberContact(remember[1],remember[2]); return {handled:true,ok,message:ok?`Got it. I saved ${remember[1]} locally.`:'That phone number does not look valid.',intent:'CONTACT_SAVE'}; }
  const sendWa =
    command.match(/^(?:send|deliver)\s+(?:a\s+)?(?:whatsapp\s+)?message\s+to\s+(.+?)\s+on\s+whatsapp\s+(.+)$/i) ||
    command.match(/^(?:send|deliver)\s+(?:a\s+)?whatsapp\s+message\s+to\s+(.+?)\s+(?:saying|message|that says|:)\s*(.+)$/i) ||
    command.match(/^whatsapp\s+(.+?)\s+(?:saying|message|that says|:)\s*(.+)$/i);
  if (sendWa) {
    if(!browserAgent) return {handled:true,ok:false,message:'WhatsApp automation is not ready.',intent:'WHATSAPP_SEND'};
    const r=await browserAgent.whatsappSend(sendWa[1].trim(),sendWa[2].trim().replace(/^[\"']|[\"']$/g,''));
    return {handled:true,ok:r.ok,message:r.message,intent:'WHATSAPP_SEND',data:r};
  }
  const inspectUi=command.match(/^inspect (?:the )?(.+?) (?:window|app|ui)$/i); if(inspectUi){const r=await windowsAgent.uiInspect(inspectUi[1]);return{handled:true,ok:r.ok,message:r.ok?'I inspected the app UI.':r.message,intent:'UI_INSPECT',data:r.data||r.text};}
  const invokeUi=command.match(/^in (.+?) (?:click|invoke) (.+)$/i); if(invokeUi){const r=await windowsAgent.uiInvoke(invokeUi[1],invokeUi[2]);return{handled:true,ok:r.ok,message:r.ok?'Done.':r.message,intent:'UI_INVOKE'};}
  if (/^(?:inspect|read) (?:the )?(?:browser|web page|page)$/.test(lower)) { if(!browserAgent)return{handled:true,ok:false,message:'Browser agent is not ready.',intent:'BROWSER_INSPECT'}; const r=await browserAgent.inspectActivePageForAI(); return{handled:true,ok:r.ok,message:r.ok?`I inspected ${r.title||'the active page'} through its accessibility tree.`:'Browser inspection failed.',intent:'BROWSER_INSPECT',data:r}; }
  const browserClick=command.match(/^(?:in browser )?(?:click|press) (.+)$/i); if(browserClick){ if(!browserAgent)return{handled:true,ok:false,message:'Browser agent is not ready.',intent:'BROWSER_ACCESSIBLE_CLICK'}; const r=await browserAgent.clickAccessible(browserClick[1]); return{handled:true,ok:r.ok,message:r.message,intent:'BROWSER_ACCESSIBLE_CLICK',data:r}; }
  if (/^(?:take |capture )?(?:a )?screenshot$/.test(lower)) { const file=await captureScreen(); return {handled:true,ok:true,message:'Screenshot captured.',intent:'SCREENSHOT',data:{path:file}}; }
  if (/^(?:look at|analyze|understand|describe|read) (?:my |the )?screen$/.test(lower) || /^(?:screen dekho|screen samjho|screen pe kya hai)$/.test(lower)) { const r=await analyzeScreen(); return {handled:true,ok:r.ok,message:r.message,intent:'SCREEN_VISION',data:r.path?{path:r.path}:undefined}; }
  const screenQ=command.match(/^(?:look at|analyze) (?:my |the )?screen (?:and )?(.+)$/i); if(screenQ){const r=await analyzeScreen(screenQ[1]);return{handled:true,ok:r.ok,message:r.message,intent:'SCREEN_VISION',data:r.path?{path:r.path}:undefined};}
  const click=lower.match(/^click\s+(\d+)\s*[, ]\s*(\d+)$/); if(click){await clickScreen(click[1],click[2]);return{handled:true,ok:true,message:`Clicked ${click[1]}, ${click[2]}.`,intent:'SCREEN_CLICK'};}
  const typing=command.match(/^type\s+(.+)$/i); if(typing){await typeText(typing[1]);return{handled:true,ok:true,message:'Typed it.',intent:'SCREEN_TYPE'};}

  const imageCreate = command.match(/^(?:create|generate|make)\s+(?:an?\s+)?(?:image|photo|picture|wallpaper|poster|logo)(?:\s+of|\s+for|\s*:)?\s+(.+)$/i) || command.match(/^(?:image|photo|picture|wallpaper|poster|logo)\s+(?:banao|bana do)(?:\s+of|\s+for|\s*:)?\s+(.+)$/i) || command.match(/^(.+?)\s+(?:ki|ka|ke)?\s*(?:image|photo|picture|wallpaper|poster|logo)\s+(?:banao|bana do)$/i);
  if (imageCreate) {
    if (!imageAgent) imageAgent = new ImageAgent({downloadsDir:app.getPath('downloads')});
    const r=await imageAgent.generate(imageCreate[1].trim());
    return {handled:true,ok:r.ok,message:r.message,intent:'IMAGE_GENERATE',data:r.path?{path:r.path,provider:r.provider}:undefined};
  }

  if (/^(?:download|get|save) (?:the )?(?:latest )?(?:chatgpt )?(?:generated )?image(?: from chatgpt)?$/i.test(command) || /chatgpt.*image.*download/i.test(command)) {
    if (!browserAgent) return {handled:true,ok:false,message:'Browser agent is not ready.',intent:'BROWSER_UNAVAILABLE'};
    const r=await browserAgent.chatgptLatestImageDownload();
    return {handled:true,ok:r.ok,message:r.message,intent:'CHATGPT_IMAGE_DOWNLOAD',data:r.path?{path:r.path}:undefined};
  }
  const waName = command.match(/^(?:whatsapp|message)\s*(?:pe|par|to)?\s+(.+?)\s+(?:ko\s+)?(?:message|msg|bol|bolo|saying|that says|:)\s+(.+)$/i);
  if (waName && !/^\+?[0-9]/.test(waName[1].trim())) {
    if (!browserAgent) return {handled:true,ok:false,message:'Browser agent is not ready.',intent:'BROWSER_UNAVAILABLE'};
    const r=await browserAgent.whatsappDraft(waName[1].trim(),waName[2].trim());
    if(r.ok) pendingConfirmation={type:'whatsapp-send',expires:Date.now()+120000};
    return {handled:true,ok:r.ok,message:r.message,intent:'WHATSAPP_BROWSER_DRAFT'};
  }
  if (/^(send it|bhej do|bhej de|send)$/i.test(command.trim())) {
    if (!pendingConfirmation || pendingConfirmation.type!=='whatsapp-send' || pendingConfirmation.expires<Date.now()) return {handled:true,ok:false,message:'There is no recent action waiting for confirmation.',intent:'NO_PENDING_CONFIRMATION'};
    pendingConfirmation=null;
    const r=await browserAgent.sendCurrentWhatsAppDraft();
    return {handled:true,ok:r.ok,message:r.message,intent:'WHATSAPP_BROWSER_SEND'};
  }

  if (/^(?:show|read) clipboard$/.test(lower) || /clipboard (?:dikhao|batao)$/.test(lower)) {
    const value=clipboard.readText(); return {handled:true,ok:true,message:value?`Clipboard says: ${value}`:'Your clipboard is empty.',intent:'CLIPBOARD_READ'};
  }
  if (/^(?:open )?downloads(?: folder)?$/.test(lower) || /downloads (?:kholo|khol do)$/.test(lower)) {
    await shell.openPath(app.getPath('downloads')); return {handled:true,ok:true,message:'Opening Downloads.',intent:'OPEN_FOLDER'};
  }
  const research = command.match(/^(?:research|web research|internet pe research|search and explain)\s+(.+)$/i);
  if (research) {
    if (!browserAgent) return {handled:true,ok:false,message:'Browser research agent is not ready.',intent:'RESEARCH_UNAVAILABLE'};
    const web=await browserAgent.researchWeb(research[1]);
    if (!web.ok) return {handled:true,ok:false,message:web.message,intent:'WEB_RESEARCH'};
    if (!dnaBrain) dnaBrain = new DNABrain({ userDataDir: app.getPath('userData'), getApiKey: getStoredApiKey });
    const evidence=web.results.map((r,i)=>`[${i+1}] ${r.title}\n${r.url}\n${r.snippet}`).join('\n\n');
    const answer=await dnaBrain.chat(`Research question: ${research[1]}\n\nCurrent web search evidence:\n${evidence}\n\nAnswer using only useful evidence above. Clearly say when evidence is insufficient. Do not claim you browsed pages you did not inspect.`);
    return {handled:true,ok:answer.ok,message:answer.message,intent:'WEB_RESEARCH',data:{sources:web.results}};
  }
  const rememberBrain = command.match(/^(?:remember|yaad rakh(?:o)?|note that)\s+(.+)$/i);
  if (rememberBrain) {
    if (!dnaBrain) dnaBrain = new DNABrain({ userDataDir: app.getPath('userData'), getApiKey: getStoredApiKey });
    dnaBrain.remember(rememberBrain[1], ['explicit']);
    return { handled:true, ok:true, message:'Yaad rakh liya.', intent:'MEMORY_SAVE' };
  }
  const forget = command.match(/^(?:forget|bhool ja(?:o)?)\s+(.+)$/i);
  if (forget) {
    if (!dnaBrain) dnaBrain = new DNABrain({ userDataDir: app.getPath('userData'), getApiKey: getStoredApiKey });
    const n=dnaBrain.forgetMatching(forget[1]);
    return { handled:true, ok:true, message:n?`Theek hai, ${n} matching memory bhool gaya.`:'Mujhe usse matching koi saved memory nahi mili.', intent:'MEMORY_FORGET' };
  }
  const recall = command.match(/^(?:what do you remember about|tumhe kya yaad hai about|yaad hai)\s+(.+)$/i);
  if (recall) {
    if (!dnaBrain) dnaBrain = new DNABrain({ userDataDir: app.getPath('userData'), getApiKey: getStoredApiKey });
    const rows=dnaBrain.relevantMemory(recall[1],6);
    return { handled:true, ok:true, message:rows.length?rows.map(r=>r.text).join(' • '):'Is topic par meri long-term memory mein abhi kuch saved nahi hai.', intent:'MEMORY_RECALL' };
  }
  return { handled: false, ok: false, message: '', intent: 'AI_QUERY' };
}

async function askGemini(text) {
  if (!dnaBrain) dnaBrain = new DNABrain({ userDataDir: app.getPath('userData'), getApiKey: getStoredApiKey });
  return dnaBrain.chat(text);
}

async function executeCommand(raw, options = {}) {
  const text = String(raw || '').trim(); if (!text) return { ok: false, message: 'Empty command.', intent: 'UNKNOWN' };
  // YouTube natural-language commands must stay atomic. Splitting "open yt and play X"
  // into two commands loses the YouTube context from the second half.
  const atomicYouTube = parseYouTube(text);
  if (atomicYouTube) {
    const local = await localIntent(text);
    const result = local.handled ? local : { ok:false, message:'I could not resolve that YouTube command.', intent:'YOUTUBE_PLAY' };
    rememberEvent('command', { input:text, intent:result.intent, ok:result.ok });
    return { ok:result.ok, message:result.message, intent:result.intent, data:result.data };
  }
  // Multi-action local plans: "Chrome kholo aur YouTube kholo" executes sequentially.
  // We only auto-chain when every segment clearly looks like a local action; conversation stays with the brain.
  if (!options._subplan) {
    const parts=text.split(/\s+(?:and then|then|and|aur|phir)\s+/i).map(x=>x.trim()).filter(Boolean);
    if(parts.length>1 && parts.length<=6 && parts.every(looksLikeLocalCommand)) {
      const steps=[];
      for(const part of parts){ const r=await executeCommand(part,{...options,speak:false,_subplan:true}); steps.push({command:part,...r}); if(!r.ok) break; }
      const ok=steps.every(x=>x.ok); const message=steps.map(x=>x.message).filter(Boolean).join(' ');
      rememberEvent('plan',{input:text,ok,steps:steps.map(x=>({command:x.command,intent:x.intent,ok:x.ok}))});
      if(options.speak && message) try{await speak(message)}catch{}
      return {ok,message,intent:'MULTI_ACTION_PLAN',data:{steps}};
    }
  }
  const local = await localIntent(text);
  let result;
  if (local.handled) {
    result = local;
    console.log(`[DNA.AI][LOCAL] ${JSON.stringify({ input: text, intent: local.intent, ok: local.ok })}`);
  } else if (looksLikeLocalCommand(text)) {
    result = { ok: false, message: 'I recognized that as a local command, but no matching local action is installed yet.', intent: 'LOCAL_COMMAND_UNKNOWN' };
    console.warn(`[DNA.AI][LOCAL_UNRESOLVED] ${text}`);
  } else {
    console.log(`[DNA.AI][AI] Routing conversational input to AI provider.`);
    result = await askGemini(text);
  }
  rememberEvent('command', { input:text, intent:result.intent, ok:result.ok });
  if(runtimeGuard) runtimeGuard.record({kind:'command',input:text,intent:result.intent,ok:result.ok,risk:runtimeGuard.classify(result.intent)});
  if (options.speak && result.message) { try { await speak(result.message); } catch {} }
  return { ok: result.ok, message: result.message, intent: result.intent, data: result.data };
}

function psEncoded(script) { return Buffer.from(script, 'utf16le').toString('base64'); }
let activeTtsPromise = null;
async function speak(text, style='') {
  // Exactly one voice response at a time. If another code path tries to speak
  // while the female voice is already talking, do not start a second speaker.
  if (activeTtsPromise) {
    console.warn('[DNA.AI][TTS_OVERLAP_BLOCKED]');
    return false;
  }
  activeTtsPromise = speakFemaleOnly(text, style);
  try { return await activeTtsPromise; }
  finally { activeTtsPromise = null; }
}
async function speakFemaleOnly(text, style='') {
  if (process.platform !== 'win32') throw new Error('Voice currently supports Windows only.');
  const spoken = String(text || '').trim();
  // Never vocalize STT echo/hallucination garbage (e.g. 'alte alte alte').
  if (!spoken || isVoiceGarbage(spoken)) { console.warn('[DNA.AI][TTS_GARBAGE_BLOCKED]', spoken); return false; }
  const normSpoken = normalizeSpeech(spoken);
  const nowSpoken = Date.now();
  if (normSpoken && normSpoken === lastSpokenText && nowSpoken-lastSpokenAt < 6000) { console.warn('[DNA.AI][TTS_DUPLICATE_BLOCKED]', spoken); return false; }
  lastSpokenText = normSpoken; lastSpokenAt = nowSpoken;
  text = spoken;
  isSpeaking=true; voiceState={...voiceState,state:'SPEAKING'}; emitVoice();
  try {
    // ONE VOICE ONLY: Edge-TTS Indian female voice.
    // Never fall back to Gemini/Windows System.Speech because those fallback
    // providers were responsible for a second (male/different) spoken reply.
    try {
      await edgeNaturalTts(text);
      return true;
    } catch (e) {
      console.warn('[DNA.AI][FEMALE_TTS_FAILED_NO_FALLBACK]', e?.message || e);
      return false;
    }
  } finally {
    isSpeaking=false;
    wakeCooldownUntil=Date.now()+400;
    voiceState={...voiceState,state:'COOLDOWN'}; emitVoice();
    await sleep(400);
    if(!isQuitting){ voiceState={...voiceState,state:'WAITING_WAKE'}; emitVoice(); }
  }
}
function normalizeSpeech(text) { return String(text || '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim(); }
function isVoiceGarbage(text) {
  const n=normalizeSpeech(text); if(!n) return true;
  const words=n.split(' ').filter(Boolean); if(!words.length) return true;
  // Whisper/echo sometimes emits one nonsense token repeatedly (e.g. "alte alte alte").
  const counts=new Map(); for(const w of words) counts.set(w,(counts.get(w)||0)+1);
  const max=Math.max(...counts.values());
  if(words.length>=3 && max/words.length>=0.67) return true;
  if(/^(?:alte|alright|yeah|ya|uh|um|hmm)(?:\s+(?:alte|alright|yeah|ya|uh|um|hmm)){1,}$/i.test(n)) return true;
  return false;
}
function shouldSpeakVoiceResult(result) {
  // Speak the final verified response for both actions and conversation. Execution still
  // happens first, so TTS never blocks opening apps/sites or starting searches.
  if (!result || !result.message) return false;
  if (isVoiceGarbage(result.message)) return false;
  return true;
}

let wakeEngine = null;
let commandProcess = null;
let wakeCooldownUntil = 0;
const sleep = ms => new Promise(r => setTimeout(r, ms));

// P6 Local Wake: no cloud account, no API key, no downloaded wake model.
// The user's Windows recognizer was runtime-tested and transcribed "Hey DNA" as "AT&T".
// We therefore use a tiny constrained wake grammar with explicit acoustic aliases instead of
// open dictation. This keeps the listener local and dramatically narrows the search space.
const WAKE_ALIASES = ['hey DNA', 'hey D N A', 'DNA', 'AT&T', 'A T and T'];

function voiceProviderName() {
  return localVoiceAvailable() ? 'DNA Local Voice — Whisper multilingual STT' : 'DNA Local Voice — Windows fallback';
}

function showAssistantOverlay() {
  if (!assistantWindow || assistantWindow.isDestroyed()) createAssistantWindow();
  if (!assistantWindow) return;
  // Voice activation must never steal keyboard focus from the dashboard/text input.
  try {
    const area = screen.getDisplayNearestPoint(screen.getCursorScreenPoint()).workArea;
    const [w,h] = assistantWindow.getSize();
    assistantWindow.setPosition(Math.round(area.x + area.width - w - 22), Math.round(area.y + (area.height - h) / 2));
  } catch {}
  assistantWindow.showInactive();
  assistantWindow.setAlwaysOnTop(true, 'screen-saver');
  assistantWindow.moveTop();
}
function hideAssistantOverlay() { if (assistantWindow && !assistantWindow.isDestroyed()) assistantWindow.hide(); }
function foregroundDNA() { showAssistantOverlay(); }

function sendToRenderers(channel, payload) {
  for (const win of [mainWindow, assistantWindow]) if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
}
function emitVoice() { sendToRenderers('dna:voice-state', voiceState); }

function stopWakeEngine() {
  if (voiceProcess) { try { voiceProcess.kill(); } catch {} voiceProcess = null; }
  wakeEngine = null;
}
function stopCommandRecognizer() {
  if (commandProcess) { try { commandProcess.kill(); } catch {} commandProcess = null; }
  if (sttCapturePending) { const p=sttCapturePending; sttCapturePending=null; try{p.resolve({type:'error',message:'capture cancelled'});}catch{} }
}
function stopSttWorker() {
  if (sttWorker) { try { sttWorker.stdin.write('QUIT\n'); } catch {} try { sttWorker.kill(); } catch {} }
  sttWorker=null; sttWorkerReady=false; sttCapturePending=null;
}
function ensureSttWorker() {
  if (!localVoiceAvailable()) return Promise.reject(new Error('LOCAL_STT_UNAVAILABLE'));
  if (sttWorker && sttWorkerReady) return Promise.resolve(true);
  if (sttWorker && !sttWorkerReady) return new Promise((resolve,reject)=>{ const t=setInterval(()=>{if(sttWorkerReady){clearInterval(t);resolve(true)}else if(!sttWorker){clearInterval(t);reject(new Error('STT_WORKER_EXITED'))}},100); setTimeout(()=>{clearInterval(t); sttWorkerReady?resolve(true):reject(new Error('STT_WORKER_TIMEOUT'))},30000); });
  return new Promise((resolve,reject)=>{
    const p=spawn(pythonExe(),[localVoiceBridge(),'server'],{windowsHide:true,stdio:['pipe','pipe','pipe']}); sttWorker=p; let buffer=''; let done=false;
    const ready=()=>{if(!done){done=true;resolve(true)}};
    p.stdout.on('data',chunk=>{buffer+=chunk.toString();const lines=buffer.split(/\r?\n/);buffer=lines.pop()||'';for(const line of lines){
      if(line.startsWith('DNA_SERVER_READY|')){sttWorkerReady=true;voiceState={...voiceState,recognizer:'DNA Local Voice — persistent Whisper'};emitVoice();ready();continue;}
      if(line.startsWith('DNA_WARN|')){console.warn('[DNA.AI][STT]',line);continue;}
      const pending=sttCapturePending; if(!pending) continue;
      if(line.startsWith('DNA_COMMAND|')){sttCapturePending=null;pending.resolve({type:'transcript',text:line.split('|').slice(2).join('|').trim()});}
      else if(line==='DNA_COMMAND_TIMEOUT'){sttCapturePending=null;pending.resolve({type:'timeout'});}
      else if(line.startsWith('DNA_COMMAND_ERROR|')){sttCapturePending=null;pending.resolve({type:'error',message:line.slice(18)});}
    }});
    p.stderr.on('data',d=>{const msg=d.toString().trim();if(msg)console.warn('[DNA.AI][STT STDERR]',msg)});
    p.on('exit',code=>{if(sttWorker===p){sttWorker=null;sttWorkerReady=false;}if(sttCapturePending){const q=sttCapturePending;sttCapturePending=null;q.resolve({type:'error',message:`STT worker exited ${code}`});}if(!done){done=true;reject(new Error(`STT_WORKER_EXIT_${code}`));}});
    p.on('error',e=>{if(!done){done=true;reject(e)}});
  });
}
async function requestWhisperCapture(seconds=8) {
  await ensureSttWorker();
  if(sttCapturePending) throw new Error('STT_CAPTURE_ALREADY_ACTIVE');
  return new Promise((resolve,reject)=>{sttCapturePending={resolve,reject};try{sttWorker.stdin.write(`CAPTURE|${seconds}\n`)}catch(e){sttCapturePending=null;reject(e)}});
}

async function stopVoice() {
  stopCommandRecognizer();
  stopWakeEngine();
  stopSttWorker();
  voiceState = { ...voiceState, state: 'STOPPED' };
  emitVoice();
  return voiceState;
}

async function handleWakeDetected(source = 'local-wake', inlineCommand = '') {
  if (isSpeaking || voiceState.state === 'PROCESSING' || voiceState.state === 'AWAKE') return;
  stopWakeEngine();
  sleepingMode = false; // Wake word always exits sleep mode.
  foregroundDNA();
  voiceState = { ...voiceState, state: 'AWAKE', wakeDetectedAt: Date.now(), lastError: '', recognizer: voiceProviderName(), lastTranscript: 'DNA' };
  emitVoice();
  sendToRenderers('dna:wake-detected', { transcript: 'DNA', command: '', source });
  const inline = String(inlineCommand || '').trim();
  if (inline) {
    voiceState = { ...voiceState, state:'PROCESSING', lastTranscript:inline }; emitVoice();
    sendToRenderers('dna:voice-transcript', inline);
    const result = await executeCommand(inline, { speak:false });
    sendToRenderers('dna:voice-result', result);
    if (shouldSpeakVoiceResult(result) && result.message) { try { await speak(result.message); } catch {} }
    if (!isQuitting) await startWakeEngine();
    return;
  }
  // Wake acknowledgement is visual only. Speaking here caused the assistant to hear itself.
  voiceState = { ...voiceState, state:'LISTENING_COMMAND' }; emitVoice();
  await listenForOneCommand();
}

function listenForOneWhisperCommand({followup=false}={}){
  const seconds=Math.max(3,Math.min(12,Number(followup ? (process.env.DNA_FOLLOWUP_TIMEOUT_SECONDS||4) : (process.env.DNA_COMMAND_TIMEOUT_SECONDS||4.5))));
  voiceState={...voiceState,state:'LISTENING_COMMAND',recognizer:'DNA Local Voice — persistent Whisper'};emitVoice();
  return requestWhisperCapture(seconds).then(async out=>{
    if(out.type==='transcript' && out.text){
      const transcript=out.text.trim();
      const normalizedTranscript=normalizeSpeech(transcript);
      const now=Date.now();
      // Guard against Whisper/echo hallucination loops (for example the same short token
      // being emitted repeatedly after TTS). Never execute an identical transcript twice
      // inside the debounce window.
      if (normalizedTranscript && normalizedTranscript === lastVoiceTranscript && now-lastVoiceTranscriptAt < 8000) {
        console.warn('[DNA.AI][VOICE_DUPLICATE_IGNORED]', transcript);
        voiceState={...voiceState,state:'WAITING_WAKE'};emitVoice();
        if(!isQuitting) await startWakeEngine();
        return true;
      }
      if (isVoiceGarbage(transcript)) {
        console.warn('[DNA.AI][VOICE_GARBAGE_IGNORED]', transcript);
        voiceState={...voiceState,state:'WAITING_WAKE'};emitVoice();
        if(!isQuitting) await startWakeEngine();
        return true;
      }
      lastVoiceTranscript=normalizedTranscript; lastVoiceTranscriptAt=now;
      voiceState={...voiceState,lastTranscript:transcript,state:'PROCESSING'};emitVoice();sendToRenderers('dna:voice-transcript',transcript);
      // Execute first. Do not serialize simple local commands behind TTS.
      const r=await executeCommand(transcript,{speak:false}); sendToRenderers('dna:voice-result',r);
      if (shouldSpeakVoiceResult(r) && r.message) { try { await speak(r.message); } catch {} }
      // Sleep command immediately ends the active session. Continuous follow-up is opt-in;
      // defaulting it off prevents the assistant from repeatedly transcribing speaker echo/noise.
      if(r?.intent==='SLEEP_MODE' || sleepingMode) { if(!isQuitting) await startWakeEngine(); return true; }
      if(!isQuitting && String(process.env.DNA_CONTINUOUS_SESSION||'0')==='1') return listenForOneWhisperCommand({followup:true});
      if(!isQuitting) await startWakeEngine(); return true;
    }
    if(out.type==='error'){voiceState={...voiceState,state:'FAILED',lastError:out.message||'STT error'};emitVoice();}
    else {voiceState={...voiceState,state:'WAITING_WAKE'};emitVoice();}
    if(!isQuitting) await startWakeEngine(); return true;
  }).catch(async e=>{voiceState={...voiceState,state:'FAILED',lastError:e.message||String(e)};emitVoice();if(!isQuitting)await startWakeEngine();return false;});
}

function listenForOneCommand() {
  if (process.platform !== 'win32') return Promise.resolve(false);
  stopCommandRecognizer();
  // Accuracy-first: command recognition NEVER falls back to Windows dictation.
  // Wake detection may use the lightweight Windows recognizer, but every actual command
  // is captured by the single persistent multilingual Whisper worker.
  if (localVoiceAvailable()) {
    if (sttWorkerReady) return listenForOneWhisperCommand({followup:false});
    voiceState = { ...voiceState, state: 'VOICE_MODEL_LOADING', recognizer: 'DNA Local Voice — preparing Whisper' };
    emitVoice();
    return ensureSttWorker()
      .then(() => listenForOneWhisperCommand({followup:false}))
      .catch(async e => {
        voiceState={...voiceState,state:'FAILED',lastError:'Whisper unavailable: '+(e.message||String(e))}; emitVoice();
        if(!isQuitting) await startWakeEngine();
        return false;
      });
  }
  voiceState = { ...voiceState, state: 'FAILED', lastError: 'High-accuracy Whisper voice engine is not installed.' };
  emitVoice();
  if(!isQuitting) startWakeEngine();
  return Promise.resolve(false);

  /* Legacy Windows dictation intentionally disabled for commands.
  voiceState = { ...voiceState, state: 'AWAKE', recognizer: voiceProviderName() };
  emitVoice();
  const seconds = Math.max(4, Math.min(20, Number(process.env.DNA_COMMAND_TIMEOUT_SECONDS || 10)));
  const script = `Add-Type -AssemblyName System.Speech; try { $r=New-Object System.Speech.Recognition.SpeechRecognitionEngine; $phrases=@('open calculator','open chrome','open edge','open firefox','open youtube','open notepad','open file explorer','open vs code','open spotify','open whatsapp','open instagram','open chatgpt','open downloads','play carryminati on youtube','play some music','calculator kholo','chrome kholo','youtube kholo','notepad kholo','vs code kholo','spotify kholo','whatsapp kholo','downloads kholo','close calculator','close chrome','close notepad','calculator band karo','chrome band karo','notepad band karo'); $choices=New-Object System.Speech.Recognition.Choices; foreach($p in $phrases){$choices.Add($p)}; $gb=New-Object System.Speech.Recognition.GrammarBuilder; $gb.Append($choices); $r.LoadGrammar((New-Object System.Speech.Recognition.Grammar($gb))); $r.LoadGrammar((New-Object System.Speech.Recognition.DictationGrammar)); $r.SetInputToDefaultAudioDevice(); [Console]::Out.WriteLine('DNA_COMMAND_READY'); [Console]::Out.Flush(); $x=$r.Recognize([TimeSpan]::FromSeconds(${seconds})); if($x){[Console]::Out.WriteLine(('DNA_COMMAND|'+$x.Confidence+'|'+$x.Text));[Console]::Out.Flush()}else{[Console]::Out.WriteLine('DNA_COMMAND_TIMEOUT');[Console]::Out.Flush()} } catch { [Console]::Out.WriteLine(('DNA_COMMAND_ERROR|'+$_.Exception.Message));[Console]::Out.Flush();exit 1 }`;
  return new Promise(resolve => {
    const p = spawn('powershell.exe', ['-NoProfile','-NonInteractive','-EncodedCommand', psEncoded(script)], { windowsHide: true });
    commandProcess = p;
    let buffer = '';
    let settled = false;
    const finish = async () => {
      if (settled) return;
      settled = true;
      if (commandProcess === p) commandProcess = null;
      if (!isQuitting) await startWakeEngine();
      resolve(true);
    };
    p.stdout.on('data', chunk => {
      buffer += chunk.toString();
      const lines = buffer.split(/\r?\n/); buffer = lines.pop() || '';
      for (const line of lines) {
        if (line.startsWith('DNA_COMMAND|')) {
          const parts = line.split('|');
          const transcript = parts.slice(2).join('|').trim();
          if (!transcript) continue;
          voiceState = { ...voiceState, lastTranscript: transcript, state: 'PROCESSING' }; emitVoice();
          sendToRenderers('dna:voice-transcript', transcript);
          executeCommand(transcript, { speak: true }).then(async result => {
            sendToRenderers('dna:voice-result', result);
            await finish();
          });
        } else if (line === 'DNA_COMMAND_TIMEOUT') {
          voiceState = { ...voiceState, state: 'WAITING_WAKE' }; emitVoice();
          finish();
        } else if (line.startsWith('DNA_COMMAND_ERROR|')) {
          voiceState = { ...voiceState, state: 'FAILED', lastError: line.slice('DNA_COMMAND_ERROR|'.length) }; emitVoice();
          finish();
        }
      }
    });
    p.stderr.on('data', d => { const msg=d.toString().trim(); if(msg){ voiceState={...voiceState,lastError:msg}; emitVoice(); } });
    p.on('exit', () => { if (!settled) finish(); });
  });
  */
}

function startWhisperWake() {
  if (voiceProcess) return voiceState;
  voiceState={...voiceState,state:'INITIALIZING',lastError:'',recognizer:voiceProviderName(),wakeWord:'DNA'}; emitVoice();
  const p=spawn(pythonExe(),[localVoiceBridge(),'wake'],{windowsHide:true}); voiceProcess=p; wakeEngine={type:'whisper-local'}; let buffer='';
  p.stdout.on('data',chunk=>{buffer+=chunk.toString();const lines=buffer.split(/\r?\n/);buffer=lines.pop()||'';for(const line of lines){
    if(line==='DNA_READY'){voiceState={...voiceState,state:'WAITING_WAKE',recognizer:voiceProviderName(),lastError:''};emitVoice();}
    else if(line.startsWith('DNA_HEARD|')){voiceState={...voiceState,lastTranscript:line.slice(10)};emitVoice();}
    else if(line.startsWith('DNA_WAKE|')){const heard=line.split('|').slice(2).join('|');voiceState={...voiceState,lastTranscript:heard};emitVoice();const tail=heard.replace(/^\s*(?:hey\s+)?(?:d\s*n\s*a|dna)(?:\s+ai)?[\s,.:;-]*/i,'').trim();handleWakeDetected('whisper-local', tail && tail.toLowerCase()!==heard.toLowerCase()?tail:'');}
    else if(line.startsWith('DNA_ERROR|')){voiceState={...voiceState,state:'FAILED',lastError:line.slice(10)};emitVoice();}
  }});
  p.stderr.on('data',d=>{const msg=d.toString().trim();if(msg){voiceState={...voiceState,lastError:msg};emitVoice();}});
  p.on('exit',()=>{if(voiceProcess===p)voiceProcess=null;wakeEngine=null;}); return voiceState;
}

function startLocalWake() {
  if (voiceProcess) return voiceState;
  // Zero-install Windows fallback. Use continuous dictation rather than a fragile constrained
  // grammar, then normalize the hypotheses we observed on Windows (including AT&T -> Hey DNA).
  const script = `Add-Type -AssemblyName System.Speech; try { $r=New-Object System.Speech.Recognition.SpeechRecognitionEngine; $choices=New-Object System.Speech.Recognition.Choices; @('DNA','D N A','Hey DNA','Hey D N A','AT&T','A T and T','Okay DNA','OK DNA','Yo DNA') | ForEach-Object { $choices.Add($_) }; $gb=New-Object System.Speech.Recognition.GrammarBuilder; $gb.Append($choices); $r.LoadGrammar((New-Object System.Speech.Recognition.Grammar($gb))); $r.SetInputToDefaultAudioDevice(); Register-ObjectEvent $r SpeechRecognized -Action { $t=$Event.SourceEventArgs.Result.Text; $c=$Event.SourceEventArgs.Result.Confidence; [Console]::Out.WriteLine(('DNA_HEARD|'+$c+'|'+$t));[Console]::Out.Flush() }|Out-Null; [Console]::Out.WriteLine('DNA_READY');[Console]::Out.Flush(); $r.RecognizeAsync([System.Speech.Recognition.RecognizeMode]::Multiple); while($true){Start-Sleep -Milliseconds 250} } catch { [Console]::Out.WriteLine(('DNA_ERROR|'+$_.Exception.Message));[Console]::Out.Flush();exit 1 }`;
  voiceState = { ...voiceState, state: 'INITIALIZING', lastError: '', recognizer: voiceProviderName(), wakeWord: 'DNA' }; emitVoice();
  const p = spawn('powershell.exe', ['-NoProfile','-NonInteractive','-EncodedCommand', psEncoded(script)], { windowsHide: true });
  voiceProcess = p; wakeEngine = { type: 'windows-dictation-wake' }; let buffer = '';
  const wakeRx = /\b(?:(?:hey|okay|ok|yo)\s+)?(?:dna|d\s*n\s*a|at\s*&\s*t|a\s*t\s+and\s+t)\b/i;
  p.stdout.on('data', chunk => {
    buffer += chunk.toString(); const lines=buffer.split(/\r?\n/); buffer=lines.pop() || '';
    for (const line of lines) {
      if (line === 'DNA_READY') { voiceState={...voiceState,state:sleepingMode?'SLEEPING':'WAITING_WAKE',recognizer:voiceProviderName(),lastError:''}; emitVoice(); continue; }
      if (line.startsWith('DNA_HEARD|')) {
        const parts=line.split('|'); const confidence=Number(parts[1]||0); const heard=parts.slice(2).join('|').trim();
        voiceState={...voiceState,lastTranscript:heard}; emitVoice();
        const m=heard.match(wakeRx);
        if(m && confidence >= Number(process.env.DNA_WAKE_CONFIDENCE || 0.35)) {
          const tail=heard.slice((m.index||0)+m[0].length).replace(/^[\s,.:;-]+/,'').trim();
          handleWakeDetected('windows-dictation-wake', tail);
        }
      } else if(line.startsWith('DNA_ERROR|')) { voiceState={...voiceState,state:'FAILED',lastError:line.slice(10)}; emitVoice(); }
    }
  });
  p.stderr.on('data', d=>{const msg=d.toString().trim();if(msg){voiceState={...voiceState,lastError:msg};emitVoice();}});
  p.on('exit',code=>{if(voiceProcess===p)voiceProcess=null;wakeEngine=null;if(!isQuitting&&voiceState.state!=='STOPPED'&&!commandProcess){voiceState={...voiceState,state:code===0?'STOPPED':'FAILED'};emitVoice();}});
  return voiceState;
}

async function startWakeEngine() {
  if (isQuitting || isSpeaking || commandProcess || voiceProcess || Date.now() < wakeCooldownUntil) return voiceState;
  return startLocalWake();
}

async function startVoice() {
  if (process.platform !== 'win32') { voiceState = { ...voiceState, state: 'FAILED', lastError: 'Native voice currently supports Windows only.' }; emitVoice(); return voiceState; }
  if(!localVoiceAvailable()) await bootstrapVoiceDependencies();
  if(localVoiceAvailable()) {
    voiceState={...voiceState,state:'VOICE_MODEL_LOADING',recognizer:'DNA Local Voice — loading Whisper medium'}; emitVoice();
    try { await ensureSttWorker(); }
    catch(e) { console.warn('[DNA.AI][STT PREWARM]',e.message); voiceState={...voiceState,lastError:'Whisper prewarm failed: '+e.message}; emitVoice(); }
  }
  return startWakeEngine();
}

function metrics() { const total=os.totalmem(), free=os.freemem(); return { cpuCount:os.cpus().length, ramPercent:Math.round(((total-free)/total)*100), totalMemory:total, freeMemory:free, uptime:os.uptime(), platform:os.platform(), hostname:os.hostname() }; }
function health() { return { electron:'READY', ipc:'READY', ai:getStoredApiKey()?'READY':'NOT_CONFIGURED', voice:voiceState.state, stt:localVoiceAvailable()?'WHISPER_LOCAL':'WINDOWS_FALLBACK', tts:process.platform==='win32'?'READY':'UNAVAILABLE', automation:process.platform==='win32'?'READY':'UNAVAILABLE' }; }

function createAssistantWindow() {
  assistantWindow = new BrowserWindow({
    width: 190, height: 190, resizable: false, frame: false, transparent: true,
    backgroundColor: '#00000000', show: false, skipTaskbar: true, hasShadow: false,
    alwaysOnTop: true, focusable: false,
    webPreferences: { preload: path.join(__dirname,'preload.cjs'), contextIsolation:true, nodeIntegration:false, sandbox:true }
  });
  if (isDev) assistantWindow.loadURL('http://127.0.0.1:5173/?dnaOverlay=1');
  else assistantWindow.loadFile(path.join(__dirname,'..','dist','index.html'), { query: { dnaOverlay: '1' } });
  assistantWindow.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  assistantWindow.on('closed', () => { assistantWindow = null; });
}

function createSetupWindow() {
  if (setupWindow && !setupWindow.isDestroyed()) { setupWindow.show(); setupWindow.focus(); return; }
  setupWindow = new BrowserWindow({ width: 620, height: 520, resizable: false, autoHideMenuBar: true, backgroundColor: '#050a0f',
    webPreferences: { preload: path.join(__dirname,'preload.cjs'), contextIsolation:true, nodeIntegration:false, sandbox:true } });
  if (isDev) setupWindow.loadURL('http://127.0.0.1:5173/?dnaSetup=1');
  else setupWindow.loadFile(path.join(__dirname,'..','dist','index.html'), { query: { dnaSetup: '1' } });
  setupWindow.on('closed', () => { setupWindow = null; });
}

function createWindow() {
  mainWindow=new BrowserWindow({width:1500,height:950,minWidth:1100,minHeight:700,backgroundColor:'#050a0f',autoHideMenuBar:true,show:!launchedInBackground,webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true}});
  if(isDev) mainWindow.loadURL('http://127.0.0.1:5173'); else mainWindow.loadFile(path.join(__dirname,'..','dist','index.html'));
  mainWindow.webContents.once('did-finish-load',()=>{ if(!voiceProcess) startVoice(); });
  mainWindow.on('close', (event) => {
    if (!isQuitting) {
      event.preventDefault();
      mainWindow.hide();
    }
  });
}
function showDNA() {
  if (!mainWindow || mainWindow.isDestroyed()) createWindow();
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
}
function configureLoginStartup(enabled = true) {
  if (process.platform !== 'win32') return;
  const settings = isDev
    ? { openAtLogin: enabled, path: process.execPath, args: [app.getAppPath(), '--background'] }
    : { openAtLogin: enabled, args: ['--background'] };
  app.setLoginItemSettings(settings);
}
function createTray() {
  if (tray) return;
  let icon = nativeImage.createFromPath(path.join(__dirname, 'dna-tray.png'));
  if (icon.isEmpty()) icon = nativeImage.createEmpty();
  tray = new Tray(icon);
  tray.setToolTip('DNA.AI — Background Assistant');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Open DNA.AI', click: showDNA },
    { label: 'Wake Engine: Running', enabled: false },
    { label: 'AI Settings', click: createSetupWindow },
    { type: 'separator' },
    { label: 'Quit DNA.AI', click: () => { isQuitting = true; app.quit(); } }
  ]));
  tray.on('double-click', showDNA);
}
const gotSingleInstanceLock = app.requestSingleInstanceLock();
if (!gotSingleInstanceLock) app.quit();
else app.on('second-instance', () => showDNA());

app.whenReady().then(()=>{
  runtimeGuard = new RuntimeGuard(app.getPath('userData'));
  dnaScheduler = new DNAScheduler({ userDataDir: app.getPath('userData'), onFire: async item => {
    const title=item.type==='alarm'?'DNA.AI Alarm':item.type==='timer'?'DNA.AI Timer':'DNA.AI Reminder';
    try { new Notification({title,body:item.label,silent:false}).show(); } catch {}
    foregroundDNA();
    try { await speak(item.type==='alarm'?`Alarm. ${item.label}`:`Reminder. ${item.label}`); } catch {}
    sendToRenderers('dna:schedule-fired',item);
  }});
  dnaScheduler.arm();
  browserAgent = new BrowserAgent({ userDataDir: app.getPath('userData'), downloadsDir: app.getPath('downloads') });
  imageAgent = new ImageAgent({ downloadsDir: app.getPath('downloads') });
  ipcMain.handle('dna:execute-command',async(_e,c)=>{
    // Typed input must behave like voice input: execute first, then speak the
    // final validated result. Keeping speech outside executeCommand prevents
    // local actions from being delayed by TTS.
    const result = await executeCommand(c,{speak:false,inputSource:'typed'});
    if (result?.message && shouldSpeakVoiceResult(result)) {
      // Await so Electron keeps the TTS lifecycle/state coherent and the
      // renderer receives a result only after the spoken response completes.
      try { await speak(result.message); }
      catch (e) { console.warn('[DNA.AI][TYPED_TTS_FAILED]', e?.message || e); }
    }
    return result;
  }); ipcMain.handle('dna:schedules',()=>dnaScheduler?dnaScheduler.list():[]); ipcMain.handle('dna:schedule-cancel',(_e,id)=>dnaScheduler?dnaScheduler.cancel(id):false); ipcMain.handle('dna:system-metrics',()=>metrics()); ipcMain.handle('dna:health',()=>health());
  ipcMain.handle('dna:voice-start',()=>startVoice()); ipcMain.handle('dna:voice-stop',()=>stopVoice()); ipcMain.handle('dna:voice-toggle',async()=>{ if(voiceState.state==='STOPPED'||voiceState.state==='MIC_OFF'){ const v=await startVoice(); return {...v,micEnabled:true}; } await stopVoice(); voiceState={...voiceState,state:'MIC_OFF',lastError:''}; emitVoice(); return {...voiceState,micEnabled:false}; }); ipcMain.handle('dna:voice-state',()=>voiceState); ipcMain.handle('dna:speak',(_e,t)=>speak(t).then(()=>true));
  ipcMain.handle('dna:assistant-hide',()=>{ hideAssistantOverlay(); return true; });
  ipcMain.handle('dna:config-status',()=>({ aiConfigured: true, geminiConfigured: Boolean(getStoredApiKey()), localFirst: true }));
  ipcMain.handle('dna:config-save-key',(_e,key)=>saveApiKey(key));
  ipcMain.handle('dna:config-open',()=>{ createSetupWindow(); return true; });
  ipcMain.handle('dna:browser-login', async (_e, service) => { if(!browserAgent) return false; const urls={chatgpt:'https://chatgpt.com/',whatsapp:'https://web.whatsapp.com/'}; if(!urls[service]) return false; await browserAgent.open(urls[service]); return true; });
  ipcMain.handle('dna:dashboard-show',()=>{ showDNA(); hideAssistantOverlay(); return true; });
  ipcMain.handle('dna:screen-capture',()=>captureScreen()); ipcMain.handle('dna:screen-click',(_e,x,y)=>clickScreen(x,y)); ipcMain.handle('dna:screen-type',(_e,t)=>typeText(t));
  ipcMain.handle('dna:clipboard-read',()=>clipboard.readText()); ipcMain.handle('dna:clipboard-write',(_e,t)=>{clipboard.writeText(String(t||''));return true;});
  configureLoginStartup(true);
  createTray();
  createWindow();
  createAssistantWindow();
  // Self-configure accurate local STT/TTS on first launch; no setup batch file required.
  bootstrapVoiceDependencies().finally(()=>startVoice().catch(()=>{}));
  // Gemini is optional. Do not block first launch with an API-key window.
  app.on('activate',()=>showDNA());
});
app.on('before-quit',()=>{ isQuitting = true; stopVoice(); });
app.on('window-all-closed',()=>{ /* Intentionally stay alive in the system tray. */ });
