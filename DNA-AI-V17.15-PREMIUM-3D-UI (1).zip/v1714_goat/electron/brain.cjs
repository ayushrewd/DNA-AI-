const fs = require('node:fs');
const path = require('node:path');

class DNABrain {
  constructor({ userDataDir, getApiKey }) {
    this.userDataDir = userDataDir;
    this.getApiKey = getApiKey;
    this.memoryFile = path.join(userDataDir, 'dna-brain-memory.json');
    this.session = [];
    this.ollamaModelCache = { name:'', at:0 };
  }

  readMemory() {
    try {
      const data = JSON.parse(fs.readFileSync(this.memoryFile, 'utf8'));
      return Array.isArray(data) ? data : [];
    } catch { return []; }
  }

  writeMemory(rows) {
    fs.mkdirSync(this.userDataDir, { recursive: true });
    fs.writeFileSync(this.memoryFile, JSON.stringify(rows.slice(-500), null, 2), 'utf8');
  }

  remember(text, tags = ['user']) {
    const value = String(text || '').trim();
    if (!value) return false;
    const rows = this.readMemory();
    rows.push({ id: `${Date.now()}-${Math.random().toString(36).slice(2,8)}`, at: new Date().toISOString(), text: value, tags });
    this.writeMemory(rows);
    return true;
  }

  forgetMatching(query) {
    const q = String(query || '').toLowerCase().trim();
    if (!q) return 0;
    const rows = this.readMemory();
    const kept = rows.filter(r => !String(r.text || '').toLowerCase().includes(q));
    this.writeMemory(kept);
    return rows.length - kept.length;
  }

  relevantMemory(query, limit = 8) {
    const q = String(query || '').toLowerCase();
    const stem = x => String(x||'').toLowerCase().replace(/(ing|ed|es|s)$/,'');
    const terms = [...new Set(q.split(/[^a-z0-9]+/).filter(x => x.length > 2).map(stem))];
    const rows = this.readMemory();
    const df = new Map();
    for (const r of rows) { const toks=new Set(String(r.text||'').toLowerCase().split(/[^a-z0-9]+/).filter(x=>x.length>2).map(stem)); for(const x of toks) df.set(x,(df.get(x)||0)+1); }
    return rows.map(r => {
      const t = String(r.text || '').toLowerCase();
      const toks=new Set(t.split(/[^a-z0-9]+/).filter(x=>x.length>2).map(stem));
      let score = 0;
      for (const term of terms) if (toks.has(term)) score += 1 + Math.log((rows.length+1)/((df.get(term)||0)+1));
      if (q.length > 5 && t.includes(q)) score += 4;
      const ageDays = Math.max(0, (Date.now() - Date.parse(r.at || 0)) / 86400000);
      const recency = Number.isFinite(ageDays) ? Math.max(0, 1 - ageDays / 365) : 0;
      const explicit = Array.isArray(r.tags) && r.tags.includes('explicit') ? 1.5 : 0;
      score += recency + explicit;
      return { ...r, score };
    }).filter(r => r.score > 0.75).sort((a,b) => b.score-a.score || String(b.at).localeCompare(String(a.at))).slice(0, limit);
  }

  pushSession(role, text) {
    this.session.push({ role, text: String(text || '').slice(0, 8000) });
    if (this.session.length > 24) this.session = this.session.slice(-24);
  }

  systemPrompt(memory) {
    const memoryText = memory.length ? memory.map(m => `- ${m.text}`).join('\n') : '(no relevant saved memory)';
    return `You are DNA.AI, a persistent personal Windows AI companion, junior assistant, and computer agent.\n\nIDENTITY\n- Your name is DNA.AI. Never identify as Gemini, Ollama, Google, Microsoft, or an underlying model.\n- Speak naturally in the user's language. English, Hindi in Latin script, and Hinglish are all normal.\n- Sound like a capable human assistant/friend: concise by default, not robotic, not corporate.\n\nTRUTHFULNESS\n- Never claim a computer action happened unless the local tool layer reports success.\n- Never invent files, messages, downloads, contacts, screen state, memories, or tool results.\n- If a capability is unavailable, say so briefly.\n\nAGENT BEHAVIOR\n- Prefer local tools for actions. The model is for reasoning/conversation, not for pretending to control Windows.\n- Keep follow-ups context-aware. Resolve pronouns and short follow-ups from recent conversation when reasonable.\n- For risky/destructive actions, require explicit confirmation.\n\nRELEVANT LONG-TERM MEMORY\n${memoryText}`;
  }

  async callGemini(text, memory) {
    const key = this.getApiKey();
    if (!key) throw new Error('NO_GEMINI_KEY');
    const preferred = process.env.GEMINI_MODEL || 'gemini-3.6-flash';
    const models = [...new Set([preferred, 'gemini-3.6-flash', 'gemini-3.5-flash', 'gemini-3.5-flash-lite'])];
    const history = this.session.slice(-12).map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.text }] }));
    const contents = [...history, { role:'user', parts:[{text}] }];
    const body = { system_instruction:{parts:[{text:this.systemPrompt(memory)}]}, contents };
    let last = '';
    for (const model of models) {
      try {
        const url = `https://generativelanguage.googleapis.com/v1/models/${encodeURIComponent(model)}:generateContent`;
        const res = await fetch(url, { method:'POST', headers:{'content-type':'application/json','x-goog-api-key':key}, body:JSON.stringify(body) });
        const data = await res.json();
        if (!res.ok) {
          last = data?.error?.message || `HTTP ${res.status}`;
          if (res.status === 404) continue;
          throw new Error(last);
        }
        const message = data?.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join('').trim();
        if (!message) throw new Error('EMPTY_RESPONSE');
        return { message, provider:'cloud', model };
      } catch (e) { last = e.message || String(e); if (!/404|not found/i.test(last)) throw e; }
    }
    throw new Error(last || 'NO_MODEL');
  }

  async callOllama(text, memory) {
    const base = process.env.OLLAMA_HOST || 'http://127.0.0.1:11434';
    let model = process.env.DNA_LOCAL_MODEL || '';
    if (!model && this.ollamaModelCache.name && Date.now()-this.ollamaModelCache.at < 300000) model=this.ollamaModelCache.name;
    if (!model) {
      const tags = await fetch(`${base}/api/tags`, { signal:AbortSignal.timeout(1200) });
      if (!tags.ok) throw new Error('OLLAMA_NOT_READY');
      const data = await tags.json();
      const models = Array.isArray(data?.models) ? data.models : [];
      if (!models.length) throw new Error('OLLAMA_NO_MODEL');
      const preferred = ['qwen2.5:3b','llama3.2:3b','phi4-mini','qwen3:4b','gemma3:4b'];
      model = preferred.map(x=>models.find(m=>String(m.name||'').toLowerCase().startsWith(x))?.name).find(Boolean)
        || [...models].sort((a,b)=>(Number(a.size)||Infinity)-(Number(b.size)||Infinity))[0]?.name || '';
      if (!model) throw new Error('OLLAMA_NO_MODEL');
      this.ollamaModelCache={name:model,at:Date.now()};
    }
    const messages = [
      { role:'system', content:this.systemPrompt(memory) },
      ...this.session.slice(-6).map(m => ({role:m.role, content:m.text})),
      { role:'user', content:text }
    ];
    const res = await fetch(`${base}/api/chat`, { method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify({model,messages,stream:false,think:false,keep_alive:'60m',options:{num_ctx:2048,num_predict:160,temperature:0.4}}), signal:AbortSignal.timeout(30000) });
    if (!res.ok) throw new Error(`OLLAMA_HTTP_${res.status}`);
    const data = await res.json();
    const message = String(data?.message?.content || '').trim();
    if (!message) throw new Error('OLLAMA_EMPTY_RESPONSE');
    return { message, provider:'local', model };
  }

  async chat(text) {
    const memory = this.relevantMemory(text);
    const order = String(process.env.DNA_BRAIN_ORDER || 'ollama,gemini').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean);
    let lastError = '';
    for (const provider of order) {
      try {
        const result = provider === 'ollama' ? await this.callOllama(text, memory) : provider === 'gemini' ? await this.callGemini(text, memory) : null;
        if (!result) continue;
        this.pushSession('user', text);
        this.pushSession('assistant', result.message);
        return { ok:true, message:result.message, intent:'AI_QUERY', provider:result.provider, model:result.model };
      } catch (e) { lastError = e.message || String(e); }
    }
    console.error('[DNA.AI][BRAIN]', lastError);
    const quota = /quota|rate|429|resource_exhausted/i.test(lastError);
    return { ok:false, message: quota ? 'My online brain is rate-limited right now, but local computer commands still work.' : 'My local conversational model is not installed yet. PC commands still work; install an Ollama model once to enable full conversation.', intent:'AI_UNAVAILABLE' };
  }
}

module.exports = { DNABrain };
