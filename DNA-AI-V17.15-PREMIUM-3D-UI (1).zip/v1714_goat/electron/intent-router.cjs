function clean(text){
  return String(text||'').toLowerCase().replace(/[“”"'`]/g,'').replace(/[.,!?;:]+$/g,'').replace(/\s+/g,' ').trim()
    .replace(/^\s*(?:hey\s+|okay\s+|ok\s+|yo\s+)?(?:d\s*n\s*a|dna)(?:\s+ai)?[ ,:-]*/i,'')
    .replace(/\bplease\b/g,'').replace(/\b(?:zara|jara|bhai|bro)\b/g,'').replace(/\s+/g,' ').trim();
}
function parseYouTube(text){
  const s=clean(text);
  const patterns=[
    // Natural compound forms: "open yt and play CarryMinati", "open youtube then play X"
    /^(?:open|launch|start)\s+(?:youtube|you tube|yt)\s+(?:and\s+then|then|and|aur|phir)?\s*(?:play|chalao|chala do|chala|laga|laga do)\s+(.+)$/,
    /^(?:open|launch|start)\s+(?:youtube|you tube|yt)\s+(?:and\s+then|then|and|aur|phir)?\s*(?:search(?:\s+for)?|search karo|search kar)\s+(.+)$/,
    /^(?:play|chalao|chala do|chala|laga|laga do)\s+(.+?)\s+(?:on|in|at|pe|par)\s+(?:youtube|you tube|yt)$/,
    /^(?:youtube|you tube|yt)(?:\s+pe|\s+par)?\s+(.+?)\s+(?:play|chalao|chala do|chala|laga|laga do)$/,
    /^(?:youtube|you tube|yt)(?:\s+pe|\s+par)?\s+(?:play|chalao|chala do|chala|laga|laga do)\s+(.+)$/,
    /^(.+?)\s+(?:youtube|you tube|yt)\s+(?:pe|par)\s+(?:play|chalao|chala do|chala|laga|laga do)$/,
    /^(?:youtube|you tube|yt)\s+(?:search(?:\s+for)?|search karo|search kar)\s+(.+)$/,
    /^(?:search(?:\s+for)?|search karo|search kar)\s+(.+?)\s+(?:on|pe|par)\s+(?:youtube|you tube|yt)$/,
    /^(?:youtube|you tube|yt)\s+(.+)$/
  ];
  for(const rx of patterns){const m=s.match(rx);if(m&&m[1])return {intent:'YOUTUBE_PLAY',query:m[1].trim()};}
  if(/^(?:play|chalao|chala do|chala|laga|laga do)\s+(?:some\s+)?music(?:\s+(?:on|at|pe|par)\s+(?:youtube|you tube|yt))?$/.test(s)) return {intent:'YOUTUBE_PLAY',query:'music'};
  return null;
}
function parseSearch(text){
  const s=clean(text);
  let m=s.match(/^(?:google search|search for|search karo|search kar|search|google)\s+(.+?)(?:\s+(?:on|pe|par)\s+google)?$/);
  if(m&&m[1]) return {intent:'WEB_SEARCH',query:m[1].trim()};
  m=s.match(/^google(?:\s+pe|\s+par)?\s+(.+?)\s+(?:search|search karo|search kar)$/);
  if(m&&m[1]) return {intent:'WEB_SEARCH',query:m[1].trim()};
  return null;
}
function parseOpen(text){
 const s=clean(text);
 const m=s.match(/^(?:open|launch|start|run)\s+(?:the\s+)?(.+?)(?:\s+(?:open\s+kar|khol(?:o)?|khol\s+do))?$/) || s.match(/^(.+?)\s+(?:kholo|khol do|khol|open kar|open karo)$/);
 return m&&m[1]?{intent:'OPEN',target:m[1].trim()}:null;
}
function classify(text){return parseYouTube(text)||parseSearch(text)||parseOpen(text)||{intent:'AI_QUERY'};}
module.exports={clean,parseYouTube,parseSearch,parseOpen,classify};
