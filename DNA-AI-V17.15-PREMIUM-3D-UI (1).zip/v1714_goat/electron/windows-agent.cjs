const { execFile, spawn } = require('node:child_process');
const fs = require('node:fs');

function psQuote(v){ return `'${String(v).replace(/'/g,"''")}'`; }
function ps(script, timeout=12000){ return new Promise((resolve,reject)=>execFile('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-Command',script],{windowsHide:true,timeout,maxBuffer:2*1024*1024},(e,o,er)=>e?reject(new Error(String(er||e.message).trim())):resolve(String(o||'').trim()))); }

const PROCESS_NAMES={calculator:'CalculatorApp',notepad:'Notepad',chrome:'chrome',edge:'msedge',firefox:'firefox','vs code':'Code',spotify:'Spotify',whatsapp:'WhatsApp',discord:'Discord',telegram:'Telegram',paint:'mspaint'};

class WindowsAgent {
  async isRunning(target){ const p=PROCESS_NAMES[String(target).toLowerCase()]; if(!p)return null; try{ const out=await ps(`@(Get-Process -Name ${psQuote(p)} -ErrorAction SilentlyContinue).Count`); return Number(out)>0; }catch{return false;} }
  async waitRunning(target, timeoutMs=6000){ const known=PROCESS_NAMES[String(target).toLowerCase()]; if(!known)return {verified:false,reason:'no-process-mapping'}; const end=Date.now()+timeoutMs; while(Date.now()<end){ if(await this.isRunning(target))return {verified:true}; await new Promise(r=>setTimeout(r,300)); } return {verified:false,reason:'process-not-observed'}; }
  async setVolume(percent){ const n=Math.max(0,Math.min(100,Math.round(Number(percent)))); await ps(`$w=New-Object -ComObject WScript.Shell; 1..50|%{$w.SendKeys([char]174)}; 1..${Math.round(n/2)}|%{$w.SendKeys([char]175)}`); return n; }
  async volumeStep(direction,steps=3){ const key=direction==='down'?174:175; await ps(`$w=New-Object -ComObject WScript.Shell; 1..${Math.max(1,Math.min(20,steps))}|%{$w.SendKeys([char]${key})}`); return true; }
  async mute(){ await ps(`$w=New-Object -ComObject WScript.Shell; $w.SendKeys([char]173)`); return true; }
  async lock(){ await ps(`rundll32.exe user32.dll,LockWorkStation`); return true; }
  async hasWinAppCli(){ try{ await ps(`$c=Get-Command winapp -ErrorAction Stop; $c.Source`); return true; }catch{return false;} }
  async uiInspect(appName){ if(!(await this.hasWinAppCli())) return {ok:false,message:'Structured Windows UI Automation is not installed.'}; return new Promise((resolve)=>{ execFile('winapp',['ui','inspect','-a',String(appName),'--json'],{windowsHide:true,timeout:12000,maxBuffer:4*1024*1024},(e,o,er)=>{ if(e)return resolve({ok:false,message:String(er||e.message)}); try{return resolve({ok:true,data:JSON.parse(o)});}catch{return resolve({ok:true,text:String(o)});} }); }); }
  async uiInvoke(appName,selector){ if(!(await this.hasWinAppCli())) return {ok:false,message:'Structured Windows UI Automation is not installed.'}; return new Promise((resolve)=>{ execFile('winapp',['ui','invoke',String(selector),'-a',String(appName),'--json'],{windowsHide:true,timeout:12000,maxBuffer:2*1024*1024},(e,o,er)=>resolve(e?{ok:false,message:String(er||e.message)}:{ok:true,output:String(o)})); }); }
}
module.exports={WindowsAgent};
