const fs = require('node:fs');
const path = require('node:path');

class ImageAgent {
  constructor({ downloadsDir }) {
    this.downloadsDir = downloadsDir;
    this.base = (process.env.COMFYUI_HOST || 'http://127.0.0.1:8188').replace(/\/$/, '');
  }
  async json(url, options={}) {
    const res = await fetch(url, { ...options, signal: AbortSignal.timeout(Number(process.env.DNA_IMAGE_TIMEOUT_MS || 120000)) });
    if (!res.ok) throw new Error(`IMAGE_HTTP_${res.status}`);
    return res.json();
  }
  async health() {
    try { await this.json(`${this.base}/object_info`); return {ok:true, provider:'ComfyUI'}; }
    catch (e) { return {ok:false, message:'Local image engine is not running. Start ComfyUI once, then retry.', error:e.message}; }
  }
  async firstCheckpoint() {
    const info = await this.json(`${this.base}/object_info/CheckpointLoaderSimple`);
    const list = info?.CheckpointLoaderSimple?.input?.required?.ckpt_name?.[0];
    if (!Array.isArray(list) || !list.length) throw new Error('NO_COMFYUI_CHECKPOINT');
    return process.env.DNA_IMAGE_CHECKPOINT || list[0];
  }
  workflow(prompt, checkpoint, width=1024, height=1024) {
    const negative = process.env.DNA_IMAGE_NEGATIVE || 'blurry, low quality, distorted, watermark, unreadable text';
    const seed = Math.floor(Math.random()*2147483647);
    return {
      '1': {class_type:'CheckpointLoaderSimple', inputs:{ckpt_name:checkpoint}},
      '2': {class_type:'CLIPTextEncode', inputs:{text:prompt, clip:['1',1]}},
      '3': {class_type:'CLIPTextEncode', inputs:{text:negative, clip:['1',1]}},
      '4': {class_type:'EmptyLatentImage', inputs:{width,height,batch_size:1}},
      '5': {class_type:'KSampler', inputs:{seed,steps:Number(process.env.DNA_IMAGE_STEPS||24),cfg:Number(process.env.DNA_IMAGE_CFG||6.5),sampler_name:'euler',scheduler:'normal',denoise:1,model:['1',0],positive:['2',0],negative:['3',0],latent_image:['4',0]}},
      '6': {class_type:'VAEDecode', inputs:{samples:['5',0],vae:['1',2]}},
      '7': {class_type:'SaveImage', inputs:{filename_prefix:'DNA_AI',images:['6',0]}}
    };
  }
  async generate(prompt, options={}) {
    const text=String(prompt||'').trim(); if(!text)return {ok:false,message:'Image prompt is empty.'};
    try {
      fs.mkdirSync(this.downloadsDir,{recursive:true});
      const checkpoint=await this.firstCheckpoint();
      const width=Math.max(512,Math.min(1536,Number(options.width||1024)));
      const height=Math.max(512,Math.min(1536,Number(options.height||1024)));
      const queued=await this.json(`${this.base}/prompt`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({prompt:this.workflow(text,checkpoint,width,height)})});
      const id=queued.prompt_id; if(!id)throw new Error('NO_PROMPT_ID');
      const deadline=Date.now()+Number(process.env.DNA_IMAGE_TIMEOUT_MS||120000);
      while(Date.now()<deadline){
        await new Promise(r=>setTimeout(r,1000));
        const history=await this.json(`${this.base}/history/${encodeURIComponent(id)}`);
        const outputs=history?.[id]?.outputs||{};
        for(const node of Object.values(outputs)) for(const image of (node.images||[])) {
          const params=new URLSearchParams({filename:image.filename,subfolder:image.subfolder||'',type:image.type||'output'});
          const res=await fetch(`${this.base}/view?${params}`,{signal:AbortSignal.timeout(30000)}); if(!res.ok)continue;
          const ext=path.extname(image.filename)||'.png'; const out=path.join(this.downloadsDir,`DNA-AI-${Date.now()}${ext}`);
          fs.writeFileSync(out,Buffer.from(await res.arrayBuffer()));
          return {ok:true,path:out,message:`Image created and saved to Downloads as ${path.basename(out)}.`,provider:'local-comfyui',checkpoint};
        }
      }
      throw new Error('IMAGE_GENERATION_TIMEOUT');
    } catch(e) { return {ok:false,message:e.message==='NO_COMFYUI_CHECKPOINT'?'ComfyUI is running but no image checkpoint is installed.':'Local image generation is unavailable. Start/configure ComfyUI and retry.',error:e.message}; }
  }
}
module.exports={ImageAgent};
