const fs=require('node:fs'); const path=require('node:path'); const crypto=require('node:crypto');
class RuntimeGuard{
 constructor(userDataDir){this.dir=userDataDir;this.audit=path.join(userDataDir,'dna-audit.jsonl');}
 classify(intent){
  const destructive=new Set(['LOCK_PC','WHATSAPP_SEND']);
  const sensitive=new Set(['SCREEN_VISION','SCREENSHOT','CLIPBOARD_READ','CHATGPT_IMAGE_DOWNLOAD','WHATSAPP_BROWSER_DRAFT','UI_INVOKE']);
  return destructive.has(intent)?'confirm':sensitive.has(intent)?'sensitive':'normal';
 }
 record(row){try{fs.mkdirSync(this.dir,{recursive:true});const clean={at:new Date().toISOString(),id:crypto.randomUUID(),...row};fs.appendFileSync(this.audit,JSON.stringify(clean)+'\n','utf8');}catch{}}
 health(){return {platform:process.platform,node:process.version,auditFile:this.audit};}
}
module.exports={RuntimeGuard};
