const path = require('node:path');
const fs = require('node:fs');

class BrowserAgent {
  constructor({ userDataDir, downloadsDir }) {
    this.userDataDir = path.join(userDataDir, 'browser-agent-profile');
    this.downloadsDir = downloadsDir;
    this.context = null;
  }

  async ensure() {
    if (this.context) return this.context;
    const { chromium } = require('playwright');
    fs.mkdirSync(this.userDataDir, { recursive: true });
    this.context = await chromium.launchPersistentContext(this.userDataDir, {
      channel: 'msedge',
      headless: false,
      acceptDownloads: true,
      viewport: null,
      args: ['--start-maximized'],
    });
    this.context.on('close', () => { this.context = null; });
    return this.context;
  }

  async pageFor(urlPart, fallbackUrl) {
    const ctx = await this.ensure();
    let page = ctx.pages().find(p => p.url().includes(urlPart));
    if (!page) {
      page = ctx.pages()[0] || await ctx.newPage();
      if (fallbackUrl) await page.goto(fallbackUrl, { waitUntil: 'domcontentloaded' });
    }
    await page.bringToFront();
    return page;
  }

  async open(url) {
    const ctx = await this.ensure();
    const page = ctx.pages()[0] || await ctx.newPage();
    await page.goto(url, { waitUntil: 'domcontentloaded' });
    await page.bringToFront();
    return { ok: true, url: page.url() };
  }

  async playYouTube(query) {
    const q = String(query || '').trim();
    if (!q) return { ok:false, message:'Tell me what you want to play.' };
    const ctx = await this.ensure();
    let page = ctx.pages().find(p => p.url().includes('youtube.com')) || await ctx.newPage();
    try {
      await page.goto(`https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`, { waitUntil:'domcontentloaded', timeout:9000 });
      const first = page.locator('ytd-video-renderer a#thumbnail, ytd-rich-item-renderer a#thumbnail').first();
      await first.waitFor({ state:'visible', timeout:6000 });
      await first.click();
      await page.waitForURL(/youtube\.com\/watch\?v=/, { timeout:6000 });
      await page.bringToFront();
      const video = page.locator('video').first();
      await video.waitFor({ state:'attached', timeout:3500 }).catch(()=>{});
      await video.evaluate(v => { v.muted = false; return v.play(); }).catch(()=>{});
      await page.waitForTimeout(250);
      const state = await video.evaluate(v => ({ paused:v.paused, currentTime:v.currentTime, readyState:v.readyState })).catch(()=>null);
      if (state && !state.paused) return { ok:true, message:`Playing ${q} on YouTube.`, url:page.url(), playback:state };
      // Browser autoplay policy can occasionally require a trusted click; click the native play button and verify again.
      const playButton = page.getByRole('button', { name:/play/i }).first();
      if (await playButton.count().catch(()=>0)) await playButton.click({ timeout:1800 }).catch(()=>{});
      await page.waitForTimeout(250);
      const verified = await video.evaluate(v => !v.paused).catch(()=>false);
      return verified
        ? { ok:true, message:`Playing ${q} on YouTube.`, url:page.url() }
        : { ok:false, message:`I opened ${q} on YouTube, but playback did not start.`, url:page.url() };
    } catch (e) {
      return { ok:false, message:`I couldn't start ${q} on YouTube.`, error:String(e?.message || e) };
    }
  }

  async inspectActivePageForAI() {
    const ctx = await this.ensure();
    const pages = ctx.pages();
    const page = pages[pages.length - 1] || await ctx.newPage();
    await page.bringToFront();
    let snapshot = '';
    try { snapshot = await page.locator('body').ariaSnapshot({ mode:'ai', boxes:true, depth:12, timeout:5000 }); }
    catch { snapshot = await page.locator('body').ariaSnapshot({ timeout:5000 }).catch(()=> ''); }
    return { ok:true, url:page.url(), title:await page.title().catch(()=>''), snapshot:String(snapshot).slice(0,30000) };
  }

  async clickAccessible(name) {
    const ctx=await this.ensure(); const pages=ctx.pages(); const page=pages[pages.length-1]||await ctx.newPage();
    const q=String(name||'').trim(); if(!q)return {ok:false,message:'Missing browser control name.'};
    const roles=['button','link','menuitem','tab','checkbox','radio'];
    for(const role of roles){
      const loc=page.getByRole(role,{name:new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'i')}).first();
      if(await loc.count().catch(()=>0)){ try{await loc.click({timeout:5000});return{ok:true,message:`Clicked ${q}.`,role};}catch{} }
    }
    const text=page.getByText(q,{exact:false}).first();
    if(await text.count().catch(()=>0)){try{await text.click({timeout:5000});return{ok:true,message:`Clicked ${q}.`,role:'text'};}catch{}}
    return {ok:false,message:`I could not find an accessible browser control named ${q}.`};
  }

  async chatgptLatestImageDownload() {
    const page = await this.pageFor('chatgpt.com', 'https://chatgpt.com/');
    if (/auth|login/i.test(page.url())) return { ok:false, needsLogin:true, message:'ChatGPT is not signed in inside the DNA browser profile. Sign in once, then retry.' };

    // Prefer explicit download controls attached to the latest generated image.
    const candidates = [
      page.getByRole('button', { name: /download/i }),
      page.locator('button[aria-label*="Download" i]'),
      page.locator('a[download]'),
    ];
    for (const locator of candidates) {
      const count = await locator.count().catch(() => 0);
      if (!count) continue;
      const target = locator.nth(count - 1);
      try {
        const downloadPromise = page.waitForEvent('download', { timeout: 8000 });
        await target.click();
        const download = await downloadPromise;
        const filename = download.suggestedFilename() || `chatgpt-image-${Date.now()}.png`;
        const out = path.join(this.downloadsDir, filename);
        await download.saveAs(out);
        return { ok:true, path:out, message:`Downloaded ${filename} to Downloads.` };
      } catch {}
    }
    return { ok:false, message:'I could not find a downloadable generated image on the current ChatGPT page.' };
  }

  async whatsappDraft(contactName, message) {
    const page = await this.pageFor('web.whatsapp.com', 'https://web.whatsapp.com/');
    // User signs in by QR once; persistent profile keeps the session.
    const search = page.locator('[contenteditable="true"][data-tab="3"], [contenteditable="true"][aria-label*="Search" i]').first();
    if (!(await search.count())) return { ok:false, needsLogin:true, message:'WhatsApp Web is not ready in the DNA browser profile. Sign in once and retry.' };
    await search.click();
    await search.fill(contactName).catch(async()=>{ await search.pressSequentially(contactName); });
    await page.waitForTimeout(1200);
    const result = page.getByText(contactName, { exact:false }).first();
    if (!(await result.count())) return { ok:false, message:`I could not find ${contactName} in WhatsApp.` };
    await result.click();
    const box = page.locator('footer [contenteditable="true"]').last();
    if (!(await box.count())) return { ok:false, message:'WhatsApp message box was not available.' };
    await box.click();
    await box.fill(message).catch(async()=>{ await box.pressSequentially(message); });
    return { ok:true, message:`Message to ${contactName} is ready in WhatsApp. Say "send it" to confirm.` };
  }

  async whatsappSend(contactName, message) {
    const name=String(contactName||'').trim(); const text=String(message||'').trim();
    if(!name || !text) return {ok:false,message:'Tell me the WhatsApp contact and message.'};
    const page = await this.pageFor('web.whatsapp.com', 'https://web.whatsapp.com/');
    const search = page.locator('[contenteditable="true"][data-tab="3"], [contenteditable="true"][aria-label*="Search" i]').first();
    if (!(await search.count())) return {ok:false,needsLogin:true,message:'WhatsApp Web needs a one-time sign-in inside DNA.AI.'};
    try {
      await search.click(); await search.fill(''); await search.fill(name).catch(async()=>{await search.pressSequentially(name)});
      await page.waitForTimeout(1000);
      const result=page.getByText(name,{exact:false}).first();
      if(!(await result.count())) return {ok:false,message:`I could not find ${name} in WhatsApp.`};
      await result.click();
      const box=page.locator('footer [contenteditable="true"]').last();
      if(!(await box.count())) return {ok:false,message:'WhatsApp message box is unavailable.'};
      await box.click(); await box.fill(text).catch(async()=>{await box.pressSequentially(text)});
      await box.press('Enter'); await page.waitForTimeout(250);
      const outgoing=page.locator('div.message-out').filter({hasText:text}).last();
      const verified=(await outgoing.count().catch(()=>0))>0;
      return verified?{ok:true,message:`Sent to ${name}.`}:{ok:false,message:`I typed the message to ${name}, but could not verify that WhatsApp sent it.`};
    } catch(e) { return {ok:false,message:`I couldn't send the WhatsApp message to ${name}.`,error:String(e?.message||e)}; }
  }

  async researchWeb(query) {
    const q = String(query || '').trim();
    if (!q) return { ok:false, message:'Research query is empty.', results:[] };
    const ctx = await this.ensure();
    const searchPage = await ctx.newPage();
    try {
      await searchPage.goto(`https://www.google.com/search?q=${encodeURIComponent(q)}`, { waitUntil:'domcontentloaded', timeout:20000 });
      const hits = await searchPage.locator('a:has(h3)').evaluateAll((nodes) => nodes.slice(0,6).map(a => ({
        title:(a.querySelector('h3')?.innerText||'').trim(), url:a.href||''
      })).filter(x=>x.title && /^https?:/i.test(x.url)));
      const results=[];
      for (const hit of hits.slice(0,4)) {
        const p=await ctx.newPage();
        try {
          await p.goto(hit.url,{waitUntil:'domcontentloaded',timeout:15000});
          const extracted=await p.evaluate(()=>{
            const bad=['script','style','nav','footer','header','aside','form']; bad.forEach(t=>document.querySelectorAll(t).forEach(n=>n.remove()));
            const main=document.querySelector('main,article,[role="main"]')||document.body;
            const text=(main?.innerText||'').replace(/\s+/g,' ').trim();
            return {title:document.title||'',text:text.slice(0,6500)};
          });
          if(extracted.text.length>120) results.push({title:hit.title||extracted.title,url:p.url(),snippet:extracted.text});
        } catch {} finally { await p.close().catch(()=>{}); }
      }
      return { ok:results.length>0, results, message:results.length?`Read ${results.length} current web sources.`:'I found search results but could not read reliable source text.' };
    } finally { await searchPage.close().catch(()=>{}); }
  }

  async sendCurrentWhatsAppDraft() {
    const page = await this.pageFor('web.whatsapp.com', 'https://web.whatsapp.com/');
    const send = page.getByRole('button', { name:/send/i }).last();
    if (await send.count()) { await send.click(); return {ok:true,message:'Sent.'}; }
    const box = page.locator('footer [contenteditable="true"]').last();
    if (await box.count()) { await box.press('Enter'); return {ok:true,message:'Sent.'}; }
    return {ok:false,message:'There is no WhatsApp draft ready to send.'};
  }
}

module.exports = { BrowserAgent };
