const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('dnaDesktop', {
  executeCommand: command => ipcRenderer.invoke('dna:execute-command', command),
  schedules: () => ipcRenderer.invoke('dna:schedules'), scheduleCancel: id => ipcRenderer.invoke('dna:schedule-cancel', id),
  onScheduleFired: cb => { const h=(_e,v)=>cb(v); ipcRenderer.on('dna:schedule-fired',h); return ()=>ipcRenderer.removeListener('dna:schedule-fired',h); },
  getSystemMetrics: () => ipcRenderer.invoke('dna:system-metrics'), health: () => ipcRenderer.invoke('dna:health'),
  voiceStart: () => ipcRenderer.invoke('dna:voice-start'), voiceStop: () => ipcRenderer.invoke('dna:voice-stop'), voiceToggle: () => ipcRenderer.invoke('dna:voice-toggle'), voiceState: () => ipcRenderer.invoke('dna:voice-state'),
  speak: text => ipcRenderer.invoke('dna:speak', text),
  onVoiceState: cb => { const h=(_e,v)=>cb(v); ipcRenderer.on('dna:voice-state',h); return ()=>ipcRenderer.removeListener('dna:voice-state',h); },
  onVoiceTranscript: cb => { const h=(_e,v)=>cb(v); ipcRenderer.on('dna:voice-transcript',h); return ()=>ipcRenderer.removeListener('dna:voice-transcript',h); },
  onVoiceResult: cb => { const h=(_e,v)=>cb(v); ipcRenderer.on('dna:voice-result',h); return ()=>ipcRenderer.removeListener('dna:voice-result',h); },
  onWakeDetected: cb => { const h=(_e,v)=>cb(v); ipcRenderer.on('dna:wake-detected',h); return ()=>ipcRenderer.removeListener('dna:wake-detected',h); },
  hideAssistant: () => ipcRenderer.invoke('dna:assistant-hide'), showDashboard: () => ipcRenderer.invoke('dna:dashboard-show'),
  configStatus: () => ipcRenderer.invoke('dna:config-status'), saveApiKey: key => ipcRenderer.invoke('dna:config-save-key', key), openSettings: () => ipcRenderer.invoke('dna:config-open'), browserLogin: service => ipcRenderer.invoke('dna:browser-login', service),
  captureScreen: () => ipcRenderer.invoke('dna:screen-capture'), screenClick: (x,y) => ipcRenderer.invoke('dna:screen-click',x,y), screenType: text => ipcRenderer.invoke('dna:screen-type',text),
  clipboardRead: () => ipcRenderer.invoke('dna:clipboard-read'), clipboardWrite: text => ipcRenderer.invoke('dna:clipboard-write', text), runtime: { electron:true, platform:process.platform }
});
