const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

class DNAScheduler {
  constructor({ userDataDir, onFire }) {
    this.file = path.join(userDataDir, 'dna-schedules.json');
    this.onFire = onFire;
    this.items = [];
    this.timer = null;
    this.load();
  }
  load(){ try { this.items = JSON.parse(fs.readFileSync(this.file,'utf8')); if(!Array.isArray(this.items)) this.items=[]; } catch { this.items=[]; } }
  save(){ fs.mkdirSync(path.dirname(this.file),{recursive:true}); fs.writeFileSync(this.file,JSON.stringify(this.items,null,2)); }
  add({at,label,type='reminder',repeat=null}){
    const when = new Date(at); if(!Number.isFinite(when.getTime())) throw new Error('Invalid schedule time');
    const item={id:crypto.randomUUID(),at:when.toISOString(),label:String(label||'Reminder'),type,repeat,createdAt:new Date().toISOString(),enabled:true};
    this.items.push(item); this.save(); this.arm(); return item;
  }
  list(){ return this.items.filter(x=>x.enabled).sort((a,b)=>new Date(a.at)-new Date(b.at)); }
  cancel(id){ const x=this.items.find(i=>i.id===id); if(!x)return false; x.enabled=false; this.save(); this.arm(); return true; }
  nextDate(item){ const d=new Date(item.at); if(item.repeat==='daily') d.setDate(d.getDate()+1); else if(item.repeat==='weekly') d.setDate(d.getDate()+7); else return null; return d; }
  arm(){
    if(this.timer){clearTimeout(this.timer);this.timer=null;}
    const next=this.list().find(x=>new Date(x.at).getTime()>Date.now()-1000); if(!next)return;
    const delay=Math.max(0,Math.min(2147483000,new Date(next.at).getTime()-Date.now()));
    this.timer=setTimeout(()=>this.fireDue(),delay);
  }
  async fireDue(){
    const now=Date.now(); const due=this.items.filter(x=>x.enabled && new Date(x.at).getTime()<=now+1000);
    for(const item of due){
      try{await this.onFire(item);}catch(e){console.error('[DNA.AI][SCHEDULER]',e.message);}
      const n=this.nextDate(item); if(n)item.at=n.toISOString(); else item.enabled=false;
    }
    this.save(); this.arm();
  }
}

function parseClock(hour, minute, ampm){
  let h=Number(hour), m=Number(minute||0); if(ampm){ const a=ampm.toLowerCase(); if(a==='pm'&&h<12)h+=12; if(a==='am'&&h===12)h=0; } return {h,m};
}
function parseScheduleCommand(text, now=new Date()){
  const s=String(text).trim();
  let m=s.match(/^(?:set\s+)?(?:a\s+)?timer\s+(?:for\s+)?(\d+)\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)(?:\s+(?:for|called|named)\s+(.+))?$/i) || s.match(/^(\d+)\s*(second|minute|hour)s?\s+(?:ka\s+)?timer\s+(?:laga(?:o| do)?|set karo)?(?:\s+(.+))?$/i);
  if(m){ const n=Number(m[1]); const u=m[2].toLowerCase(); const ms=u.startsWith('sec')?n*1000:u.startsWith('hour')||u.startsWith('hr')?n*3600000:n*60000; return {at:new Date(now.getTime()+ms),label:m[3]||'Timer complete',type:'timer'}; }
  m=s.match(/^(?:set\s+)?(?:an?\s+)?(?:alarm|reminder)(?:\s+for)?\s+(?:(tomorrow|kal)\s+)?(?:at\s+)?(\d{1,2})(?::(\d{2}))?\s*(am|pm)?(?:\s+(?:for|to)\s+(.+))?$/i) || s.match(/^(?:(kal)\s+)?(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\s+(?:baje\s+)?(?:ka\s+)?(?:alarm|reminder)\s+(?:laga(?:o| do)?|set karo)?(?:\s+(.+))?$/i);
  if(m){ const tomorrow=Boolean(m[1]); const {h,m:mi}=parseClock(m[2],m[3],m[4]); const d=new Date(now); d.setHours(h,mi,0,0); if(tomorrow||d<=now)d.setDate(d.getDate()+1); return {at:d,label:m[5]||'Alarm',type:'alarm'}; }
  m=s.match(/^(?:remind me|mujhe yaad dilana)\s+(?:in\s+)?(\d+)\s*(minutes?|mins?|hours?|hrs?)\s+(?:to\s+)?(.+)$/i);
  if(m){ const n=Number(m[1]); const ms=/hour|hr/i.test(m[2])?n*3600000:n*60000; return {at:new Date(now.getTime()+ms),label:m[3],type:'reminder'}; }
  return null;
}
module.exports={DNAScheduler,parseScheduleCommand};
