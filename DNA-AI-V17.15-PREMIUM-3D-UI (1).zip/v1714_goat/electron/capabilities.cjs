// Canonical machine-readable capability registry. Keep claims separate from runtime verification.
const CAPABILITIES = Object.freeze({
  wake:{local:true, verified:false, engine:'faster-whisper / Windows fallback'},
  stt:{local:true, verified:false, languages:['en','hi','Hinglish']},
  tts:{localOrCloud:true, verified:false, providers:['edge-tts','Gemini TTS','Windows fallback']},
  localActions:{local:true, verified:false, examples:['apps','files','volume','lock','clipboard']},
  browser:{persistentProfile:true, verified:false, modes:['DOM','accessibility']},
  vision:{cloudOptional:true, verified:false},
  memory:{persistent:true, verified:false, retrieval:'weighted lexical + recency + explicit importance'},
  whatsapp:{confirmationRequired:true, verified:false},
  imageGeneration:{local:true, verified:false, providers:['ComfyUI'], output:'Downloads'},
  actionAudit:{persistent:true, verified:false},
});
function report(){ return JSON.parse(JSON.stringify(CAPABILITIES)); }
// V8: persistent local scheduling is implemented in scheduler.cjs.
// Capability: alarms_reminders — local, persistent across restarts, notification + spoken trigger.
module.exports={CAPABILITIES,report};
