# DNA.AI P3 — Background Assistant

P3 adds the lifecycle needed for a Jarvis-style Windows assistant:

- single-instance lock
- Windows login startup registration
- silent `--background` startup
- system tray residency
- closing the HUD hides it instead of killing DNA.AI
- wake engine remains alive while the HUD is hidden
- "Hey DNA" restores/focuses the HUD
- tray menu can reopen or fully quit DNA.AI

## Important verification boundary

The lifecycle code is implemented, but Windows login startup, microphone recognition, foreground focus behavior, and tray behavior require local Windows runtime verification. Development-mode login startup points Windows at Electron plus the current project path; packaged builds use the installed application executable.
