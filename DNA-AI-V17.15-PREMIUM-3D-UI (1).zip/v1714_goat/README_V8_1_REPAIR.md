# DNA.AI 8.1 — repaired canonical Windows build

This revision fixes the failures observed during V8 runtime testing.

- Wake engine no longer depends on Whisper being preinstalled. It always has a zero-install Windows Speech fallback.
- The Windows fallback uses continuous dictation plus wake alias normalization, including the observed `AT&T` hypothesis for spoken `Hey DNA`.
- Whisper remains an optional higher-quality multilingual STT path when its Python dependencies are present.
- Gemini is no longer a first-run requirement and the API-key setup window does not block launch.
- Ollama automatically selects an installed local model instead of assuming `qwen3:8b` exists.
- `SETUP_DNA_BRAIN.bat` installs Ollama through winget and pulls `qwen3:4b` as a one-time local brain setup.
- Natural speech keeps Edge neural TTS first, Gemini TTS optional, and Windows System.Speech as the no-install fallback.
- UI version display is corrected to 8.1.0 and voice waveform treats passive wake listening / awake / speaking as active states.
- Existing local Windows commands, scheduler, browser agent, image agent, memory, WhatsApp, screen tools and safety guard remain in the canonical source.

## Build
Double-click `BUILD_FINAL_WINDOWS.bat`. The resulting installer is `release\DNA.AI-Setup-8.1.0.exe`.

## Local conversational brain
Run `SETUP_DNA_BRAIN.bat` once. This is separate because the model is a large download and should not be hidden inside the application installer.

## Important
A source-level fix is not the same thing as runtime certification on every Windows PC. Wake recognition quality depends on the Windows speech recognizer or the optional Whisper path, microphone and acoustic environment.
