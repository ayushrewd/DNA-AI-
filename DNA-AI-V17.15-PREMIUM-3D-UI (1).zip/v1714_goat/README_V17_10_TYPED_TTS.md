# DNA.AI V17.10 — Typed TTS Fix

- Typed commands/questions now use the same final-response TTS path as voice input.
- Execution happens before speech, so app/site commands are not blocked by TTS.
- The existing anti-`alte alte` / repeated-garbage TTS filter remains active.
- MIC OFF affects microphone input only; typed replies can still be spoken.
- Existing typing UI, wake word, MIC toggle, sleep, router and voice protections are preserved.

Manual Windows test required for actual speaker output.
