# DNA.AI V17.11 — Single Female Voice

- Locked TTS to `en-IN-NeerjaNeural` (female).
- Removed Gemini TTS and Windows System.Speech fallback from the runtime speech path.
- If female Edge-TTS fails, DNA stays text-only for that reply instead of switching to a male voice.
- Added a single-TTS in-flight lock so two speech providers/calls cannot talk over each other.
- Existing typed replies, voice replies, anti-`aalte`, MIC toggle, wake word, sleep, commands and speed changes are preserved.
