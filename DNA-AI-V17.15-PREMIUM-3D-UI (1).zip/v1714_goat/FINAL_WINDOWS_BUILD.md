# DNA.AI Final Windows Build

## User experience
The end user does not run npm, Vite, localhost, VS Code, or PowerShell. Install `DNA.AI-Setup-0.7.0.exe`, launch DNA.AI, complete the first-run AI key screen once, then use the app normally. DNA.AI can start at Windows login and remain in the system tray.

## Developer build (one time)
On a Windows development machine with Node.js installed:
1. Double-click `BUILD_FINAL_WINDOWS.bat`.
2. The installer is written to `release/DNA.AI-Setup-0.7.0.exe`.

## Security boundaries
- Renderer uses context isolation and no Node integration.
- AI key is saved through Electron main process using Electron safeStorage when available.
- Local commands are routed before cloud AI and continue working during AI quota/provider outages.
- Broad app opening delegates unknown safe app names to the Windows shell instead of sending them to cloud AI.
- Destructive/admin operations are intentionally not granted silently. They require a future confirmation/permission layer.

## Runtime verification still required on the target Windows PC
Wake-word accuracy, microphone behavior, Windows login auto-start, arbitrary installed-app resolution, and installer behavior must be tested on the actual machine.
