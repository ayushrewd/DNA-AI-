# DNA.AI V6 — Limit Push Candidate

This is a canonical engineering candidate, not a claim of AGI or a perfect JARVIS.

## New in V6
- **One-breath wake + command:** `Hey DNA, calculator kholo` can be executed without forcing a second listening turn when Whisper captures the command in the wake utterance.
- **Improved persistent-memory retrieval:** weighted term rarity (IDF-like), stemming, recency and explicit-memory importance.
- **Machine-readable capability registry:** separates implemented capability claims from runtime verification status.
- Preserves V5 adaptive end-of-speech STT, local-first actions, browser accessibility control, action verification, screen vision, WhatsApp confirmation, persistent browser sessions, audit logging, model fallback, natural TTS, autostart and tray runtime.

## Hard boundaries
- No GPT-5.5 weights/training corpus are embedded or exportable.
- A dedicated acoustically trained custom `Hey DNA` model is not bundled.
- Windows microphone/UI reliability cannot be certified until acceptance tests pass on the target PC.
- Authenticated browser state remains sensitive and must stay local.

## Release rule
Do not call this production-ready until `ACCEPTANCE_TESTS_V6.md` passes on the target Windows machine.
