export {};
type DNAResult={ok:boolean;message:string;intent:string};
type VoiceState={state:string;lastTranscript:string;lastError:string;recognizer:string;wakeWord?:string;wakeDetectedAt?:number|null};
declare global { interface Window { dnaDesktop?: {
  executeCommand(command:string):Promise<DNAResult>; getSystemMetrics():Promise<{cpuCount:number;ramPercent:number;totalMemory:number;freeMemory:number;uptime:number;platform:string;hostname:string}>;
  health():Promise<Record<string,string>>; voiceStart():Promise<VoiceState>; voiceStop():Promise<VoiceState>; voiceToggle():Promise<VoiceState & {micEnabled?:boolean}>; voiceState():Promise<VoiceState>; speak(text:string):Promise<boolean>;
  onVoiceState(cb:(state:VoiceState)=>void):()=>void; onVoiceTranscript(cb:(text:string)=>void):()=>void; onVoiceResult(cb:(result:DNAResult)=>void):()=>void; onWakeDetected(cb:(event:{transcript:string;command:string})=>void):()=>void;
  hideAssistant():Promise<boolean>; showDashboard():Promise<boolean>;
  clipboardRead():Promise<string>; clipboardWrite(text:string):Promise<boolean>; runtime:{electron:boolean;platform:string};
}; } }
