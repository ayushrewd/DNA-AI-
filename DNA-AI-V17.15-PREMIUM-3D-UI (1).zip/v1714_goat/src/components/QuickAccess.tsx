import { motion } from 'framer-motion';
import { MessageSquare, Eye, Code2, Monitor, Settings } from 'lucide-react';

const ACTIONS = [
  { icon: MessageSquare, label: 'CHAT', action: 'focus', value: '' },
  { icon: Eye, label: 'VISION', action: 'prefill', value: 'open camera' },
  { icon: Code2, label: 'CODE', action: 'prefill', value: 'open vs code' },
  { icon: Monitor, label: 'SYSTEM', action: 'prefill', value: 'open task manager' },
  { icon: Settings, label: 'SETTINGS', action: 'prefill', value: 'open settings' },
];
export function QuickAccess() {
  const fire=(action:string,value:string)=>window.dispatchEvent(new CustomEvent('dna:quick-access',{detail:{action,value}}));
  return <motion.div initial={{opacity:0,x:20}} animate={{opacity:1,x:0}} transition={{duration:.5,delay:.4}} className="hud-panel p-3 flex flex-col" style={{height:'110px'}}>
    <div className="flex items-center gap-2 mb-2"><div className="w-1.5 h-1.5 bg-cyan-glow"/><h2 className="text-xs tracking-widest opacity-80">QUICK ACCESS</h2></div>
    <div className="flex justify-between items-center flex-1 px-1">{ACTIONS.map(({icon:Icon,label,action,value})=><button key={label} type="button" className="dna-quick-button flex flex-col items-center gap-1 group" title={`${label} quick action`} onClick={()=>fire(action,value)}>
      <div className="dna-quick-icon w-9 h-9 flex items-center justify-center border border-[rgba(69,239,255,0.38)] rounded"><Icon size={15} className="text-cyan-glow opacity-80 group-hover:opacity-100"/></div>
      <span className="text-[8px] tracking-widest opacity-60 group-hover:opacity-100 font-tech">{label}</span>
    </button>)}</div>
  </motion.div>;
}
