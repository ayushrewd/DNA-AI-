import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

function genInitialBars(count: number): number[] {
  // Produce a realistic-looking activity chart with varied heights
  return Array.from({ length: count }, (_, i) => {
    const base = 20 + Math.sin(i * 0.4) * 15;
    const spike = i > count * 0.6 ? Math.random() * 55 : Math.random() * 35;
    return Math.max(8, Math.min(95, base + spike));
  });
}

export function SystemActivity() {
  const [bars, setBars] = useState<number[]>(() => genInitialBars(32));

  useEffect(() => {
    const interval = setInterval(() => {
      setBars(prev => {
        const next = [...prev.slice(1)];
        const last = prev[prev.length - 1];
        const diff = (Math.random() - 0.48) * 45;
        next.push(Math.max(8, Math.min(95, last + diff)));
        return next;
      });
    }, 400);
    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
      className="hud-panel p-3 flex flex-col"
      style={{ height: '150px' }}
    >
      <div className="flex items-center gap-2 mb-2">
        <div className="w-1.5 h-1.5 bg-cyan-glow" />
        <h2 className="text-xs tracking-widest opacity-80">SYSTEM ACTIVITY</h2>
      </div>

      <div className="flex-1 flex relative">
        {/* Y Axis */}
        <div className="flex flex-col justify-between text-[8px] opacity-40 w-5 pr-1 pb-1">
          <span>100</span>
          <span>50</span>
          <span>0</span>
        </div>

        {/* Bars */}
        <div className="flex-1 flex items-end gap-[2px] border-b border-l border-[rgba(0,229,255,0.2)] pb-0 pl-1">
          {bars.map((h, i) => (
            <motion.div
              key={i}
              animate={{ height: `${h}%` }}
              transition={{ type: 'spring', stiffness: 120, damping: 18 }}
              className="flex-1 min-w-[2px] rounded-t-sm"
              style={{
                background: `rgba(0,229,255,${0.4 + (h / 100) * 0.5})`,
                boxShadow: h > 60 ? '0 0 4px rgba(0,229,255,0.6)' : 'none',
              }}
            />
          ))}
        </div>
      </div>
    </motion.div>
  );
}
