import { motion } from 'framer-motion';
import { useState } from 'react';

export function CentralRing() {
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  return (
    <div className="dna-main-3d-shell relative w-[500px] h-[500px]" onMouseMove={(e) => { const r=e.currentTarget.getBoundingClientRect(); const nx=(e.clientX-r.left)/r.width-.5; const ny=(e.clientY-r.top)/r.height-.5; setTilt({x:-ny*10,y:nx*12}); }} onMouseLeave={() => setTilt({x:0,y:0})}>
    <motion.div className="dna-main-3d relative w-full h-full flex items-center justify-center" animate={{rotateX:tilt.x,rotateY:tilt.y}} transition={{type:'spring',stiffness:180,damping:20,mass:.55}}>
      {/* Outer Glow Ring */}
      <div className="absolute inset-0 rounded-full bg-cyan-glow opacity-[0.03] blur-xl"></div>
      
      {/* Rotate Rings */}
      <motion.svg
        className="absolute inset-0 w-full h-full opacity-60"
        viewBox="0 0 500 500"
        animate={{ rotate: 360 }}
        transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
      >
        <circle cx="250" cy="250" r="240" fill="none" stroke="var(--color-cyan-glow)" strokeWidth="1" strokeDasharray="4 12" />
        <circle cx="250" cy="250" r="230" fill="none" stroke="var(--color-cyan-glow)" strokeWidth="1" opacity="0.5" />
      </motion.svg>

      <motion.svg
        className="absolute inset-0 w-full h-full"
        viewBox="0 0 500 500"
        animate={{ rotate: -360 }}
        transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
      >
        <circle cx="250" cy="250" r="210" fill="none" stroke="var(--color-cyan-glow)" strokeWidth="2" strokeDasharray="100 40 20 40" opacity="0.8" />
        {/* Bold outer arcs */}
        <path d="M 460 250 A 210 210 0 0 1 250 460" fill="none" stroke="var(--color-cyan-glow)" strokeWidth="6" opacity="0.4" />
        <path d="M 40 250 A 210 210 0 0 1 250 40" fill="none" stroke="var(--color-cyan-glow)" strokeWidth="6" opacity="0.4" />
      </motion.svg>

      <motion.svg
        className="absolute inset-0 w-full h-full opacity-40"
        viewBox="0 0 500 500"
        animate={{ rotate: 360 }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
      >
        <circle cx="250" cy="250" r="180" fill="none" stroke="var(--color-cyan-glow)" strokeWidth="8" strokeDasharray="2 10" />
      </motion.svg>

      <motion.svg
        className="absolute inset-0 w-full h-full opacity-80"
        viewBox="0 0 500 500"
        animate={{ rotate: -360 }}
        transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
      >
        <circle cx="250" cy="250" r="150" fill="none" stroke="var(--color-cyan-glow)" strokeWidth="3" strokeDasharray="80 20" />
        <circle cx="250" cy="250" r="140" fill="none" stroke="var(--color-cyan-glow)" strokeWidth="1" />
      </motion.svg>
      
      {/* Corner Brackets */}
      <div className="absolute inset-0 w-[320px] h-[320px] m-auto">
        <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-cyan-glow opacity-80 rounded-tl-lg"></div>
        <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-cyan-glow opacity-80 rounded-tr-lg"></div>
        <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-cyan-glow opacity-80 rounded-bl-lg"></div>
        <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-cyan-glow opacity-80 rounded-br-lg"></div>
      </div>

      {/* Center Text */}
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        <motion.div 
          animate={{ opacity: [0.8, 1, 0.8] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="font-orbitron text-5xl font-bold tracking-[0.2em] text-cyan-glow glow-text mb-2 pl-4"
        >
          DNA.AI
        </motion.div>
        <div className="text-[10px] tracking-[0.3em] opacity-80">
          CORE SYSTEM ACTIVE
        </div>
      </div>
    </motion.div>
    </div>
  );
}
