import { motion } from 'framer-motion';
import { FormEvent, useEffect, useRef, useState } from 'react';
type Log={time:string;text:string}; const stamp=()=>`[${new Date().toLocaleTimeString('en-US',{hour12:false})}]`;
export function SystemConsole(){
 const[logs,setLogs]=useState<Log[]>([]),[command,setCommand]=useState(''),[busy,setBusy]=useState(false);
 const queueRef=useRef<string[]>([]), runningRef=useRef(false), inputRef=useRef<HTMLInputElement>(null);
 const add=(text:string)=>setLogs(p=>[...p.slice(-7),{time:stamp(),text}]);
 useEffect(()=>{ const quick=(e:Event)=>{const d=(e as CustomEvent<{action:string;value:string}>).detail;if(!d)return;if(d.action==='prefill')setCommand(d.value||'');requestAnimationFrame(()=>inputRef.current?.focus());};window.addEventListener('dna:quick-access',quick); add(window.dnaDesktop?'Electron IPC bridge connected. [ READY ]':'Browser preview: native desktop bridge unavailable. [ DEGRADED ]'); if(!window.dnaDesktop)return()=>window.removeEventListener('dna:quick-access',quick);
  const a=window.dnaDesktop.onVoiceTranscript(t=>add(`VOICE > ${t}`)); const b=window.dnaDesktop.onVoiceResult(r=>add(`DNA > ${r.message} [ ${r.ok?'OK':'FAILED'} ]`)); return()=>{a();b();window.removeEventListener('dna:quick-access',quick);}; },[]);
 const drain=async()=>{if(runningRef.current||!window.dnaDesktop)return;runningRef.current=true;setBusy(true);try{while(queueRef.current.length){const v=queueRef.current.shift()!;try{const r=await window.dnaDesktop.executeCommand(v);add(`DNA > ${r.message} [ ${r.ok?'OK':'FAILED'} ]`);}catch(x){add(`IPC error: ${x instanceof Error?x.message:String(x)} [ FAILED ]`);}}}finally{runningRef.current=false;setBusy(false);}};
 const submit=(e:FormEvent)=>{e.preventDefault();const v=command.trim();if(!v)return;setCommand('');add(`> ${v}`);requestAnimationFrame(()=>inputRef.current?.focus());if(!window.dnaDesktop){add('Native runtime unavailable. [ FAILED ]');return;}queueRef.current.push(v);void drain();};
 return <motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{duration:.5,delay:.4}} className="hud-panel hud-panel-brackets p-4 h-[170px] min-h-[170px] relative flex flex-col font-mono text-[11px]">
  <div className="flex items-center gap-2 mb-3"><div className="w-1.5 h-1.5 bg-cyan-glow"/><h2 className="text-xs tracking-widest opacity-80">SYSTEM CONSOLE</h2></div>
  <div className="flex-1 min-h-0 overflow-hidden flex flex-col justify-end gap-1 opacity-80 mb-10">{logs.map((l,i)=><div key={`${l.time}-${i}`} className="flex gap-3"><span className="opacity-60 shrink-0">{l.time}</span><span className="normal-case">{l.text}</span></div>)}</div>
  <form onSubmit={submit} className="absolute left-4 right-4 bottom-3 flex items-center gap-2 pt-2 border-t border-hud-border z-20"><span className="opacity-60">&gt;</span><input ref={inputRef} autoComplete="off" spellCheck={false} aria-label="DNA command" value={command} onChange={e=>setCommand(e.target.value)} placeholder={busy?'TYPE NEXT MESSAGE — IT WILL QUEUE...':'TYPE A COMMAND OR ASK DNA...'} className="flex-1 min-w-0 bg-transparent outline-none text-cyan-glow placeholder:text-cyan-glow/40 tracking-wider pointer-events-auto"/><motion.div animate={{opacity:[1,0,1]}} transition={{duration:1,repeat:Infinity}} className="w-2 h-3 bg-cyan-glow"/></form>
 </motion.div>;
}
