import { motion } from 'framer-motion';

const MODULES = [
  { name: 'VOICE ENGINE',    status: 'ACTIVE',  color: '#00ff00' },
  { name: 'VISION SYSTEM',   status: 'ACTIVE',  color: '#00ff00' },
  { name: 'NLP PROCESSOR',   status: 'ACTIVE',  color: '#00ff00' },
  { name: 'MEMORY CORE',     status: 'ACTIVE',  color: '#00ff00' },
  { name: 'LEARNING MODEL',  status: 'ACTIVE',  color: '#00ff00' },
  { name: 'AUTONOMOUS MODE', status: 'STANDBY', color: '#0088ff' },
];

export function AiModules() {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="hud-panel p-3 flex flex-col flex-1"
    >
      <div className="flex items-center gap-2 mb-3">
        <div className="w-1.5 h-1.5 bg-cyan-glow" />
        <h2 className="text-xs tracking-widest opacity-80">AI MODULES</h2>
      </div>

      <div className="flex flex-col justify-evenly flex-1">
        {MODULES.map((mod) => (
          <div key={mod.name} className="flex justify-between items-center text-[11px] py-0.5">
            <span className="opacity-80 tracking-wider">{mod.name}</span>
            <div className="flex items-center gap-2">
              <motion.div
                className="w-1.5 h-1.5 rounded-full"
                style={{ backgroundColor: mod.color, boxShadow: `0 0 6px ${mod.color}` }}
                animate={{ opacity: mod.status === 'ACTIVE' ? [1, 0.5, 1] : 1 }}
                transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
              />
              <span
                className="w-14 text-right font-tech text-[10px]"
                style={{ color: mod.color }}
              >
                {mod.status}
              </span>
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
