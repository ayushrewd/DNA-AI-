import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

export function HudHeader() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (d: Date) => {
    return d.toLocaleTimeString('en-US', { hour12: true, hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };
  
  const formatDate = (d: Date) => {
    return d.toLocaleDateString('en-US', { weekday: 'long', day: '2-digit', month: 'short', year: 'numeric' }).toUpperCase();
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className="flex justify-between items-start w-full border-b border-hud-border pb-4 mb-2 relative"
    >
      {/* Decorative lines */}
      <div className="absolute bottom-0 left-[20%] right-[20%] h-[1px] bg-cyan-glow opacity-30"></div>
      
      {/* Left side */}
      <div className="flex flex-col">
        <h1 className="font-orbitron text-4xl font-bold tracking-wider text-cyan-glow glow-text">DNA.AI</h1>
        <p className="text-[10px] tracking-[0.2em] opacity-80 mt-1">ARTIFICIAL INTELLIGENCE OPERATING SYSTEM</p>
      </div>

      {/* Center */}
      <div className="flex flex-col items-center justify-start pt-2">
        <div className="flex items-center gap-4 opacity-70">
          <div className="h-[1px] w-12 bg-cyan-glow"></div>
          <p className="text-xs tracking-[0.3em]">SYSTEM INTERFACE</p>
          <div className="h-[1px] w-12 bg-cyan-glow"></div>
        </div>
      </div>

      {/* Right side */}
      <div className="flex items-start gap-6">
        <div className="flex items-center gap-2 pt-2">
          <div className="w-2 h-2 rounded-full bg-[#00ff00] shadow-[0_0_8px_#00ff00] animate-pulse"></div>
          <span className="text-xs tracking-widest text-[#00ff00]">ONLINE</span>
        </div>
        <div className="w-[1px] h-12 bg-hud-border mx-2"></div>
        <div className="flex flex-col items-end">
          <div className="font-orbitron text-3xl font-bold tracking-wider">{formatTime(time)}</div>
          <div className="text-[10px] tracking-[0.1em] opacity-80 mt-1">{formatDate(time)}</div>
        </div>
      </div>
    </motion.div>
  );
}
