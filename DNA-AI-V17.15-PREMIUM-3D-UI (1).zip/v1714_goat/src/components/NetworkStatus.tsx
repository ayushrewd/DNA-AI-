import { motion } from 'framer-motion';

// Simplified continent dot-matrix coordinates [x, y] in a 200x100 viewBox
const CONTINENT_DOTS: [number, number][] = [
  // North America
  [18,8],[22,7],[26,7],[30,8],[34,8],[38,9],[42,10],[44,12],
  [16,12],[18,14],[20,15],[24,14],[28,13],[32,12],[36,12],[40,13],
  [16,18],[18,19],[20,20],[22,21],[26,20],[30,18],[34,16],[38,15],
  [18,24],[20,25],[22,26],[24,27],[26,26],[28,24],[30,22],[32,20],
  [18,28],[20,30],[22,31],[24,32],[22,34],[20,36],[19,38],
  [28,26],[30,28],[32,30],[34,29],[36,28],
  // Greenland
  [50,4],[54,4],[58,5],[56,7],[52,7],
  // South America
  [26,44],[28,43],[30,44],[32,45],[34,44],
  [24,48],[26,49],[28,50],[30,50],[32,49],[34,48],
  [24,54],[26,55],[28,56],[30,56],[32,55],
  [25,60],[27,62],[29,63],[31,62],[29,65],
  [27,68],[29,70],[28,73],[27,76],[26,79],
  // Europe
  [82,8],[84,7],[86,7],[88,8],[90,8],[92,8],[94,9],
  [80,12],[82,12],[84,11],[86,11],[88,10],[90,10],[92,10],[96,10],
  [80,16],[82,16],[84,15],[86,14],[88,13],[90,12],[94,12],[98,12],
  [82,20],[84,20],[86,19],[88,18],[90,17],[92,16],[96,15],
  [84,23],[86,22],[88,21],[90,20],[92,20],
  // UK/Iceland
  [76,12],[76,14],[78,11],
  [72,8],[74,9],[72,10],
  // Africa
  [84,28],[86,27],[88,27],[90,28],[92,28],[94,28],[96,28],
  [82,32],[84,32],[86,31],[88,30],[90,30],[92,31],[94,32],[96,32],[98,32],
  [82,36],[84,36],[86,35],[88,35],[90,35],[92,35],[94,36],[96,36],
  [84,40],[86,40],[88,40],[90,40],[92,40],[94,40],
  [85,44],[87,44],[89,44],[91,44],[93,44],
  [86,48],[88,48],[90,48],[92,48],
  [87,52],[89,52],[91,52],
  [88,56],[90,56],[89,60],
  // Madagascar
  [102,46],[102,49],[102,52],
  // Middle East
  [100,20],[102,19],[104,19],[106,20],[108,20],[110,21],
  [100,24],[102,24],[104,23],[106,22],[108,22],[110,22],[112,22],
  // Asia
  [104,8],[108,7],[112,7],[116,8],[120,8],[124,8],[128,9],[132,9],[136,10],[140,10],[144,10],[148,10],[152,11],
  [106,12],[110,11],[114,11],[118,11],[122,11],[126,11],[130,11],[134,11],[138,11],[142,11],[146,11],[150,12],[154,12],
  [106,16],[110,15],[114,15],[118,14],[122,14],[126,14],[130,14],[134,14],[138,14],[142,14],[146,14],[150,14],
  [108,20],[112,19],[116,18],[120,18],[124,18],[128,18],[132,18],[136,18],[140,18],[144,18],[148,18],
  [112,24],[116,23],[120,23],[124,23],[128,23],[132,23],[136,23],[140,23],[144,23],[148,23],
  [116,28],[120,28],[124,27],[128,27],[132,27],[136,28],[140,28],[144,28],
  [120,32],[124,32],[128,32],[132,32],[136,32],[140,32],
  [124,36],[128,36],[132,36],[136,36],
  // Japan
  [158,14],[160,15],[158,17],[160,19],
  // Philippines / Indonesia
  [148,38],[152,40],[156,40],[160,38],[156,44],[152,44],[148,44],
  // India
  [112,28],[114,28],[116,28],[118,28],
  [112,32],[114,32],[116,32],[118,32],
  [112,36],[114,36],[116,36],
  [113,40],[115,40],[114,44],
  // Australia
  [148,56],[152,54],[156,54],[160,54],[164,55],[168,56],[168,60],
  [148,60],[150,60],[154,59],[158,59],[162,59],[166,59],[170,60],
  [150,64],[154,64],[158,64],[162,64],[166,64],[168,64],
  [152,68],[156,68],[160,68],[164,68],
  [154,72],[158,72],[162,72],
  // New Zealand
  [174,68],[174,72],[176,76],
];

const NODE_POSITIONS = [
  { x: 25, y: 25 },   // North America
  { x: 90, y: 15 },   // Europe
  { x: 130, y: 20 },  // Asia
  { x: 90, y: 42 },   // Africa
];

export function NetworkStatus() {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
      className="hud-panel p-3 flex flex-col"
      style={{ height: '190px' }}
    >
      <div className="flex items-center gap-2 mb-2">
        <div className="w-1.5 h-1.5 bg-cyan-glow" />
        <h2 className="text-xs tracking-widest opacity-80">NETWORK STATUS</h2>
      </div>

      <div className="relative flex-1 rounded overflow-hidden bg-[rgba(0,229,255,0.02)] border border-[rgba(0,229,255,0.08)] mb-2">
        <svg viewBox="0 0 200 100" className="w-full h-full" preserveAspectRatio="xMidYMid meet">
          {/* Grid lines */}
          {[25,50,75].map(y => (
            <line key={y} x1="0" y1={y} x2="200" y2={y} stroke="rgba(0,229,255,0.04)" strokeWidth="0.5" />
          ))}
          {[50,100,150].map(x => (
            <line key={x} x1={x} y1="0" x2={x} y2="100" stroke="rgba(0,229,255,0.04)" strokeWidth="0.5" />
          ))}

          {/* Continent dots */}
          {CONTINENT_DOTS.map(([x, y], i) => (
            <circle
              key={i}
              cx={x}
              cy={y}
              r="0.9"
              fill="rgba(0,229,255,0.45)"
            />
          ))}

          {/* Animated pulsing nodes */}
          {NODE_POSITIONS.map((node, i) => (
            <g key={i}>
              <circle cx={node.x} cy={node.y} r="1.5" fill="#00e5ff" opacity="0.9" />
              <motion.circle
                cx={node.x}
                cy={node.y}
                r="1.5"
                fill="none"
                stroke="#00e5ff"
                strokeWidth="0.8"
                animate={{ r: [1.5, 5, 1.5], opacity: [0.9, 0, 0.9] }}
                transition={{ repeat: Infinity, duration: 2.5, delay: i * 0.6 }}
              />
            </g>
          ))}

          {/* Connection lines between nodes */}
          <line x1="25" y1="25" x2="90" y2="15" stroke="rgba(0,229,255,0.2)" strokeWidth="0.4" strokeDasharray="2 3" />
          <line x1="90" y1="15" x2="130" y2="20" stroke="rgba(0,229,255,0.2)" strokeWidth="0.4" strokeDasharray="2 3" />
          <line x1="90" y1="15" x2="90" y2="42" stroke="rgba(0,229,255,0.15)" strokeWidth="0.4" strokeDasharray="2 3" />
        </svg>
      </div>

      <div className="grid grid-cols-3 gap-2 text-center text-xs pb-0.5">
        <div className="flex flex-col gap-0.5">
          <span className="opacity-50 text-[9px] tracking-wider">CONNECTION</span>
          <span className="text-[#00ff00] font-orbitron text-[10px] tracking-wider">SECURE</span>
        </div>
        <div className="flex flex-col gap-0.5">
          <span className="opacity-50 text-[9px] tracking-wider">PING</span>
          <span className="font-orbitron text-[10px]">12ms</span>
        </div>
        <div className="flex flex-col gap-0.5">
          <span className="opacity-50 text-[9px] tracking-wider">DATA FLOW</span>
          <span className="font-orbitron text-[10px]">2.4 GB/S</span>
        </div>
      </div>
    </motion.div>
  );
}
