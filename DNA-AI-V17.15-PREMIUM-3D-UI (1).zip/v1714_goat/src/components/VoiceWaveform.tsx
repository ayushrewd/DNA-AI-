import { motion } from 'framer-motion'; import { useEffect,useState } from 'react';
export function VoiceWaveform(){ const[state,setState]=useState('UNAVAILABLE'),[last,setLast]=useState('');
 useEffect(()=>{if(!window.dnaDesktop)return; let off=()=>{}; window.dnaDesktop.voiceState().then(s=>{setState(s.state);setLast(s.lastTranscript)}); off=window.dnaDesktop.onVoiceState(s=>{setState(s.state);setLast(s.lastTranscript)}); window.dnaDesktop.voiceStart().catch(()=>setState('FAILED')); return()=>off();},[]);
 const active=['WAITING_WAKE','AWAKE','LISTENING','PROCESSING','SPEAKING'].includes(state); const bars=Array.from({length:60},(_,i)=>active?12+Math.abs(Math.sin(Date.now()/500+i*.45))*55:8);
 return <motion.div initial={{opacity:0,x:-20}} animate={{opacity:1,x:0}} transition={{duration:.5,delay:.3}} className="hud-panel p-4 h-[120px] flex flex-col justify-between">
  <div className="flex items-center gap-2 mb-2"><div className="w-1.5 h-1.5 bg-cyan-glow"/><h2 className="text-xs tracking-widest opacity-80">VOICE WAVEFORM</h2></div>
  <div className="flex-1 flex items-center justify-center gap-[2px]">{bars.map((h,i)=><motion.div key={i} animate={{height:active?[`${Math.max(8,h/2)}%`,`${h}%`,`${Math.max(8,h/2)}%`]:'8%'}} transition={{duration:.7,repeat:active?Infinity:0,delay:i*.01}} className="flex-1 bg-cyan-glow rounded-sm min-w-[2px] opacity-60"/>)}</div>
  <div className="flex items-center gap-2 mt-2"><div className={`w-2 h-2 rounded-full ${active?'bg-green-500':'bg-red-500'} shadow-[0_0_8px_currentColor]`}/><span className="text-[10px] tracking-widest opacity-60">{state}{last?` · ${last.slice(0,24)}`:''}</span></div>
 </motion.div> }
