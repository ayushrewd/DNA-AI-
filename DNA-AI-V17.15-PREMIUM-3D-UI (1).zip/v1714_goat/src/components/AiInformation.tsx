import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

export function AiInformation() {
  const [uptime, setUptime] = useState(5 * 3600 + 23 * 60 + 41);

  useEffect(() => {
    const interval = setInterval(() => setUptime(t => t + 1), 1000);
    return () => clearInterval(interval);
  }, []);

  const fmt = (s: number) => {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
  };

  const INFO = [
    { label: 'MODEL',      value: 'DNA AI PRO',  accent: false },
    { label: 'VERSION',    value: 'v8.1.0',       accent: false },
    { label: 'UPTIME',     value: fmt(uptime),    accent: false },
    { label: 'MEMORY',     value: '8.7 / 16 GB',  accent: false },
    { label: 'POWER MODE', value: 'OPTIMIZED',    accent: true  },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="hud-panel p-3 flex flex-col"
      style={{ height: '155px' }}
    >
      <div className="flex items-center gap-2 mb-2">
        <div className="w-1.5 h-1.5 bg-cyan-glow" />
        <h2 className="text-xs tracking-widest opacity-80">AI INFORMATION</h2>
      </div>

      <div className="flex flex-col justify-evenly flex-1">
        {INFO.map(item => (
          <div key={item.label} className="flex justify-between items-center text-[11px]">
            <span className="opacity-55 tracking-wider">{item.label}</span>
            <span
              className="font-orbitron tracking-widest text-[10px]"
              style={{ color: item.accent ? '#00e5ff' : 'inherit', textShadow: item.accent ? '0 0 6px #00e5ff' : 'none' }}
            >
              {item.value}
            </span>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
