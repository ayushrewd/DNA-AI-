import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';

interface Metric {
  label: string;
  letter: string;
  value: number;
  unit: string;
  type: string;
  max: number;
}

function WaveformCanvas({ value, color }: { value: number; color: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const timeRef = useRef(Math.random() * 100);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const draw = () => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      ctx.strokeStyle = color;
      ctx.lineWidth = 1.2;
      ctx.shadowColor = color;
      ctx.shadowBlur = 3;
      ctx.beginPath();

      const amplitude = (value / 100) * (h * 0.38) + h * 0.06;
      const frequency = 0.25 + value * 0.004;

      for (let x = 0; x < w; x++) {
        const t = timeRef.current + x * frequency;
        const y = h / 2 + Math.sin(t) * amplitude + Math.sin(t * 2.3 + 1) * amplitude * 0.3;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      timeRef.current += 0.04;
      rafRef.current = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(rafRef.current);
  }, [value, color]);

  return <canvas ref={canvasRef} width={120} height={28} className="w-full h-full" />;
}

function CircularGauge({ value, max, letter }: { value: number; max: number; letter: string }) {
  const pct = Math.min(value / max, 1);
  const r = 15;
  const circ = 2 * Math.PI * r;
  const dash = pct * circ * 0.75; // 270° arc
  const gap = circ - dash;

  return (
    <div className="relative w-11 h-11 flex items-center justify-center shrink-0">
      <svg className="absolute inset-0 w-full h-full" viewBox="0 0 40 40" style={{ transform: 'rotate(135deg)' }}>
        {/* Track */}
        <circle
          cx="20" cy="20" r={r}
          fill="none"
          stroke="rgba(0,229,255,0.12)"
          strokeWidth="2.5"
          strokeDasharray={`${circ * 0.75} ${circ * 0.25}`}
          strokeLinecap="round"
        />
        {/* Fill */}
        <circle
          cx="20" cy="20" r={r}
          fill="none"
          stroke="#00e5ff"
          strokeWidth="2.5"
          strokeDasharray={`${dash} ${gap + circ * 0.25}`}
          strokeLinecap="round"
          style={{
            transition: 'stroke-dasharray 1s ease',
            filter: 'drop-shadow(0 0 3px #00e5ff)',
          }}
        />
      </svg>
      <span className="text-[9px] font-orbitron opacity-70 relative z-10">{letter}</span>
    </div>
  );
}

export function SystemDiagnostics() {
  const [metrics, setMetrics] = useState<Metric[]>([
    { label: 'CPU', letter: 'C', value: 0, unit: '', type: 'PENDING', max: 100 },
    { label: 'RAM', letter: 'R', value: 0, unit: '%', type: 'PENDING', max: 100 },
    { label: 'GPU', letter: 'G', value: 0, unit: '', type: 'N/A', max: 100 },
    { label: 'TEMP', letter: 'T', value: 0, unit: '', type: 'N/A', max: 100 },
  ]);

  useEffect(() => {
    let cancelled = false;
    const refresh = async () => {
      if (!window.dnaDesktop) return;
      try {
        const m = await window.dnaDesktop.getSystemMetrics();
        if (!cancelled) setMetrics([
          { label: 'CPU', letter: 'C', value: Math.min(m.cpuCount, 100), unit: '', type: `${m.cpuCount} CORES`, max: 100 },
          { label: 'RAM', letter: 'R', value: m.ramPercent, unit: '%', type: 'REAL USAGE', max: 100 },
          { label: 'GPU', letter: 'G', value: 0, unit: '', type: 'N/A', max: 100 },
          { label: 'TEMP', letter: 'T', value: 0, unit: '', type: 'N/A', max: 100 },
        ]);
      } catch { /* diagnostics remain degraded */ }
    };
    refresh(); const id = setInterval(refresh, 3000);
    return () => { cancelled = true; clearInterval(id); };
  }, []);

  return (
    <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.1 }} className="hud-panel hud-panel-brackets p-3 flex flex-col gap-2" style={{ height: '260px' }}>
      <div className="flex items-center gap-2 mb-1"><div className="w-1.5 h-1.5 bg-cyan-glow"/><h2 className="text-xs tracking-widest opacity-80">SYSTEM DIAGNOSTICS</h2></div>
      <div className="flex flex-col gap-2 flex-1">
        {metrics.map((m) => <div key={m.label} className="flex items-center gap-3 h-[44px]">
          <CircularGauge value={m.value} max={m.max} letter={m.letter}/>
          <div className="w-[72px] shrink-0"><div className="text-[9px] opacity-60 tracking-wider leading-tight">{m.label}</div><div className="text-base font-orbitron leading-tight mt-0.5 text-cyan-glow" style={{ textShadow: '0 0 8px #00e5ff' }}>{m.value || '--'}{m.unit}</div><div className="text-[7px] opacity-40 tracking-wider">{m.type}</div></div>
          <div className="flex-1 h-[28px] opacity-70"><WaveformCanvas value={m.value} color="#00e5ff"/></div>
        </div>)}
      </div>
    </motion.div>
  );
}
