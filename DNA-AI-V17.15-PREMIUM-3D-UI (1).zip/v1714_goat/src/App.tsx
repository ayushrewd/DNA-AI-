import HudDashboard from '@/pages/HudDashboard';
import AssistantOverlay from '@/pages/AssistantOverlay';
import SetupPage from '@/pages/SetupPage';
export default function App() {
  const params = new URLSearchParams(window.location.search);
  if (params.get('dnaSetup') === '1') return <SetupPage />;
  return params.get('dnaOverlay') === '1' ? <AssistantOverlay /> : <HudDashboard />;
}
