import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

export default function AssistantOverlay() {
  const [state,setState]=useState('AWAKE');
  useEffect(()=>{
    document.documentElement.classList.add('dna-overlay-page');
    document.body.classList.add('dna-overlay-page');
    if(!window.dnaDesktop) return ()=>{document.documentElement.classList.remove('dna-overlay-page');document.body.classList.remove('dna-overlay-page');};
    window.dnaDesktop.voiceState().then(v=>setState(v.state));
    const offState=window.dnaDesktop.onVoiceState(v=>setState(v.state));
    const offResult=window.dnaDesktop.onVoiceResult(()=>{});
    return ()=>{offState();offResult();document.documentElement.classList.remove('dna-overlay-page');document.body.classList.remove('dna-overlay-page');};
  },[]);
  useEffect(()=>{
    if(state==='WAITING_WAKE'){
      const t=setTimeout(()=>window.dnaDesktop?.hideAssistant(),900);
      return ()=>clearTimeout(t);
    }
  },[state]);
  const active=state==='AWAKE'||state==='SPEAKING'||state==='PROCESSING';
  const speaking=state==='SPEAKING';
  const thinking=state==='PROCESSING';
  return <div className="dna-orb-stage">
    <motion.div
      className="dna-orb-wrap dna-orb-only"
      initial={{opacity:0,x:38,scale:.55,rotateY:-28}}
      animate={{opacity:1,x:0,scale:1,rotateY:0,y:[0,-5,0,4,0]}}
      exit={{opacity:0,x:28,scale:.55}}
      transition={{opacity:{duration:.18},x:{type:'spring',stiffness:280,damping:22},scale:{type:'spring',stiffness:260,damping:20},rotateY:{duration:.4},y:{repeat:Infinity,duration:3.6,ease:'easeInOut'}}}
    >
      <motion.div
        className={`dna-orb ${active?'dna-orb-active':''} ${speaking?'dna-orb-speaking':''} ${thinking?'dna-orb-thinking':''}`}
        animate={{scale: state==='AWAKE'?[1,1.075,1]:speaking?[1,1.09,.97,1.055,1]:thinking?[1,1.035,1]:[1,1.018,1]}}
        transition={{repeat:Infinity,duration:state==='AWAKE'?.95:speaking?.62:thinking?1.25:2,ease:'easeInOut'}}
      >
        <motion.div className="dna-orb-energy dna-orb-energy-a" animate={{rotate:360}} transition={{repeat:Infinity,duration:thinking?1.9:4.8,ease:'linear'}} />
        <motion.div className="dna-orb-energy dna-orb-energy-b" animate={{rotate:-360}} transition={{repeat:Infinity,duration:thinking?2.6:6.5,ease:'linear'}} />
        <motion.div className="dna-orb-energy dna-orb-energy-c" animate={{rotate:360,scale:speaking?[1,1.12,1]:[1,1.035,1]}} transition={{repeat:Infinity,duration:speaking?.7:3.2,ease:'easeInOut'}} />
        <div className="dna-orb-core"><span>DNA</span></div>
        <div className="dna-orb-specular" />
      </motion.div>
      <div className="dna-orb-shadow" />
    </motion.div>
  </div>;
}
