import { useEffect, useState } from 'react';

declare global { interface Window { dnaDesktop?: any } }

export default function SetupPage() {
  const [key, setKey] = useState('');
  const [configured, setConfigured] = useState(false);
  const [status, setStatus] = useState('');
  useEffect(() => { window.dnaDesktop?.configStatus?.().then((x:any)=>setConfigured(Boolean(x?.aiConfigured))); }, []);
  async function save() {
    if (!key.trim()) { setStatus('Paste a valid API key first.'); return; }
    await window.dnaDesktop?.saveApiKey?.(key.trim());
    setKey(''); setConfigured(true); setStatus('Saved securely for this Windows account. You can close this window.');
  }
  return <main className="min-h-screen bg-[#050a0f] text-cyan-100 flex items-center justify-center p-8">
    <section className="w-full max-w-xl border border-cyan-400/30 bg-black/40 rounded-2xl p-8 shadow-2xl">
      <div className="text-xs tracking-[0.35em] text-cyan-400 mb-3">DNA.AI // FIRST-RUN SETUP</div>
      <h1 className="text-3xl font-semibold mb-3">Connect the AI brain</h1>
      <p className="text-sm text-cyan-100/60 mb-6">Local Windows commands work without an AI key. The key is stored for this Windows account and is never exposed to the renderer after saving.</p>
      <div className="mb-3 text-sm">Status: <span className={configured ? 'text-emerald-400' : 'text-amber-300'}>{configured ? 'AI configured' : 'AI not configured'}</span></div>
      <input type="password" value={key} onChange={e=>setKey(e.target.value)} placeholder="Paste API key" className="w-full bg-black/60 border border-cyan-400/30 rounded-xl px-4 py-3 outline-none focus:border-cyan-300" />
      <button onClick={save} className="mt-4 w-full rounded-xl border border-cyan-300/50 bg-cyan-400/10 py-3 font-medium hover:bg-cyan-400/20">Save & activate DNA.AI</button>
      {status && <p className="mt-4 text-sm text-cyan-100/70">{status}</p>}
      <div className="mt-6 border-t border-cyan-400/15 pt-5">
        <div className="text-xs tracking-[0.2em] text-cyan-400 mb-2">BROWSER AGENT</div>
        <p className="text-xs text-cyan-100/50 mb-3">DNA uses its own persistent Edge profile for authenticated browser actions. Sign in yourself; DNA does not read or store your passwords.</p>
        <div className="grid grid-cols-2 gap-3">
          <button onClick={()=>window.dnaDesktop?.browserLogin?.('chatgpt')} className="rounded-xl border border-cyan-300/30 py-2 text-sm hover:bg-cyan-400/10">Connect ChatGPT</button>
          <button onClick={()=>window.dnaDesktop?.browserLogin?.('whatsapp')} className="rounded-xl border border-cyan-300/30 py-2 text-sm hover:bg-cyan-400/10">Connect WhatsApp</button>
        </div>
      </div>
      <p className="mt-6 text-xs text-cyan-100/40">Local Windows actions and natural voice do not depend on conversational AI quota. Provider failures do not disable local automation.</p>
    </section>
  </main>
}
