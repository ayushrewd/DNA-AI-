# DNA.AI V7 — Final Canonical Candidate

V7 adds a provider-independent local image-generation tool and changes the default conversational brain order to local-first (`ollama,gemini`). Gemini is optional, not the identity or mandatory runtime.

## Image creation
DNA can route commands such as:
- `create an image of a futuristic Delhi at night`
- `wallpaper banao futuristic DNA helix cyberpunk`
- `make a poster for a coding event`

The local image tool talks to a locally running ComfyUI server (default `http://127.0.0.1:8188`), discovers an installed checkpoint, queues a standard text-to-image workflow, waits for completion, downloads the generated file, and verifies that it was written to the Windows Downloads folder.

This does **not** bundle a multi-GB image checkpoint. Install/start ComfyUI and a compatible checkpoint separately. This is deliberate: model licensing, GPU/VRAM needs, and checkpoint choice vary by PC.

## Brain policy
Default: Ollama first, Gemini second. Local PC actions never require Gemini. Cloud AI remains optional for harder conversation/vision tasks.

## Truthful release status
Source-level syntax/compile checks can be performed outside Windows. Microphone, neural voice, Windows UI automation, authenticated browser sessions, local LLM speed, and local image generation require runtime acceptance testing on the target Windows PC before being called verified.
