# DNA.AI Ultimate RC — Capability Build

This is the canonical continuation of DNA.AI Core v1. Existing HUD is preserved.

## Added in this build
- Natural neural speech path using Gemini 3.1 Flash TTS Preview when configured, with Windows SAPI only as an offline fallback.
- Hinglish/English voice direction and a short natural wake acknowledgement.
- Local contact book: `remember contact Rahul as +9198...`.
- Explicit WhatsApp send flow: `send whatsapp to Rahul saying I am late` opens the saved contact/message and confirms the send with Enter after WhatsApp focuses. Use only when the command itself contains `send`.
- Local screenshot capture: `take screenshot`.
- Generic screen primitives: `click 850, 420` and `type hello world`.
- Local file search, app discovery, clipboard, browser search, background startup, tray mode and local-first routing retained.

## Important engineering boundaries
- Screen primitives are real OS actions but are not yet a vision planner. Microsoft OmniParser-class screen parsing is a future sidecar because bundling its model weights would materially increase installer size and GPU/RAM requirements.
- Authenticated ChatGPT image downloading cannot be made reliable by stealing/reusing browser cookies. A production implementation should use an explicit browser companion/Playwright profile controlled by DNA.AI. Browser auth state is sensitive and must not be copied into source control.
- Singing is not faked. Natural TTS may perform expressive speech, but true singing/music generation requires a separate music model such as ACE-Step and suitable local GPU/runtime.
- Natural TTS is network/quota dependent. Local Windows actions remain independent from it.

## Voice environment options
- `DNA_NATURAL_VOICE=1` (default)
- `DNA_TTS_MODEL=gemini-3.1-flash-tts-preview`
- `DNA_TTS_VOICE=Achird`
- `DNA_WAKE_REPLY=Haan, bol?`
