# DNA.AI V5 — Maximum Engineering Candidate

This is the single canonical continuation of V4. It is not claimed to be a frontier foundation model and does not contain ChatGPT/GPT weights or private training data.

## What V5 materially changes

- Adaptive local speech capture: waits for speech and ends on natural silence instead of fixed recording windows.
- faster-whisper multilingual STT with VAD and optional hotwords for DNA/app names.
- Local-first command execution remains independent of cloud-model quota.
- Browser accessibility inspection using Playwright ARIA snapshots, plus role/text based interaction before coordinate clicking.
- Existing screen vision + Windows structured UI automation remain available.
- Runtime audit trail with action risk classification.
- Multi-action local plans, action verification, persistent browser sessions, WhatsApp confirmation, ChatGPT download workflow, web research, memory, Ollama fallback, neural TTS, tray/autostart remain.

## Truthful limits

1. A custom acoustic `Hey DNA` wake model is not bundled. Whisper wake recognition is used unless a future dedicated trained wake model is installed.
2. Natural neural TTS quality depends on the selected TTS provider/voice and network when using Edge/Gemini paths.
3. Arbitrary computer use cannot be guaranteed on every Windows application. DNA prefers accessibility/DOM automation, then vision, and only uses coordinate primitives when explicitly requested.
4. Authenticated sites can change their UI and may require workflow maintenance.
5. No model can be given unrestricted administrator access safely; destructive/external actions need permission boundaries.
6. Windows microphone, latency, installed-app, and authenticated-browser behavior must be runtime-tested on the target PC.

## Recommended voice setup

Run `SETUP_LOCAL_VOICE.bat`. Default STT model is `small`. On a capable GPU, set `DNA_WHISPER_MODEL=large-v3` and `DNA_WHISPER_DEVICE=cuda` for higher accuracy. CPU users should start with `small` or `medium`.

## Release rule

Do not create a new version for every failed test. Fix this canonical source and rerun the acceptance suite.
