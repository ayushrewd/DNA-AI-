# DNA.AI P6.2 Local-First Router Fix

- Local desktop commands are resolved before any AI provider call.
- Command-like input never falls through to the AI provider when an app is unknown.
- Added normalization and common speech aliases.
- AI provider/quota details are logged internally and are no longer exposed as Gemini-branded user messages.
- Existing wake, overlay, Gemini conversation, tray, and UI architecture are preserved.
