# DNA.AI Acceptance Suite

A release is not “final” until these pass on the target Windows PC.

1. Background startup survives reboot/login.
2. 20/20 quiet-room `Hey DNA` wake attempts; record false wakes over 30 minutes.
3. Hinglish: `calculator kholo`, `Chrome kholo aur YouTube kholo`, `volume kam karo`.
4. Barge/latency observation: command capture ends after natural silence rather than waiting a fixed 7–9 seconds.
5. Gemini quota disabled: local app/file/volume commands still work.
6. Conversation maintains at least five follow-up turns without identity/provider leakage.
7. Memory: remember → restart → recall → forget.
8. File search returns an existing known file and never invents a path.
9. Browser inspection returns current page accessibility state; named control click is verified visually.
10. ChatGPT download only after user signs in to DNA's persistent browser profile; downloaded file exists.
11. WhatsApp contact draft is shown before send; send requires explicit confirmation.
12. Screen analysis describes the current desktop without claiming actions it did not execute.
13. Known app launch is process-verified.
14. Failed action reports failure instead of `Done`.
15. Audit log records command, intent, result and risk class.
