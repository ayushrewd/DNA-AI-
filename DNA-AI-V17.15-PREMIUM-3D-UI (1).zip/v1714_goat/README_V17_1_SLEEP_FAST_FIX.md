# DNA.AI V17.1 — Sleep + Anti-Loop + Speed Fix

Focused patch only; frontend unchanged.

## Fixes
- Adds voice command: `sleep`, `sleep mode`, `go to sleep`, `so ja`, `so jao`.
- Sleep returns DNA to wake-word-only mode; `DNA` / `Hey DNA` wakes it again.
- Continuous follow-up listening is now OFF by default to prevent speaker/noise/Whisper feedback loops. Set `DNA_CONTINUOUS_SESSION=1` only if explicitly wanted.
- Repeated identical STT transcripts inside 8 seconds are ignored instead of executed/spoken again.
- Post-TTS cooldown reduced from 1500 ms to 650 ms.
- Edge TTS default rate increased from +2% to +12%.
- Command capture default reduced from 9s to 7s (VAD can still finish earlier).

## Expected flow
Hey DNA -> command -> execute -> reply -> 650ms cooldown -> wake-only.
Say `sleep` -> DNA confirms -> wake-only sleep state -> say `Hey DNA` to wake.

## Validation performed here
- electron/main.cjs syntax: PASS
- preload syntax: PASS
- Python bridge compile: PASS
- deterministic router: 11/11 PASS
- physical Windows microphone/TTS loop: MANUAL TEST REQUIRED
