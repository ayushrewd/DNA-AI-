@echo off
setlocal
cd /d "%~dp0"
echo ==========================================
echo DNA.AI - OPTIONAL LOCAL HINGLISH VOICE SETUP
echo ==========================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher was not found. Install Python 3.10, 3.11 or 3.12, then run this again.
  if /I not "%~1"=="--no-pause" if /I not "%~1"=="--no-pause" pause
  exit /b 1
)
py -m pip install --upgrade pip
py -m pip install faster-whisper sounddevice numpy edge-tts
if errorlevel 1 (
  echo Voice dependency installation failed.
  if /I not "%~1"=="--no-pause" if /I not "%~1"=="--no-pause" pause
  exit /b 1
)
echo.
echo DONE. On first use faster-whisper downloads the selected local model.
echo Default model: medium for substantially better command/name accuracy. First voice use downloads the model once.
if /I not "%~1"=="--no-pause" pause
