# DNA.AI Core v1

Canonical installer-ready build.

## Runtime architecture
- Background Electron main process starts at Windows login.
- Local wake listener is independent of cloud AI.
- Wake acknowledgement uses local Windows TTS.
- Voice transcript is routed through the same local-first intent router as typed commands.
- Local actions never require AI quota.
- Conversational input falls back to the configured AI provider.
- API key is stored with Electron safeStorage when configured through Settings.
- Recent command history is stored locally in the app user-data directory.

## Local capabilities in v1
Open common apps/sites, Windows shell app discovery, close common processes, Google/YouTube search, open Downloads, search files in Desktop/Documents/Downloads, clipboard read, WhatsApp draft by phone number, tray/background startup.

## Deliberately not claimed
Contact-name resolution, autonomous WhatsApp Send, authenticated ChatGPT image downloading, reliable multilingual neural STT, natural neural voice, singing synthesis, arbitrary GUI computer-use, destructive file actions, and administrator automation are not falsely marked complete. They require dedicated integrations and permission/confirmation controls.
