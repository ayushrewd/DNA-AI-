# DNA.AI V17.14 — GOAT Interactive UI

Frontend/overlay refinement based on the working V17.11 core.

- Main HUD pushed to near-black with brighter electric sky-blue highlights.
- Central DNA core gets layered 3D depth without adding Three.js or other packages.
- Quick Access controls are real buttons and focus/prefill the existing command console.
- Existing MIC control remains wired to the existing voiceToggle IPC.
- Assistant overlay removes page/background/shadow layers so only the circular orb is visible.
- No Ollama, PyTorch, image generation, screen scanning, or new package dependency added.
- Voice/command routing architecture remains the V17.11 baseline.
