# DNA.AI V16 — Packaged Voice Engine Repair

Fixes the production-only voice failure where Python bridge scripts were packaged inside `app.asar`. Python cannot execute Electron ASAR virtual paths.

Changes:
- `voice/**/*` is explicitly unpacked by electron-builder.
- Production bridge resolution uses `resources/app.asar.unpacked/voice/...`.
- Development resolution is unchanged.
- Existing V15 wake, persistent microphone, Whisper accuracy, router, UI, and action behavior are preserved.
