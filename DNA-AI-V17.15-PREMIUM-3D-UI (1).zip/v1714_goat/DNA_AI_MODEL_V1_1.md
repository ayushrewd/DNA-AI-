# DNA.AI Model v1.1 — Canonical Personal Agent

This is the single canonical branch. Do not merge older P0–P6 folders back into it.

## Runtime architecture

Wake/voice -> unified local-first intent router -> local Windows/browser/file tools -> optional AI conversation -> natural TTS.

The AI provider is never the operating-system control plane. Local commands continue when AI quota is unavailable.

## Added in v1.1

- Natural neural TTS path independent of Gemini conversational quota (Edge neural voice, with Gemini TTS and Windows SAPI fallbacks).
- Persistent Playwright/Edge browser agent using a dedicated DNA profile.
- One-time user-controlled login for ChatGPT and WhatsApp; passwords are not captured by DNA.
- Authenticated ChatGPT latest-image download attempt using page download controls.
- WhatsApp contact-name draft workflow plus explicit "send it" confirmation.
- Existing local app launcher, file search, screenshot, clipboard, click/type primitives retained.
- Windows login startup, tray runtime, Siri-style overlay and local-first command routing retained.

## Runtime verification required on Windows

The build environment cannot physically test microphone recognition, Edge UI state, WhatsApp/ChatGPT account state, or Windows foreground automation. These features must be marked working only after tests on the target PC.

## Known engineering boundary

The legacy System.Speech recognizer remains the weakest subsystem for natural Hinglish STT. The architecture is ready for a Whisper-class local speech worker, but a production model/binary is not bundled in this source archive. Do not claim Siri-grade recognition until that worker is integrated and benchmarked.

## Commercial note

The included Edge neural TTS package is appropriate for personal prototyping. Before distributing DNA.AI commercially or to thousands of users, replace it with a TTS provider/model whose license and service terms explicitly cover that deployment.
