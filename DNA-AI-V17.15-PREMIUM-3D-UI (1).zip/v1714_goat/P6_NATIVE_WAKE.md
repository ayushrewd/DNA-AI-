# P6 — Dedicated "Hey DNA" Wake Engine

## Root cause fixed
P5 used Windows `System.Speech` dictation to transcribe the wake phrase. On the tested machine, saying "Hey DNA" was transcribed as "AT&T". A general-purpose STT recognizer is the wrong primitive for an always-on wake phrase.

## Architecture

Waiting state:
`Microphone -> PvRecorder -> Porcupine custom Hey DNA model -> wake event`

After wake:
`stop Porcupine mic -> Siri overlay -> TTS "Yes?" -> Windows STT one-command capture -> Intent/Gemini -> TTS -> restart Porcupine`

This prevents two engines fighting for the microphone and avoids DNA listening to its own TTS.

## Setup
1. Create a free Picovoice account and obtain an AccessKey.
2. In Picovoice Console > Porcupine, train the phrase `Hey DNA` for Windows.
3. Download the `.ppn` model and save it as `voice/hey-dna_windows.ppn`.
4. Add `PICOVOICE_ACCESS_KEY=...` to `.env`.
5. Run `npm install`, then `npm run electron:dev`.

If Picovoice is not configured, P6 deliberately falls back to a constrained Windows System.Speech wake grammar. The UI reports that this is degraded mode; it is not presented as production-grade wake detection.
